﻿namespace ConsoleAppLection09
{
    interface SOLID_I_Loader
    {
        void LoadDataFromApi(string url);
    }
}