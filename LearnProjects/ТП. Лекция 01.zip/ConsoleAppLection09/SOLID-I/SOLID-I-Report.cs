﻿namespace ConsoleAppLection09
{
    interface SOLID_I_Report
    {
        void CreateReport(string fileName);
    }
}