﻿namespace ConsoleAppLection09
{
    interface SOLID_I
    {
        void CreateReport(string fileName);

        void SendMail(string receiver);

        void LoadDataFromApi(string url);
    }
}