﻿namespace ConsoleAppLection09
{
    interface SOLID_I_Mail
    {
        void SendMail(string receiver);
    }
}