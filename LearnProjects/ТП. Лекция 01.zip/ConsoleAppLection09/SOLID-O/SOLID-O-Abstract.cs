﻿namespace ConsoleAppLection09
{
    abstract class SOLID_O_Abstract
    {
        protected bool CheckFileName(string fileName)
        {
            return string.IsNullOrEmpty(fileName);
        }

        public abstract void CreateReport(string fileName);
    }
}