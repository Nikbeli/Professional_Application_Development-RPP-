﻿namespace ConsoleAppLection09
{
    class SOLID_O_Update
    {
        public void CreateReport(string fileName, string type)
        {
            SOLID_O_Abstract report = null;

            switch (type)
            {
                case "doc":
                    report = new SOLID_O_Doc();
                    break;
                case "excel":
                    report = new SOLID_O_Excel();
                    break;
                case "pdf":
                    report = new SOLID_O_Pdf();
                    break;
            }

            report?.CreateReport(fileName);
        }
    }
}