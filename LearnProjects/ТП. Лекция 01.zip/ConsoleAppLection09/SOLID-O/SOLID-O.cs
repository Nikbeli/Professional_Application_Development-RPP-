﻿namespace ConsoleAppLection09
{
    class SOLID_O
    {
        private string _fileName;
        public void CreateReport(string fileName, string type)
        {
            _fileName = fileName;

            switch (type)
            {
                case "doc":
                    CreateDoc();
                    break;
                case "excel":
                    CreateExcel();
                    break;
                case "pdf":
                    CreatePdf();
                    break;
            }
        }

        private void CreatePdf()
        {
            if (string.IsNullOrEmpty(_fileName))
            {
                return;
            }
        }

        private void CreateDoc()
        {

        }

        private void CreateExcel()
        {

        }
    }
}