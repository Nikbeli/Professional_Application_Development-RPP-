﻿using System;

namespace ConsoleAppLection09
{
    class SOLID_O_Doc : SOLID_O_Abstract
    {
        public override void CreateReport(string fileName)
        {
            throw new NotImplementedException();
        }
    }
}