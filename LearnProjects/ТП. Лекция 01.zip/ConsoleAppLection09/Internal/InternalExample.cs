﻿namespace ConsoleAppLection09
{
    internal class InternalExample
    {
        public int Fild { get; set; }
    }
}