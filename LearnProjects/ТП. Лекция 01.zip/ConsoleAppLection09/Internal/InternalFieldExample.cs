﻿namespace ConsoleAppLection09
{
    public class InternalFieldExample
    {
        internal int Field { get; set; }

        protected internal int ProtField { get; set; }
    }
}