﻿using System;

namespace ConsoleAppLection09
{
    class Program
    {
        static void Main(string[] args)
        {
            InternalExample xampl = new InternalExample();
            xampl.Fild = 10;
            InternalFieldExample exampl = new InternalFieldExample();
            exampl.Field = 15;

            #region Singleton
            // Singleton s = new Singleton();

            //s = Singleton.getInstance();
            #endregion

            Console.ReadKey();
        }

        void MethodArr1()
        {
            Console.Write("Введите размерность массива:");
            int n = Convert.ToInt32(Console.ReadLine());
            int[] arr = new int[n];
            Random rnd = new Random();
            for (int i = 0; i < n; ++i)
            {
                arr[i] = rnd.Next();
            }

            for (int i = 0; i < arr.Length; ++i)
            {
                Console.Write(" ", arr[i]);
            }

            for (int i = 0; i < n; ++i)
            {
                arr[i] = arr[n - i];
            }

            for (int i = 0; i < arr.Length; ++i)
            {
                Console.Write(" ", arr[i]);
            }
        }

        void PrintArr(int[] arr, int n)
        {
            for (int i = 0; i < n; ++i)
            {
                Console.Write(" ", arr[i]);
            }
            Console.WriteLine();
        }

        void MethodArr()
        {
            Console.Write("Введите размерность массива:");
            int n = Convert.ToInt32(Console.ReadLine());
            int[] arr = new int[n];
            Random rnd = new Random();
            for (int i = 0; i < n; ++i)
            {
                arr[i] = rnd.Next();
            }

            PrintArr(arr, arr.Length);

            for (int i = 0; i < n; ++i)
            {
                arr[i] = arr[n - i];
            }

            PrintArr(arr, arr.Length);
        }
    }
}
