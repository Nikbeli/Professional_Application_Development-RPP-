﻿namespace ConsoleAppLection09
{
    class SOLID_L_GoodJunior : SOLID_L_Employee
    {
        public override void DoWork(string task)
        {
            ReportIdea(task);
            base.DoWork(task);
        }

        private void ReportIdea(string task)
        {
            var c = task;
        }
    }
}