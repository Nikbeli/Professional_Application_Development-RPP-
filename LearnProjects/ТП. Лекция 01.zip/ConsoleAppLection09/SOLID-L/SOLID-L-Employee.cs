﻿namespace ConsoleAppLection09
{
    class SOLID_L_Employee
    {
        public virtual void DoWork(string task)
        {
            Analisys(task);
            Work(task);
            Report(task);
        }

        private void Analisys(string task)
        {
            string s = task;
        }

        private void Work(string task)
        {
            string s = task;
        }

        private void Report(string task)
        {
            string s = task;
        }
    }
}