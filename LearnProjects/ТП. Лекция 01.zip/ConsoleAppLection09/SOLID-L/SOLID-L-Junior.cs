﻿namespace ConsoleAppLection09
{
    class SOLID_L_Junior : SOLID_L_Employee
    {
        public override void DoWork(string task)
        {
            DrinkTea();
        }

        private void DrinkTea()
        {

        }
    }
}