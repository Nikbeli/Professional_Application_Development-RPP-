﻿using System.Collections.Generic;

namespace ConsoleAppLection09
{
    class SOLID_S
    {
        public int Id { get; set; }

        public string UserName { get; set; }

        public string Passwrod { get; set; }

        public void AddRecordToBD(SOLID_S record) 
        {
            if (record == null)
            {
                return;
            }
            // Логика вставки в БД
        }

        public bool CheckUser(string user, string password)
        {
            var list = GetFromBDRecords(); 
            foreach(var elem in list)
            {
                if (elem.UserName == user && elem.Passwrod == password)
                {
                    return true;
                }
            }
            return false;
        }

        public List<SOLID_S> GetFromBDRecords() 
        {
            // Логика получения записей из БД
            return null; 
        }

        public void CreateReport(string fileName)
        {
            if (string.IsNullOrEmpty(fileName))
            {
                return;
            }
        }
    }
}