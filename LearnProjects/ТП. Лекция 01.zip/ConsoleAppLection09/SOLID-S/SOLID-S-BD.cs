﻿using System.Collections.Generic;

namespace ConsoleAppLection09
{
    class SOLID_S_BD
    {
        public void AddRecordToBD(SOLID_S_Data record)
        {
            if (record == null)
            {
                return;
            }
            // Логика вставки в БД
        }

        public List<SOLID_S_Data> GetFromBDRecords()
        {
            // Логика получения записей из БД
            return null;
        }
    }
}