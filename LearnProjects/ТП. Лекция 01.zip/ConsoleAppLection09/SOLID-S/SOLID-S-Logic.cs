﻿namespace ConsoleAppLection09
{
    class SOLID_S_Logic
    {
        private SOLID_S_BD _bd;

        private SOLID_S_Report _report;

        public SOLID_S_Logic(SOLID_S_BD bd, SOLID_S_Report report)
        {
            _bd = bd;
            _report = report;
        }

        public void AddRecordToBD(SOLID_S_Data record)
        {
            _bd.AddRecordToBD(record);
        }

        public bool CheckUser(string user, string password)
        {
            var list = _bd.GetFromBDRecords();
            foreach (var elem in list)
            {
                if (elem.UserName == user && elem.Passwrod == password)
                {
                    return true;
                }
            }
            return false;
        }

        public void CreateReport(string fileName)
        {
            _report.CreateReport(fileName);
        }
    }
}