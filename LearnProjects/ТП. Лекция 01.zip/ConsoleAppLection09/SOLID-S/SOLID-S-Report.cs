﻿namespace ConsoleAppLection09
{
    class SOLID_S_Report
    {
        public void CreateReport(string fileName)
        {
            if (string.IsNullOrEmpty(fileName))
            {
                return;
            }
        }
    }
}