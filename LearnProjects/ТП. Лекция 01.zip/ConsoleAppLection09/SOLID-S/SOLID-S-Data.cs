﻿namespace ConsoleAppLection09
{
    class SOLID_S_Data
    {
        public int Id { get; set; }

        public string UserName { get; set; }

        public string Passwrod { get; set; }
    }
}