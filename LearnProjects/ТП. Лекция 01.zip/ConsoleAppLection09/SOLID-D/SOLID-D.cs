﻿namespace ConsoleAppLection09
{
    class SOLID_D
    {
        private SOLID_D_IBD _bd;

        private SOLID_D_IReport _report;

        public SOLID_D(SOLID_D_IBD bd, SOLID_D_IReport report)
        {
            _bd = bd;
            _report = report;
        }

        public void AddRecordToBD(SOLID_S_Data record)
        {
            _bd.AddRecordToBD(record);
        }

        public bool CheckUser(string user, string password)
        {
            var list = _bd.GetFromBDRecords();
            foreach (var elem in list)
            {
                if (elem.UserName == user && elem.Passwrod == password)
                {
                    return true;
                }
            }
            return false;
        }

        public void CreateReport(string fileName)
        {
            _report.CreateReport(fileName);
        }
    }
}