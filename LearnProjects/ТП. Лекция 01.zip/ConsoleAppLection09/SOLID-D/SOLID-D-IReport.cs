﻿namespace ConsoleAppLection09
{
    interface SOLID_D_IReport
    {
        void CreateReport(string fileName);
    }
}