﻿using System.Collections.Generic;

namespace ConsoleAppLection09
{
    interface SOLID_D_IBD
    {
        void AddRecordToBD(SOLID_S_Data record);

        List<SOLID_S_Data> GetFromBDRecords();
    }
}