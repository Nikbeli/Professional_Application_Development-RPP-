﻿using System;

namespace ConsoleAppLection09
{
    class InversionControlDL
    {
        private readonly IInversionControlRepository _bd;

        private readonly IInversionControlReport _report;

        public InversionControlDL(IServiceProvider provider)
        {
            _bd = (IInversionControlRepository)provider.GetService(typeof(IInversionControlRepository));
            _report = (IInversionControlReport)provider.GetService(typeof(IInversionControlReport));
        }

        public void AddRecordToBD(SOLID_S_Data record)
        {
            _bd.AddRecordToBD(record);
        }

        public bool CheckUser(string user, string password)
        {
            var list = _bd.GetFromBDRecords();
            foreach (var elem in list)
            {
                if (elem.UserName == user && elem.Passwrod == password)
                {
                    return true;
                }
            }
            return false;
        }

        public void CreateReport(string fileName)
        {
            _report.CreateReport(fileName);
        }
    }
}