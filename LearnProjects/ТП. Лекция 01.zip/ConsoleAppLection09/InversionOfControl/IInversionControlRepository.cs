﻿using System.Collections.Generic;

namespace ConsoleAppLection09
{
    interface IInversionControlRepository
    {
        void AddRecordToBD(SOLID_S_Data record);

        List<SOLID_S_Data> GetFromBDRecords();
    }
}
