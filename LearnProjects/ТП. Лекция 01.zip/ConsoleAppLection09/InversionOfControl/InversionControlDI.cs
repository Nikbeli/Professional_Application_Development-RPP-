﻿namespace ConsoleAppLection09
{
    class InversionControlDI
    {
        private IInversionControlRepository _bd;

        private IInversionControlReport _report;

        public InversionControlDI(IInversionControlRepository bd, IInversionControlReport report)
        {
            _bd = bd;
            _report = report;
        }

        public IInversionControlRepository BD { set { _bd = value; } }

        public IInversionControlReport Report { set { _report = value; } }

        public void AddRecordToBD(IInversionControlRepository bd, SOLID_S_Data record)
        {
            bd.AddRecordToBD(record);
        }

        public bool CheckUser(string user, string password)
        {
            var list = _bd.GetFromBDRecords();
            foreach (var elem in list)
            {
                if (elem.UserName == user && elem.Passwrod == password)
                {
                    return true;
                }
            }
            return false;
        }

        public void CreateReport(string fileName)
        {
            _report.CreateReport(fileName);
        }
    }
}