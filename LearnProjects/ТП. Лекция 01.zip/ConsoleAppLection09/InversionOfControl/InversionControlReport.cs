﻿namespace ConsoleAppLection09
{
    class InversionControlReport : IInversionControlReport
    {
        public void CreateReport(string fileName)
        {
            if (string.IsNullOrEmpty(fileName))
            {
                return;
            }
        }
    }
}