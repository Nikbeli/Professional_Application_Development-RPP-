﻿namespace ConsoleAppLection09
{
    class NoInversionControl
    {
        private readonly InversionControlRepository _bd;

        private readonly InversionControlReport _report;

        public NoInversionControl()
        {
            _bd = new InversionControlRepository();
            _report = new InversionControlReport();
        }

        public void AddRecordToBD(SOLID_S_Data record)
        {
            _bd.AddRecordToBD(record);
        }

        public bool CheckUser(string user, string password)
        {
            var list = _bd.GetFromBDRecords();
            foreach (var elem in list)
            {
                if (elem.UserName == user && elem.Passwrod == password)
                {
                    return true;
                }
            }
            return false;
        }

        public void CreateReport(string fileName)
        {
            _report.CreateReport(fileName);
        }
    }
}