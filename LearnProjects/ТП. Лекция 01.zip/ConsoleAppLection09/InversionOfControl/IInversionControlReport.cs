﻿namespace ConsoleAppLection09
{
    interface IInversionControlReport
    {
        void CreateReport(string fileName);
    }
}