﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace ConsoleAppLection14
{
    class Program
    {
        public static void ThreadMethod()
        {
            for (int i = 0; i < 9; i++)
            {
                Console.WriteLine("Новый поток: {0}", i);
                Thread.Sleep(400);
            }
        }

        public static void ThreadMethodWithParam(object obj)
        {
            var x = (int)obj;
            for (int i = 0; i < 9; i++)
            {
                Console.WriteLine("Новый поток({1}): {0}", i * x, x);
                Thread.Sleep(400);
            }
        }

        public static int ThreadMethodReturnParam(object obj)
        {
            int x = (int)obj;
            for (int i = 0; i < 9; i++)
            {
                Console.WriteLine("Новый поток({1}): {0}", i * x, x);
                Thread.Sleep(400);
            }
            return x;
        }

        public static void ThreadMethodWithParamForPool(object obj)
        {
            var x = (int)obj;
            for (int i = 0; i < 9; i++)
            {
                Console.WriteLine("Новый пул поток({1}): {0}", i * x, x);
                Thread.Sleep(400);
            }
        }

        public static int Factorial(int x)
        {
            int result = 1;

            for (int i = 1; i <= x; i++)
            {
                result *= i;
                Console.WriteLine("Шаг {0}, Факториал = {1}", i, result);
                Thread.Sleep(150);
            }
            return result;
        }

        public static int NumberSum(int x)
        {
            int sum = 0;
            Console.WriteLine("Старт метода подсчета суммы");
            while (x > 0)
            {
                sum += x % 10;
                x /= 10;
            }
            return sum;
        }


        public static async void SimpleAsync()
        {
            Console.WriteLine("Вызвали");
            Thread.Sleep(1000);
            await Task.Run(() => { Console.WriteLine("Просто сообщение"); });
            Console.WriteLine("Отработали");
        }

        public static async Task TaskReturnAsync()
        {
            Console.WriteLine("Вызвали");
            Thread.Sleep(1000);
            await Task.Run(() => { Console.WriteLine("Просто сообщение"); });
            Console.WriteLine("Отработали");
        }

        public static async Task CallAnotherAsync()
        {
            //await SimpleAsync();

            await TaskReturnAsync();
        }

        public static Task<int> FactorialAsync(int x)
        {
            int result = 1;

            return Task.Run(() =>
            {
                for (int i = 1; i <= x; i++)
                {
                    result *= i;
                }
                return result;
            });
        }

        public static async void CallTaskAsync()
        {
            int num = 5;
            Console.WriteLine("Начинаем считать");

            int result = await FactorialAsync(num);

            Console.WriteLine("Факториал числа {0} равен {1}", num, result);
        }

        public static async Task<string> ReadFromFileAsync(string fileName)
        {
            if (!File.Exists(fileName))
            {
                return null;
            }
            using (var reader = new StreamReader(fileName))
            {
                var text = await reader.ReadToEndAsync();
                return text;
            }
        }


        private static readonly Random random = new Random();

        private static decimal balance;

        public static void Credit(decimal amount)
        {
            // иммитация начисления средств
            Thread.Sleep(random.Next(1, 5) * 100);
            balance += amount;
            Console.WriteLine("Оперция начисления, баланс: {0}", balance);
        }

        public static void Debit(decimal amount)
        {
            if (balance >= amount)
            {
                // иммитация списания средств
                Thread.Sleep(random.Next(1, 5) * 100);
                balance -= amount;
                Console.WriteLine("Оперция списания, баланс: {0}", balance);
            }
        }

        public static void ChangeBalance()
        {
            switch (random.Next(1, 3))
            {
                case 1:
                    Credit(random.Next(500, 5000));
                    break;
                case 2:
                    Debit(random.Next(500, 5000));
                    break;
            }
        }


        static readonly object locker = new object();

        public static void DebitWithLock(decimal amount)
        {
            lock (locker)
            {
                if (balance >= amount)
                {
                    // иммитация списания средств
                    Thread.Sleep(random.Next(1, 5) * 100);
                    balance -= amount;
                    Console.WriteLine("Оперция списания, баланс: {0}", balance);
                }
            }
        }

        public static void ChangeBalanceWithLock()
        {
            switch (random.Next(1, 3))
            {
                case 1:
                    Credit(random.Next(500, 5000));
                    break;
                case 2:
                    DebitWithLock(random.Next(500, 5000));
                    break;
            }
        }

        static readonly object lockerCredit = new object();

        static readonly object lockerDebit = new object();

        public static void CreditWithMonitor(decimal amount)
        {
            try
            {
                Monitor.Enter(lockerCredit);
                // иммитация начисления средств
                Thread.Sleep(random.Next(1, 5) * 100);
                balance += amount;
            }
            finally
            {
                Monitor.Exit(lockerCredit);
            }
            Console.WriteLine("Оперция начисления, баланс: {0}", balance);
        }

        public static void DebitWithMonitor(decimal amount)
        {
            try
            {
                if (balance >= amount)
                {
                    Monitor.Enter(lockerDebit);
                    // иммитация списания средств
                    Thread.Sleep(random.Next(1, 5) * 100);
                    balance -= amount;
                    Console.WriteLine("Оперция списания, баланс: {0}", balance);
                }
            }
            finally
            {
                Monitor.Exit(lockerDebit);
            }
        }

        public static void ChangeBalanceWithMonitor()
        {
            switch (random.Next(1, 3))
            {
                case 1:
                    CreditWithMonitor(random.Next(500, 5000));
                    break;
                case 2:
                    DebitWithMonitor(random.Next(500, 5000));
                    break;
            }
        }

        static readonly AutoResetEvent waitHandler = new AutoResetEvent(true);

        public static void CreditWithAutoResetEvent(decimal amount)
        {
            waitHandler.WaitOne();
            // иммитация начисления средств
            Thread.Sleep(random.Next(1, 5) * 100);
            balance += amount;
            waitHandler.Set();
            Console.WriteLine("Оперция начисления, баланс: {0}", balance);
        }

        public static void DebitWithAutoResetEvent(decimal amount)
        {
            waitHandler.WaitOne();
            if (balance >= amount)
            {
                // иммитация списания средств
                Thread.Sleep(random.Next(1, 5) * 100);
                balance -= amount;
                Console.WriteLine("Оперция списания, баланс: {0}", balance);
            }
            waitHandler.Set();
        }

        public static void ChangeBalanceWithAutoResetEvent()
        {
            switch (random.Next(1, 3))
            {
                case 1:
                    CreditWithAutoResetEvent(random.Next(500, 5000));
                    break;
                case 2:
                    DebitWithAutoResetEvent(random.Next(500, 5000));
                    break;
            }
        }

        static readonly Mutex mutexObj = new Mutex();

        public static void CreditWithMutex(decimal amount)
        {
            mutexObj.WaitOne();
            // иммитация начисления средств
            Thread.Sleep(random.Next(1, 5) * 100);
            balance += amount;
            mutexObj.ReleaseMutex();
            Console.WriteLine("Оперция начисления, баланс: {0}", balance);
        }

        public static void DebitWithMutex(decimal amount)
        {
            mutexObj.WaitOne();
            if (balance >= amount)
            {
                // иммитация списания средств
                Thread.Sleep(random.Next(1, 5) * 100);
                balance -= amount;
                Console.WriteLine("Оперция списания, баланс: {0}", balance);
            }
            mutexObj.ReleaseMutex();
        }

        public static void ChangeBalanceWithMutex()
        {
            switch (random.Next(1, 3))
            {
                case 1:
                    CreditWithMutex(random.Next(500, 5000));
                    break;
                case 2:
                    DebitWithMutex(random.Next(500, 5000));
                    break;
            }
        }


        public static int FactorialForParallel(int x)
        {
            int result = 1;
            for (int i = 1; i <= x; i++)
            {
                result *= i;
            }
            Console.WriteLine("Факториал числа {0} равен {1}", x, result);
            return result;
        }

        static void Main(string[] args)
        {
            Console.WriteLine();

            #region Call Method

            //var myThread = new Thread(new ThreadStart(ThreadMethod));
            //myThread.Start();

            //for (int i = 0; i < 9; i++)
            //{
            //    Console.WriteLine("Главный поток: {0}", i * i);
            //    Thread.Sleep(300);
            //}

            #endregion

            #region Call Method With Param

            //int num = 4;
            //var myThreadWith = new Thread(new ParameterizedThreadStart(ThreadMethodWithParam));
            //myThreadWith.Start(num);

            //for (int i = 1; i < 9; i++)
            //{
            //    Console.WriteLine("Главный поток: {0}", i * i);
            //    Thread.Sleep(300);
            //}

            #endregion

            #region Call Method Return Param

            //int numVal = 4;
            //var myThreadReturn = new Thread(new ParameterizedThreadStart(ThreadMethodReturnParam));
            //myThreadReturn.Start(numVal);

            //for (int i = 1; i < 9; i++)
            //{
            //    Console.WriteLine("Главный поток: {0}", i * i);
            //    Thread.Sleep(300);
            //}

            #endregion

            #region Call Method From TheardPool

            //ThreadPool.QueueUserWorkItem(ThreadMethodWithParamForPool, 4);
            //for (int i = 0; i < 9; i++)
            //{
            //    Console.WriteLine("Главный поток: {0}", i * i);
            //    Thread.Sleep(300);
            //}

            #endregion

            #region Task

            //var taskRun = Task.Run(() => Console.WriteLine("Hello Task!"));

            //var taskRunMethod = Task.Run(ThreadMethod);

            //var taskFact = Task.Factory.StartNew(() => Console.WriteLine("Hello Task!"));

            //var taskFactMethod = Task.Factory.StartNew(ThreadMethod);

            #endregion

            #region Task Run from Start

            //var task = new Task(() => Console.WriteLine("Hello Task!"));
            //var taskMethod = new Task(() => ThreadMethod());
            //Console.WriteLine("Запустить методы на выполнение?");
            //if (Console.ReadLine() == "yes")
            //{
            //    task.Start();
            //    taskMethod.Start();
            //}

            #endregion

            #region Task

            //var taskMethod = new Task(() => ThreadMethod());
            //Console.WriteLine("Запустить методы синхронно?");
            //if (Console.ReadLine() == "yes")
            //{
            //    taskMethod.RunSynchronously();
            //}
            //else
            //{
            //    taskMethod.Start();
            //}
            //Console.WriteLine("Метод запущен");

            #endregion

            #region Task Return Val

            //var taskReturn = Task.Run(() => Factorial(5));
            //Thread.Sleep(500);
            //Console.WriteLine("Подождем расчета");
            //int res = taskReturn.Result;
            //Console.WriteLine("Факториал от 5 = " + res);

            #endregion

            #region Task Wait

            //var taskWait = Task.Run(() =>
            //{
            //    int x = Factorial(10); 
            //    Console.WriteLine("Факториал от 10 = {0}", x);
            //});
            //Thread.Sleep(500);
            //Console.WriteLine("Подождем расчета");
            //taskWait.Wait();
            //Console.WriteLine("Завершение метода Main");

            #endregion

            #region Task WaitAny/All

            //var tasks = new Task[5];
            //for (int i = 0; i < tasks.Length; i++)
            //{
            //    int fact = 10 - i;
            //    tasks[i] = Task.Run(() => Factorial(fact));
            //}
            //int index = Task.WaitAny(tasks);
            //Console.WriteLine("Завершился поток {0} (№{1}).", tasks[index].Id, index);
            //Task.WaitAll(tasks);
            //Console.WriteLine("Завершились все потоки");

            #endregion

            #region Task Call After

            //var taskFirst = Task.Run(() => Factorial(10));
            //var taskSecond = taskFirst.ContinueWith(x => NumberSum(x.Result));
            //Console.WriteLine("Задачи запущены");
            //Console.WriteLine("Сумма чисел факториала числа {0}", taskSecond.Result);

            #endregion

            #region Task Cancel

            //var cancelTokenSource = new CancellationTokenSource();
            //var token = cancelTokenSource.Token;
            //int number = 6;

            //var taskCancel = Task.Run(() =>
            //{
            //    int result = 1;
            //    for (int i = 1; i <= number; i++)
            //    {
            //        if (token.IsCancellationRequested)
            //        {
            //            Console.WriteLine("Операция прервана");
            //            return;
            //        }

            //        result *= i;
            //        Console.WriteLine("Факториал числа {0} равен {1}", i, result);
            //        Thread.Sleep(1500);
            //    }
            //});

            //Console.WriteLine("Введите Y для отмены операции или другой символ для ее продолжения:");
            //if (Console.ReadLine() == "y")
            //{
            //    cancelTokenSource.Cancel();
            //}

            #endregion

            #region Task Error

            //var taskSimpleError = Task.Run(() => { Thread.Sleep(1000); throw new Exception("Случилась ошибка"); });
            //while (!taskSimpleError.IsCompleted) { }
            //if (taskSimpleError.Status == TaskStatus.Faulted)
            //{
            //    foreach (var e in taskSimpleError.Exception.InnerExceptions)
            //    {
            //        Console.WriteLine("Ошибка: {0}", e.Message);
            //    }
            //}

            //taskSimpleError = Task.Run(() => { Thread.Sleep(1000); throw new Exception("Случилась ошибка, снова"); });
            //try
            //{
            //    taskSimpleError.Wait();
            //}
            //catch (AggregateException ae)
            //{
            //    foreach (var e in ae.InnerExceptions)
            //    {
            //        Console.WriteLine("Ошибка: {0}", e.Message);
            //    }
            //}

            #endregion

            #region async/await noreturn async

            //Console.WriteLine("До вызова");
            //SimpleAsync();
            //Console.WriteLine("После вызова");

            #endregion

            #region async/await return val

            //Console.WriteLine("До вызова");
            //CallTaskAsync();
            //Console.WriteLine("После вызова");

            //Console.WriteLine("Прямой вызов");
            //Console.WriteLine("Факториал 5 = {0}", FactorialAsync(5).Result);
            //Console.WriteLine("Окончание");

            #endregion

            balance = 0;
            var tasks = new Task[100];

            #region Call Method Without Lock

            //for (int i = 0; i < tasks.Length; i++)
            //{
            //    tasks[i] = Task.Run(() => ChangeBalance());
            //}
            //Task.WaitAll(tasks);
            //Console.WriteLine($"Итоговый баланс {balance}");

            #endregion

            #region Call Method With Lock

            //for (int i = 0; i < tasks.Length; i++)
            //{
            //    tasks[i] = Task.Run(() => ChangeBalanceWithLock());
            //}
            //Task.WaitAll(tasks);
            //Console.WriteLine($"Итоговый баланс {balance}");

            #endregion

            #region Call Method With Monitor

            //for (int i = 0; i < tasks.Length; i++)
            //{
            //    tasks[i] = Task.Run(() => ChangeBalanceWithMonitor());
            //}
            //Task.WaitAll(tasks);
            //Console.WriteLine($"Итоговый баланс {balance}");

            #endregion

            #region Call Method With AutoResetEvent

            //for (int i = 0; i < tasks.Length; i++)
            //{
            //    tasks[i] = Task.Run(() => ChangeBalanceWithAutoResetEvent());
            //}
            //Task.WaitAll(tasks);
            //Console.WriteLine($"Итоговый баланс {balance}");

            #endregion

            #region Call Method With Mutex

            //for (int i = 0; i < tasks.Length; i++)
            //{
            //    tasks[i] = Task.Run(() => ChangeBalanceWithMutex());
            //}
            //Task.WaitAll(tasks);
            //Console.WriteLine($"Итоговый баланс {balance}");

            #endregion

            #region Call Method With Semathor

            //var exam = new Examenation();
            //exam.StartExam();

            #endregion

            #region Call Semathor
            for (int i = 0; i < 10; i++)
            {
                // Console.WriteLine("Студент " + i);
                // Student student = new Student(i);
            }
            #endregion

            #region Parallel LINQ

            //int[] numbers = new int[] { 1, 2, 3, 4, 5, 6, 7, 8, };
            //var factorials = from n in numbers.AsParallel()
            //                 select FactorialForParallel(n);
            //foreach (var elem in factorials)
            //{
            //    Console.Write("{0}, ", elem);
            //}

            //Console.WriteLine();
            //Console.WriteLine();

            //numbers.AsParallel()
            //    .Select(x => FactorialForParallel(x))
            //    .ForAll(n => Console.Write("{0}, ", n));

            //Console.WriteLine();
            //Console.WriteLine();

            //numbers.AsParallel().ForAll(x => x = FactorialForParallel(x));
            //foreach (var elem in numbers)
            //{
            //    Console.Write("{0}, ", elem);
            //}

            //Console.WriteLine();
            //Console.WriteLine();

            //numbers = new int[] { 1, 2, 3, 5, 6, 7, 4, 8, };
            //var orderFactorials = numbers.AsParallel().AsOrdered()
            //    .Select(x => FactorialForParallel(x));
            //foreach (var elem in orderFactorials)
            //{
            //    Console.Write("{0}, ", elem);
            //}

            #endregion

            #region ConcurrentBag

            //var cb = new ConcurrentBag<int>();
            //var bagAddTasks = new Task[10];
            //for (int i = 0; i < 10; i++)
            //{
            //    var numberToAdd = i;
            //    bagAddTasks[i] = Task.Run(() => cb.Add(numberToAdd));
            //}
            //Task.WaitAll(bagAddTasks);
            //foreach (var elem in cb)
            //{
            //    Console.Write("{0}, ", elem);
            //}
            //Console.WriteLine();
            //int itemsInBag = 0;
            //while (!cb.IsEmpty)
            //{
            //    if (cb.TryTake(out int item))
            //    {
            //        Console.Write("{0}, ", item);
            //        itemsInBag++;
            //    }
            //}
            //Console.WriteLine();
            //Console.WriteLine("Извлечено {0} записей", itemsInBag);

            #endregion

            #region ConcurrentQueue

            //var cq = new ConcurrentQueue<int>();
            //var bagAddTasks = new Task[10];
            //for (int i = 0; i < 10; i++)
            //{
            //    var numberToAdd = i;
            //    bagAddTasks[i] = Task.Run(() => cq.Enqueue(numberToAdd));
            //}
            //Task.WaitAll(bagAddTasks);
            //foreach (var elem in cq)
            //{
            //    Console.Write("{0}, ", elem);
            //}
            //Console.WriteLine();
            //int itemsInBag = 0;
            //while (!cq.IsEmpty)
            //{
            //    if (cq.TryDequeue(out int item))
            //    {
            //        Console.Write("{0}, ", item);
            //        itemsInBag++;
            //    }
            //}
            //Console.WriteLine();
            //Console.WriteLine("Извлечено {0} записей", itemsInBag);

            #endregion

            #region ConcurrentStack

            //var cs = new ConcurrentStack<int>();
            //for (int i = 0; i < 5; i++)
            //{
            //    cs.Push(i);
            //}
            //cs.PushRange(new int[] { 1, 2, 3, 4, 5, 6, 7, 8 }, 3, 4);
            //foreach (var elem in cs)
            //{
            //    Console.Write("{0}, ", elem);
            //}
            //Console.WriteLine();
            //var mas = new int[5];
            //int itemsInBag = cs.TryPopRange(mas, 1, 3);
            //Console.WriteLine("Извлечено {0} записей", itemsInBag);
            //foreach (var elem in mas)
            //{
            //    Console.Write("{0}, ", elem);
            //}
            //Console.WriteLine();
            //while (!cs.IsEmpty)
            //{
            //    if (cs.TryPop(out int item))
            //    {
            //        Console.Write("{0}, ", item);
            //        itemsInBag++;
            //    }
            //}

            #endregion

            #region ConcurrentDictionary

            //var cd = new ConcurrentDictionary<int, string>();
            //for (int i = 0; i < 5; ++i)
            //{
            //    var key = random.Next(0, 10);
            //    Console.Write("Добавляем ключ {0}. ", key);
            //    if (cd.TryAdd(key, $"Запись №{key}"))
            //    {
            //        Console.WriteLine("Запись добавлена");
            //    }
            //}
            //Console.WriteLine();
            //for (int i = 0; i < 5; ++i)
            //{
            //    var key = random.Next(0, 10);
            //    Console.Write("Ключ {0}. ", key);
            //    if (cd.TryUpdate(key, $"Запись №{key} обновлена", $"Запись №{key}"))
            //    {
            //        Console.WriteLine("Запись обновлена");
            //    }
            //}
            //Console.WriteLine();
            //for (int i = 0; i < 5; ++i)
            //{
            //    var key = random.Next(0, 10);
            //    Console.Write("Ключ {0}. ", key);
            //    if (cd.TryRemove(key, out string value))
            //    {
            //        Console.WriteLine("Запись {0} удалена", value);
            //    }
            //}
            //Console.WriteLine();
            //for (int i = 0; i < 5; ++i)
            //{
            //    var index = random.Next(0, 10);
            //    Console.Write("Ключ {0}. ", index);
            //    Console.WriteLine("Значение {0}", 
            //        cd.AddOrUpdate(index, $"Запись №{index}", (key, oldValue) => $"Запись №{key} обновлена"));
            //}
            //Console.WriteLine();
            //for (int i = 0; i < 5; ++i)
            //{
            //    var index = random.Next(0, 10);
            //    Console.Write("Ключ {0}. ", index);
            //    Console.WriteLine("Значение {0}",
            //        cd.GetOrAdd(index, (key) => $"Запись №{key}"));
            //}

            #endregion

            Console.ReadKey();
        }
    }
}
