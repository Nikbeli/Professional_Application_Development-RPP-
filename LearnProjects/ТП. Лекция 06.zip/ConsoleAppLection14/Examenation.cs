﻿using System;
using System.Threading;
using System.Threading.Tasks;

namespace ConsoleAppLection14
{
    class Examenation
    {
        private readonly Semaphore sem = new Semaphore(3, 10);

        private readonly Random rnd = new Random();

        public void StartExam()
        {
            var students = new Task[20];
            for (int i = 0; i < students.Length; i++)
            {
                string name = $"Студент {i}";
                students[i] = Task.Run(() => { Exam(name); });
            }
            Task.WaitAll(students);
            Console.WriteLine("Экзамен завершен");
        }

        private void Exam(string studentName)
        {
            int countTry = 3;
            while (countTry > 0)
            {
                sem.WaitOne();
                Console.WriteLine("{0} приходит на экзамен", studentName);
                Console.WriteLine("{0} сдает экзамен", studentName);
                Thread.Sleep(1000);
                var flag = Convert.ToBoolean(rnd.Next(0, 2));
                if (flag)
                {
                    Console.WriteLine("{0} сдал экзамен", studentName);
                    sem.Release();
                    return;
                }
                else
                {
                    Console.WriteLine("{0} на пересдачу", studentName);
                }
                sem.Release();
                countTry--;
                Thread.Sleep(1000);
            }
            Console.WriteLine("{0} отчислен", studentName);
        }
    }
}