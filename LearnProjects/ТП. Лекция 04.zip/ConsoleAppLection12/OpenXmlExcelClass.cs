﻿using DocumentFormat.OpenXml;
using DocumentFormat.OpenXml.Drawing.Charts;
using DocumentFormat.OpenXml.Drawing.Spreadsheet;
using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml.Spreadsheet;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleAppLection12
{
    class OpenXmlExcelClass : AbstractExcelClass
    {
        SpreadsheetDocument spreadsheetDocument;
        WorkbookPart workbookpart;
        WorksheetPart worksheetPart;
        SheetData sheetData;
        MergeCells mergeCells;

        protected override void CreateDoc(string fileName)
        {
            spreadsheetDocument = SpreadsheetDocument.Create(fileName, SpreadsheetDocumentType.Workbook);
            workbookpart = spreadsheetDocument.AddWorkbookPart();
            GenerateStyle(workbookpart);
            workbookpart.Workbook = new Workbook();
            worksheetPart = workbookpart.AddNewPart<WorksheetPart>();
            worksheetPart.Worksheet = new Worksheet();
            var columns = new Columns();
            columns.Append(new Column
            {
                Min = 1,
                Max = 4,
                Width = 8,
                CustomWidth = true
            });
            worksheetPart.Worksheet.Append(columns);
            sheetData = new SheetData();
            worksheetPart.Worksheet.Append(sheetData);
            var sheets = spreadsheetDocument.WorkbookPart.Workbook.AppendChild(new Sheets());
            var sheet = new Sheet()
            {
                Id = spreadsheetDocument.WorkbookPart.GetIdOfPart(worksheetPart),
                SheetId = 1,
                Name = "Лист 1"
            };
            sheets.Append(sheet);
        }

        protected override void AddHeader(string text)
        {
            var row = new Row() { RowIndex = 1, Height = 24, CustomHeight = true };
            sheetData.Append(row);
            Cell newCell = new Cell() { CellReference = "A1" };
            row.InsertBefore(newCell, null);
            var run = new Run();
            run.Append(new Text(text));
            var inlineString = new InlineString();
            inlineString.Append(run);
            newCell.Append(inlineString);
            newCell.DataType = CellValues.InlineString;
            newCell.StyleIndex = 1;
            mergeCells = new MergeCells();
            mergeCells.Append(new MergeCell() { Reference = new StringValue("A1:D1") });
        }

        protected override void AddData((string Header, int[] Values)[] data)
        {
            char[] symbols = new char[] { 'A', 'B', 'C', 'D' };
            for (int i = 0; i < data.Length; ++i)
            {
                var row = new Row() { RowIndex = (uint)i + 2, Height = 24, CustomHeight = true };
                sheetData.Append(row);
                Cell newCell = new Cell() { CellReference = $"A{i + 2}" };
                row.InsertBefore(newCell, null);
                var run = new Run();
                run.Append(new Text(data[i].Header));
                var inlineString = new InlineString();
                inlineString.Append(run);
                newCell.Append(inlineString);
                newCell.DataType = CellValues.InlineString;
                newCell.StyleIndex = 1;
                for (int j = 0; j < data[i].Values.Length; ++j)
                {
                    newCell = new Cell() { CellReference = $"{symbols[j + 1]}{i + 2}" };
                    row.InsertBefore(newCell, null);
                    run = new Run();
                    run.Append(new Text(data[i].Values[j].ToString()));
                    inlineString = new InlineString();
                    inlineString.Append(run);
                    newCell.Append(inlineString);
                    newCell.DataType = CellValues.InlineString;
                    newCell.StyleIndex = 2;
                }
            }
        }

        protected override void AddChart(string titleText, int countRecords)
        {
            DrawingsPart drawingsPart = worksheetPart.AddNewPart<DrawingsPart>();
            worksheetPart.Worksheet.Append(new Drawing() { Id = worksheetPart.GetIdOfPart(drawingsPart) });
            worksheetPart.Worksheet.Save();
            ChartPart chartPart = drawingsPart.AddNewPart<ChartPart>();
            chartPart.ChartSpace = new ChartSpace();
            chartPart.ChartSpace.Append(new EditingLanguage() { Val = new StringValue("en-US") });
            var axisIdDate = new AxisId() { Val = 132034944U };
            var axisIdValue = new AxisId() { Val = 132036480U };
            var lineChart = new LineChart();
            lineChart.Append(new Grouping() { Val = GroupingValues.Standard });
            char[] symbols = new char[] { 'A', 'B', 'C', 'D' };
            for (uint i = 0; i < countRecords; ++i)
            {
                var marker = new Marker();
                marker.Append(new Symbol() { Val = MarkerStyleValues.None });
                var lineChartSeries = new LineChartSeries();
                lineChartSeries.Append(new Index() { Val = i + 1 });
                lineChartSeries.Append(new Order() { Val = i });
                var stringPoint = new StringPoint() { Index = 0U };
                var seriesName = worksheetPart.Worksheet.Descendants<Cell>().Where(c => c.CellReference == $"A{i + 2}").FirstOrDefault()?.InnerText;
                stringPoint.Append(new NumericValue { Text = seriesName });
                var stringCache = new StringCache();
                stringCache.Append(new PointCount() { Val = 1U });
                stringCache.Append(stringPoint);
                var stringReference = new StringReference();
                stringReference.Append(stringCache);
                var seriesText = new SeriesText();
                seriesText.Append(stringReference);
                lineChartSeries.Append(seriesText);
                lineChartSeries.Append(new Marker());
                uint numPoints = 3;
                var numberingCache = new NumberingCache();
                numberingCache.Append(new FormatCode { Text = "General" });
                numberingCache.Append(new PointCount() { Val = numPoints });
                for (uint j = 0U; j < numPoints; j++)
                {
                    var numericPoint = new NumericPoint() { Index = j };
                    numericPoint.Append(new NumericValue { Text = $"{j + 1}" });
                    numberingCache.Append(numericPoint);
                }
                var numberReference = new NumberReference();
                numberReference.Append(numberingCache);
                var categoryAxisData = new CategoryAxisData();
                categoryAxisData.Append(numberReference);
                lineChartSeries.Append(categoryAxisData);
                numberingCache = new NumberingCache();
                numberingCache.Append(new FormatCode { Text = "General" });
                numberingCache.Append(new PointCount() { Val = numPoints });
                for (uint j = 0U; j < numPoints; j++)
                {
                    var numericPoint = new NumericPoint() { Index = j };
                    var val = worksheetPart.Worksheet.Descendants<Cell>()
                        .Where(c => c.CellReference == $"{symbols[j + 1]}{i + 2}").FirstOrDefault()?.InnerText;
                    numericPoint.Append(new NumericValue { Text = val });
                    numberingCache.Append(numericPoint);
                }
                numberReference = new NumberReference();
                numberReference.Append(numberingCache);
                var values = new DocumentFormat.OpenXml.Drawing.Charts.Values();
                values.Append(numberReference);
                lineChartSeries.Append(values);
                lineChart.Append(lineChartSeries);
            }
            lineChart.Append(new ShowMarker() { Val = true });
            lineChart.Append(axisIdDate);
            lineChart.Append(axisIdValue);
            var plotArea = new PlotArea();
            plotArea.Append(new Layout());
            plotArea.Append(lineChart);
            var scaling = new Scaling();
            scaling.Append(new Orientation() { Val = DocumentFormat.OpenXml.Drawing.Charts.OrientationValues.MinMax });
            var paragraphProperties = new DocumentFormat.OpenXml.Drawing.ParagraphProperties();
            paragraphProperties.Append(new DocumentFormat.OpenXml.Drawing.DefaultRunProperties());
            var paragraph = new DocumentFormat.OpenXml.Drawing.Paragraph();
            paragraph.Append(paragraphProperties);
            paragraph.Append(new DocumentFormat.OpenXml.Drawing.EndParagraphRunProperties());
            var textProperties = new DocumentFormat.OpenXml.Drawing.Charts.TextProperties();
            textProperties.Append(new DocumentFormat.OpenXml.Drawing.BodyProperties() { 
                Rotation = -5400000, Vertical = DocumentFormat.OpenXml.Drawing.TextVerticalValues.Vertical });
            textProperties.Append(new DocumentFormat.OpenXml.Drawing.ListStyle());
            textProperties.Append(paragraph);
            var dateAxis = new DateAxis();
            dateAxis.Append(new AxisId() { Val = axisIdDate.Val });
            dateAxis.Append(scaling);
            dateAxis.Append(new Delete() { Val = false });
            dateAxis.Append(new AxisPosition() { Val = AxisPositionValues.Bottom });
            dateAxis.Append(new DocumentFormat.OpenXml.Drawing.Charts.NumberingFormat() { FormatCode = "General", SourceLinked = true });
            dateAxis.Append(new MajorTickMark() { Val = TickMarkValues.None });
            dateAxis.Append(new TickLabelPosition() { Val = TickLabelPositionValues.Low });
            dateAxis.Append(textProperties);
            dateAxis.Append(new CrossingAxis() { Val = axisIdValue.Val });
            dateAxis.Append(new Crosses() { Val = CrossesValues.AutoZero });
            dateAxis.Append(new AutoLabeled() { Val = true });
            dateAxis.Append(new LabelOffset() { Val = (UInt16Value)100U });
            plotArea.Append(dateAxis);
            scaling = new Scaling();
            scaling.Append(new Orientation() { Val = DocumentFormat.OpenXml.Drawing.Charts.OrientationValues.MinMax });
            paragraphProperties = new DocumentFormat.OpenXml.Drawing.ParagraphProperties();
            paragraphProperties.Append(new DocumentFormat.OpenXml.Drawing.DefaultRunProperties());
            paragraph = new DocumentFormat.OpenXml.Drawing.Paragraph();
            paragraph.Append(paragraphProperties);
            paragraph.Append(new DocumentFormat.OpenXml.Drawing.EndParagraphRunProperties());
            textProperties = new DocumentFormat.OpenXml.Drawing.Charts.TextProperties();
            textProperties.Append(new DocumentFormat.OpenXml.Drawing.BodyProperties() {
                Rotation = -5400000, Vertical = DocumentFormat.OpenXml.Drawing.TextVerticalValues.Vertical });
            textProperties.Append(new DocumentFormat.OpenXml.Drawing.ListStyle());
            textProperties.Append(paragraph);
            var valueAxis = new ValueAxis();
            valueAxis.Append(new AxisId() { Val = axisIdValue.Val });
            valueAxis.Append(scaling);
            valueAxis.Append(new Delete() { Val = false });
            valueAxis.Append(new AxisPosition() { Val = AxisPositionValues.Left });
            valueAxis.Append(new MajorGridlines());
            valueAxis.Append(new DocumentFormat.OpenXml.Drawing.Charts.NumberingFormat() { FormatCode = "General", SourceLinked = false });
            valueAxis.Append(new MajorTickMark() { Val = TickMarkValues.None });
            valueAxis.Append(new TickLabelPosition() { Val = TickLabelPositionValues.NextTo });
            var solidFill = new DocumentFormat.OpenXml.Drawing.SolidFill();
            solidFill.Append(new DocumentFormat.OpenXml.Drawing.RgbColorModelHex() { Val = "000000" });
            var outline = new DocumentFormat.OpenXml.Drawing.Outline() { Width = 9525 };            
            outline.Append(solidFill);
            outline.Append(new DocumentFormat.OpenXml.Drawing.PresetDash() { Val = DocumentFormat.OpenXml.Drawing.PresetLineDashValues.Solid });
            var chartShapeProperties = new ChartShapeProperties();
            chartShapeProperties.Append(outline);
            valueAxis.Append(chartShapeProperties);
            valueAxis.Append(textProperties);
            valueAxis.Append(new CrossingAxis() { Val = axisIdDate.Val });
            valueAxis.Append(new Crosses() { Val = CrossesValues.AutoZero });
            valueAxis.Append(new CrossBetween() { Val = CrossBetweenValues.Between });
            plotArea.Append(valueAxis);
            var chart = new Chart();
            var run = new DocumentFormat.OpenXml.Drawing.Run();
            run.Append(new DocumentFormat.OpenXml.Drawing.RunProperties() { FontSize = 1100 });
            run.Append(new DocumentFormat.OpenXml.Drawing.Text(titleText));
            paragraphProperties = new DocumentFormat.OpenXml.Drawing.ParagraphProperties();
            paragraphProperties.Append(new DocumentFormat.OpenXml.Drawing.DefaultRunProperties() { FontSize = 1100 });
            paragraph = new DocumentFormat.OpenXml.Drawing.Paragraph();
            paragraph.Append(paragraphProperties);
            paragraph.Append(run);
            var richText = new RichText();
            richText.Append(new DocumentFormat.OpenXml.Drawing.BodyProperties());
            richText.Append(new DocumentFormat.OpenXml.Drawing.ListStyle());
            richText.Append(paragraph);
            var chartText = new ChartText();
            chartText.Append(richText);
            var title = new Title();
            title.Append(chartText);
            title.Append(new Layout());
            title.Append(new Overlay() { Val = false });
            chart.Append(title);
            LegendPositionValues position = LegendPositionValues.Right;
            chart.Append(plotArea);
            paragraphProperties = new DocumentFormat.OpenXml.Drawing.ParagraphProperties();
            paragraphProperties.Append(new DocumentFormat.OpenXml.Drawing.DefaultRunProperties());
            paragraph = new DocumentFormat.OpenXml.Drawing.Paragraph();
            paragraph.Append(paragraphProperties);
            paragraph.Append(new DocumentFormat.OpenXml.Drawing.EndParagraphRunProperties());
            textProperties = new DocumentFormat.OpenXml.Drawing.Charts.TextProperties();
            textProperties.Append(new DocumentFormat.OpenXml.Drawing.BodyProperties());
            textProperties.Append(new DocumentFormat.OpenXml.Drawing.ListStyle());
            textProperties.Append(paragraph);
            var legend = new Legend();
            legend.Append(new LegendPosition() { Val = position });
            legend.Append(new Layout());
            legend.Append(new Overlay() { Val = false });
            legend.Append(textProperties);
            chart.Append(legend);
            chart.Append(new PlotVisibleOnly() { Val = true });
            chartPart.ChartSpace.AppendChild(chart);
            chartPart.ChartSpace.Save();
            drawingsPart.WorksheetDrawing = new WorksheetDrawing();
            var twoCellAnchor = drawingsPart.WorksheetDrawing.AppendChild(new TwoCellAnchor());
            twoCellAnchor.Append(new DocumentFormat.OpenXml.Drawing.Spreadsheet.FromMarker(new ColumnId("5"),
                new ColumnOffset("0"),
                new RowId("0"),
                new RowOffset("0")));
            twoCellAnchor.Append(new DocumentFormat.OpenXml.Drawing.Spreadsheet.ToMarker(new ColumnId("12"),
                new ColumnOffset("0"),
                new RowId("19"),
                new RowOffset("0")));
            var graphicFrame = twoCellAnchor.AppendChild(new GraphicFrame());
            graphicFrame.Macro = "";
            graphicFrame.Append(new NonVisualGraphicFrameProperties(
                new NonVisualDrawingProperties()
                {
                    Id = new UInt32Value(2u),
                    Name = "Chart 1"
                }, new NonVisualGraphicFrameDrawingProperties()));
            graphicFrame.Append(new Transform(new DocumentFormat.OpenXml.Drawing.Offset() { X = 0L, Y = 0L },
                                new DocumentFormat.OpenXml.Drawing.Extents() { Cx = 0L, Cy = 0L }));
            graphicFrame.Append(new DocumentFormat.OpenXml.Drawing.Graphic(new
                DocumentFormat.OpenXml.Drawing.GraphicData(new ChartReference() { Id = drawingsPart.GetIdOfPart(chartPart) })
            { Uri = "http://schemas.openxmlformats.org/drawingml/2006/chart" }));
            twoCellAnchor.Append(new ClientData());
            drawingsPart.WorksheetDrawing.Save();
        }

        protected override void SaveDoc(string fileName)
        {
            worksheetPart.Worksheet.InsertAfter(mergeCells, worksheetPart.Worksheet.Elements<SheetData>().First());
            worksheetPart.Worksheet.Save();
            workbookpart.Workbook.Save();
            spreadsheetDocument.Close();
        }

        /// <summary>
        /// Генерация стилей для книги
        /// </summary>
        /// <param name="workbookPart"></param>
        private void GenerateStyle(WorkbookPart workbookPart)
        {
            var workbookStylesPart = workbookPart.AddNewPart<WorkbookStylesPart>();
            workbookStylesPart.Stylesheet = new Stylesheet();

            var fonts = new Fonts() { Count = 2, KnownFonts = BooleanValue.FromBoolean(true) };
            fonts.Append(new Font
            {
                FontSize = new FontSize() { Val = 14 },
                FontName = new FontName() { Val = "Times New Roman" },
                FontFamilyNumbering = new FontFamilyNumbering() { Val = 1 },
                FontCharSet = new FontCharSet() { Val = 204 },
                Color = new Color() { Theme = 1 },
                Bold = new Bold()
            });
            fonts.Append(new Font
            {
                FontSize = new FontSize() { Val = 14 },
                FontName = new FontName() { Val = "Times New Roman" },
                FontFamilyNumbering = new FontFamilyNumbering() { Val = 1 },
                FontCharSet = new FontCharSet() { Val = 204 },
                Color = new Color() { Theme = 1 },
            });
            workbookStylesPart.Stylesheet.Append(fonts);
            var fills = new Fills() { Count = 1 };
            fills.Append(new Fill
            {
                PatternFill = new PatternFill() { PatternType = new EnumValue<PatternValues>(PatternValues.None) }
            });
            workbookStylesPart.Stylesheet.Append(fills);
            var borders = new Borders() { Count = 2 };
            borders.Append(new Border
            {
                LeftBorder = new LeftBorder(),
                RightBorder = new RightBorder(),
                TopBorder = new TopBorder(),
                BottomBorder = new BottomBorder(),
                DiagonalBorder = new DiagonalBorder()
            });
            borders.Append(new Border
            {
                LeftBorder = new LeftBorder() { Style = BorderStyleValues.Thin },
                RightBorder = new RightBorder() { Style = BorderStyleValues.Thin },
                TopBorder = new TopBorder() { Style = BorderStyleValues.Thin },
                BottomBorder = new BottomBorder() { Style = BorderStyleValues.Thin }
            });
            workbookStylesPart.Stylesheet.Append(borders);
            var cellFormats = new CellFormats() { Count = 3 };
            cellFormats.Append(new CellFormat
            {
                NumberFormatId = 0,
                FormatId = 0,
                FontId = 0,
                BorderId = 0,
                FillId = 0,
                Alignment = new Alignment() { Horizontal = HorizontalAlignmentValues.Center, Vertical = VerticalAlignmentValues.Center }
            });
            cellFormats.Append(new CellFormat
            {
                NumberFormatId = 0,
                FormatId = 0,
                FontId = 0,
                BorderId = 1,
                FillId = 0,
                Alignment = new Alignment() { Horizontal = HorizontalAlignmentValues.Center, Vertical = VerticalAlignmentValues.Center }
            });
            cellFormats.Append(new CellFormat
            {
                NumberFormatId = 0,
                FormatId = 0,
                FontId = 1,
                BorderId = 1,
                FillId = 0,
                Alignment = new Alignment() { Horizontal = HorizontalAlignmentValues.Center, Vertical = VerticalAlignmentValues.Center }
            });
            workbookStylesPart.Stylesheet.Append(cellFormats);
        }
    }
}