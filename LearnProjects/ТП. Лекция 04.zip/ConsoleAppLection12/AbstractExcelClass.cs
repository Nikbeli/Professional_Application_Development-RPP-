﻿namespace ConsoleAppLection12
{
    abstract class AbstractExcelClass
    {
        public void CreateReport(string fileName)
        {
            CreateDoc(fileName);

            AddHeader("Заголовок");

            AddData(new (string Header, int[] Values)[]
            {
                ( "Строка 1", new int[] { 4, 5, 2 } ),
                ( "Строка 2", new int[] { 2, 7, 4 } )
            });

            AddChart("Диаграмма", 2);

            SaveDoc(fileName);
        }

        protected abstract void CreateDoc(string fileName);

        protected abstract void AddHeader(string text);

        protected abstract void AddData((string Header, int[] Values)[] data);

        protected abstract void AddChart(string title, int countRecords);

        protected abstract void SaveDoc(string fileName);
    }
}