﻿using Microsoft.Office.Interop.Excel;
using System;

namespace ConsoleAppLection12
{
    class InteropExcelClass : AbstractExcelClass
    {
        Application excelApp;

        Workbook workbook;

        Worksheet worksheet;

        protected override void CreateDoc(string fileName)
        {
            excelApp = new Application { SheetsInNewWorkbook = 1 };
            workbook = excelApp.Workbooks.Add(Type.Missing);
            worksheet = (Worksheet)workbook.Worksheets.get_Item(1);
        }

        protected override void AddHeader(string text)
        {
            var excelcells = worksheet.get_Range("A1", "D1");
            excelcells.Merge(Type.Missing);
            excelcells.Font.Bold = true;
            excelcells.Font.Size = 14;
            excelcells.Font.Name = "Times New Roman";
            excelcells.ColumnWidth = 8;
            excelcells.RowHeight = 25;
            excelcells.HorizontalAlignment = Constants.xlCenter;
            excelcells.VerticalAlignment = Constants.xlCenter;
            excelcells.Value2 = text;
        }

        protected override void AddData((string Header, int[] Values)[] data)
        {
            char[] symbols = new char[] { 'A', 'B', 'C', 'D' };
            for (int i = 0; i < data.Length; ++i)
            {
                var excelcells = worksheet.get_Range($"A{i + 2}", $"A{i + 2}");
                excelcells.Font.Bold = true;
                excelcells.RowHeight = 25;
                excelcells.Font.Size = 14;
                excelcells.Font.Name = "Times New Roman";
                excelcells.HorizontalAlignment = Constants.xlCenter;
                excelcells.VerticalAlignment = Constants.xlCenter;
                excelcells.Value2 = data[i].Header;
                for (int j = 0; j < data[i].Values.Length; ++j)
                {
                    excelcells = worksheet.get_Range($"{symbols[j + 1]}{i + 2}", $"{symbols[j + 1]}{i + 2}");
                    excelcells.Font.Size = 14;
                    excelcells.Font.Name = "Times New Roman";
                    excelcells.HorizontalAlignment = Constants.xlCenter;
                    excelcells.VerticalAlignment = Constants.xlCenter;
                    excelcells.Value2 = data[i].Values[j];
                }
            }
            var excelcellsBorder = worksheet.get_Range($"A2", $"D{data.Length + 1}");
            excelcellsBorder.Borders.LineStyle = XlLineStyle.xlContinuous;
            excelcellsBorder.Borders.Weight = 2d;
        }

        protected override void AddChart(string title, int countRecords)
        {
            var charts = worksheet.ChartObjects() as ChartObjects;
            var chartObject = charts.Add(250, 10, 300, 300);
            var chart = chartObject.Chart;
            var range = worksheet.get_Range($"A2", $"D{countRecords + 1}");
            chart.SetSourceData(range);
            chart.ChartType = XlChartType.xlLine;
            chart.ChartWizard(Source: range, Title: title);
        }

        protected override void SaveDoc(string fileName)
        {
            object missing = System.Reflection.Missing.Value;
            workbook.SaveAs(fileName, XlFileFormat.xlOpenXMLWorkbook, missing, missing, false, false, XlSaveAsAccessMode.xlNoChange,
                XlSaveConflictResolution.xlUserResolution, true, missing, missing, missing);
            workbook.Close();
            excelApp.Quit();
        }
    }
}
