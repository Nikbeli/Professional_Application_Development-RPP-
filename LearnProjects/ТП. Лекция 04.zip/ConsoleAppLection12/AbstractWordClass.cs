﻿namespace ConsoleAppLection12
{
    abstract class AbstractWordClass
    {
        public void CreateReport(string fileName)
        {
            CreateDoc(fileName);

            AddParagraph("текст с информацией");

            AddTable(new int[,]
                {
                    { 4, 5, 2},
                    { 2, 7, 4}
                });

            SaveDoc(fileName);
        }

        protected abstract void CreateDoc(string fileName);

        protected abstract void AddParagraph(string text);

        protected abstract void AddTable(int[,] data);

        protected abstract void SaveDoc(string fileName);
    }
}