﻿using DocumentFormat.OpenXml;
using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml.Wordprocessing;

namespace ConsoleAppLection12
{
    class OpenXmlWordClass : AbstractWordClass
    {
        private WordprocessingDocument wordDocument;

        private Body body;

        protected override void CreateDoc(string fileName)
        {
            wordDocument = WordprocessingDocument.Create(fileName, WordprocessingDocumentType.Document);
            MainDocumentPart mainPart = wordDocument.AddMainDocumentPart();
            mainPart.Document = new Document();
            body = mainPart.Document.AppendChild(new Body());
        }

        protected override void AddParagraph(string text)
        {
            var docParagraph = new Paragraph();

            var parProperties = new ParagraphProperties();
            parProperties.AppendChild(new Justification() { Val = JustificationValues.Center });
            parProperties.AppendChild(new SpacingBetweenLines { After = "360" });
            var paragraphMarkRunProperties = new ParagraphMarkRunProperties();
            parProperties.AppendChild(paragraphMarkRunProperties);

            docParagraph.AppendChild(parProperties);

            var docRun = new Run();
            var runProperties = new RunProperties();
            runProperties.AppendChild(new RunFonts() { Ascii = "Times New Roman", ComplexScript = "Times New Roman", HighAnsi = "Times New Roman" });
            runProperties.AppendChild(new FontSize { Val = "44" });
            runProperties.AppendChild(new Bold());
            docRun.AppendChild(runProperties);

            docRun.AppendChild(new Text { Text = text, Space = SpaceProcessingModeValues.Preserve });
            docParagraph.AppendChild(docRun);

            body.AppendChild(docParagraph);
        }

        protected override void AddTable(int[,] data)
        {
            Table table = new Table();
            var tableProp = new TableProperties();
            tableProp.AppendChild(new TableLayout { Type = TableLayoutValues.Fixed });
            tableProp.AppendChild(new TableBorders(
                    new TopBorder() { Val = new EnumValue<BorderValues>(BorderValues.Single), Size = 4 },
                    new LeftBorder() { Val = new EnumValue<BorderValues>(BorderValues.Single), Size = 4 },
                    new RightBorder() { Val = new EnumValue<BorderValues>(BorderValues.Single), Size = 4 },
                    new BottomBorder() { Val = new EnumValue<BorderValues>(BorderValues.Single), Size = 4 },
                    new InsideHorizontalBorder() { Val = new EnumValue<BorderValues>(BorderValues.Single), Size = 4 },
                    new InsideVerticalBorder() { Val = new EnumValue<BorderValues>(BorderValues.Single), Size = 4 }
                ));
            tableProp.AppendChild(new TableWidth { Type = TableWidthUnitValues.Auto });
            table.AppendChild(tableProp);
            TableGrid tableGrid = new TableGrid();
            for (int j = 0; j < data.GetLength(1); ++j)
            {
                tableGrid.AppendChild(new GridColumn() { Width = "3413" });
            }
            table.AppendChild(tableGrid);
            for (int i = 0; i < data.GetLength(0); ++i)
            {
                TableRow docRow = new TableRow();
                for (int j = 0; j < data.GetLength(1); ++j)
                {
                    var docParagraph = new Paragraph();
                    var parProperties = new ParagraphProperties();
                    parProperties.AppendChild(new Justification() { Val = JustificationValues.Center });
                    parProperties.AppendChild(new SpacingBetweenLines { Before = "120", After = "0" });
                    docParagraph.AppendChild(parProperties);
                    var docRun = new Run();
                    var runProperties = new RunProperties();
                    runProperties.AppendChild(new RunFonts() { Ascii = "Times New Roman", ComplexScript = "Times New Roman", HighAnsi = "Times New Roman" });
                    runProperties.AppendChild(new FontSize { Val = "44" });
                    runProperties.AppendChild(new Bold());
                    docRun.AppendChild(runProperties);
                    docRun.AppendChild(new Text { Text = data[i, j].ToString(), Space = SpaceProcessingModeValues.Preserve });
                    docParagraph.AppendChild(docRun);
                    TableCell docCell = new TableCell();
                    docCell.AppendChild(docParagraph);
                    docRow.AppendChild(docCell);
                }
                table.AppendChild(docRow);
            }
            body.AppendChild(table);
        }

        protected override void SaveDoc(string fileName)
        {
            var properties = new SectionProperties();
            properties.AppendChild(new PageSize { Orient = PageOrientationValues.Portrait });
            properties.AppendChild(new PageMargin { Left = 1000, Right = 1000 });
            body.AppendChild(properties);
            wordDocument.MainDocumentPart.Document.Save();
            wordDocument.Close();
        }
    }
}