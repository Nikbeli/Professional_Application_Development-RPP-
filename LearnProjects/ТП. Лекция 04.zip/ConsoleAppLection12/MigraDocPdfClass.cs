﻿using MigraDoc.DocumentObjectModel;
using MigraDoc.DocumentObjectModel.Shapes.Charts;
using MigraDoc.DocumentObjectModel.Tables;
using MigraDoc.Rendering;
using System.Linq;

namespace ConsoleAppLection12
{
    class MigraDocPdfClass : AbstractPdfClass
    {
        Document document;

        protected override void CreateDoc(string fileName)
        {
            document = new Document();
            Style style = document.Styles["Normal"];
            style.Font.Name = "Times New Roman";
            style.Font.Size = 20;
            style = document.Styles.AddStyle("NormalBold", "Normal");
            style.Font.Bold = true;
        }

        protected override void AddParagraph(string text)
        {
            var section = document.AddSection();
            var paragraph = section.AddParagraph(text, "NormalBold");
            paragraph.Format.Alignment = ParagraphAlignment.Center;
        }

        protected override void AddTable((string Header, int[] Values)[] data)
        {
            var table = new Table();
            table.Borders.Width = 0.75;
            var column = table.AddColumn(Unit.FromCentimeter(5));
            column.Format.Alignment = ParagraphAlignment.Center;
            for (int i = 0; i < 3; ++i)
            {
                column = table.AddColumn(Unit.FromCentimeter(2));
                column.Format.Alignment = ParagraphAlignment.Center;
            }
            for (int i = 0; i < data.Length; ++i)
            {
                var row = table.AddRow();
                row.VerticalAlignment = VerticalAlignment.Center;
                var cell = row.Cells[0];
                var paragraph = cell.AddParagraph(data[i].Header);
                paragraph.Style = "NormalBold";
                for (int j = 0; j < data[i].Values.Length; ++j)
                {
                    cell = row.Cells[j + 1];
                    paragraph = cell.AddParagraph(data[i].Values[j].ToString());
                    paragraph.Format.Font.Size = 16;
                }
            }
            document.LastSection.Add(table);
        }

        protected override void AddChart(string title, (string Header, int[] Values)[] data)
        {
            var chart = new Chart(ChartType.Line);
            for (int i = 0; i < data.Length; ++i)
            {
                var series = chart.SeriesCollection.AddSeries();
                series.Name = data[i].Header;
                series.Add(data[i].Values.Select(x => (double)x).ToArray());
            }
            var xseries = chart.XValues.AddXSeries();
            xseries.Add(new string[] { "1", "2", "3" });
            chart.Width = Unit.FromCentimeter(16);
            chart.Height = Unit.FromCentimeter(12);
            chart.TopArea.AddParagraph(title);
            chart.XAxis.MajorTickMark = TickMarkType.Outside;
            chart.YAxis.MajorTickMark = TickMarkType.Outside;
            chart.YAxis.HasMajorGridlines = true;
            chart.PlotArea.LineFormat.Width = 1;
            chart.PlotArea.LineFormat.Visible = true;
            chart.RightArea.AddLegend();
            document.LastSection.Add(chart);
        }

        protected override void SaveDoc(string fileName)
        {
            PdfDocumentRenderer renderer = new PdfDocumentRenderer(true)
            {
                Document = document
            };
            renderer.RenderDocument();

            renderer.PdfDocument.Save(fileName);
        }
    }
}