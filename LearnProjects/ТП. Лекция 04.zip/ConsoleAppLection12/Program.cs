﻿namespace ConsoleAppLection12
{
    class Program
    {
        static void Main(string[] args)
        {
            //new InteropWordClass().CreateReport("U:\\Report 1.docx");
            //new OpenXmlWordClass().CreateReport("U:\\Report 2.docx");
            //new InteropExcelClass().CreateReport("U:\\Report 1.xlsx");
            //new OpenXmlExcelClass().CreateReport("U:\\Report 2.xlsx");
            //new ItextPdfClass().CreateReport("U:\\Report 1.pdf");
            //new MigraDocPdfClass().CreateReport("U:\\Report 2.pdf");
        }
    }
}