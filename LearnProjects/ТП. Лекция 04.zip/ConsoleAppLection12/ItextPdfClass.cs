﻿using iText.Kernel.Font;
using iText.Kernel.Pdf;
using iText.Layout;
using iText.Layout.Element;
using iText.Layout.Properties;

namespace ConsoleAppLection12
{
    class ItextPdfClass : AbstractPdfClass
    {
        Document document;

        protected override void CreateDoc(string fileName)
        {
            document = new Document(new PdfDocument(new PdfWriter(fileName)));
        }

        protected override void AddParagraph(string text)
        {
            string fontPath = "times-new-roman-cyr.ttf";
            var font = PdfFontFactory.CreateFont(fontPath);
            document.Add(new Paragraph(text)
               .SetTextAlignment(TextAlignment.CENTER)
               .SetFont(font)
               .SetFontSize(20)
               .SetBold());
        }

        protected override void AddTable((string Header, int[] Values)[] data)
        {
            string fontPath = "times-new-roman-cyr.ttf";
            var font = PdfFontFactory.CreateFont(fontPath);
            var table = new Table(4, false);
            for (int i = 0; i < data.Length; ++i)
            {
                var cell = new Cell(1, 1)
                    .SetVerticalAlignment(VerticalAlignment.MIDDLE)
                    .SetTextAlignment(TextAlignment.CENTER)
                    .Add(new Paragraph(data[i].Header).SetFont(font).SetFontSize(16).SetBold());
                table.AddCell(cell);
                for (int j = 0; j < data[i].Values.Length; ++j)
                {
                    cell = new Cell(1, 1)
                        .SetVerticalAlignment(VerticalAlignment.MIDDLE)
                        .SetTextAlignment(TextAlignment.CENTER)
                        .Add(new Paragraph(data[i].Values[j].ToString()).SetFont(font).SetFontSize(16));
                    table.AddCell(cell);
                }
            }
            document.Add(table);
        }

        protected override void AddChart(string title, (string Header, int[] Values)[] data)
        {
            // получить изображение диаграммы каким-либо средством сторонним
            // вставить изображение в документ
        }

        protected override void SaveDoc(string fileName)
        {
            document.Close();
        }
    }
}
