﻿namespace ConsoleAppLection12
{
    abstract class AbstractPdfClass
    {
        public void CreateReport(string fileName)
        {
            CreateDoc(fileName);

            AddParagraph("текст с информацией");

            AddTable(new (string Header, int[] Values)[]
            {
                ( "Строка 1", new int[] { 4, 5, 2 } ),
                ( "Строка 2", new int[] { 2, 7, 4 } ),
                ( "Строка 2", new int[] { 2, 7 } )
            });

            AddChart("Диаграмма", new (string Header, int[] Values)[]
            {
                ( "Строка 1", new int[] { 4, 5, 2 } ),
                ( "Строка 2", new int[] { 2, 7, 4 } )
            });

            SaveDoc(fileName);
        }

        protected abstract void CreateDoc(string fileName);

        protected abstract void AddParagraph(string text);

        protected abstract void AddTable((string Header, int[] Values)[] data);

        protected abstract void AddChart(string title, (string Header, int[] Values)[] data);

        protected abstract void SaveDoc(string fileName);
    }
}