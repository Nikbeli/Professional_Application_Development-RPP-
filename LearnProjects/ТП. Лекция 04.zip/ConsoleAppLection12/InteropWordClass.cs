﻿using Microsoft.Office.Interop.Word;
using System;

namespace ConsoleAppLection12
{
    class InteropWordClass : AbstractWordClass
    {
        private Application winword;

        private Document document;

        private object missing = System.Reflection.Missing.Value;

        protected override void CreateDoc(string fileName)
        {
            winword = new Application();
            document = winword.Documents.Add(ref missing, ref missing, ref missing, ref missing);
            document.PageSetup.RightMargin = 50;
            document.PageSetup.LeftMargin = 50;
        }

        protected override void AddParagraph(string text)
        {
            var paragraph = document.Content.Paragraphs.Add(Type.Missing);
            paragraph.Range.Text = text;
            paragraph.Format.Alignment = WdParagraphAlignment.wdAlignParagraphCenter;
            paragraph.Range.Font.Name = "Times New Roman";
            paragraph.Range.Font.Size = 22;
            paragraph.Range.Font.Bold = 2;
            paragraph.Format.SpaceAfter = 18;
            paragraph.Range.InsertParagraphAfter();
        }

        protected override void AddTable(int[,] data)
        {
            var table = document.Tables.Add(document.Bookmarks.get_Item("\\endofdoc").Range,
                  data.GetLength(0), data.GetLength(1), Type.Missing, Type.Missing);
            table.Borders.Enable = 1;
            for (int i = 0; i < data.GetLength(0); ++i)
            {
                for (int j = 0; j < data.GetLength(1); ++j)
                {
                    table.Cell(i + 1, j + 1).Range.Text = data[i,j].ToString();
                    table.Cell(i + 1, j + 1).Range.ParagraphFormat.SpaceAfter = 0;
                    table.Cell(i + 1, j + 1).Range.ParagraphFormat.SpaceBefore = 6;
                }
            }
        }

        protected override void SaveDoc(string fileName)
        {
            document.SaveAs(fileName, Type.Missing, Type.Missing, Type.Missing,
                Type.Missing, Type.Missing, Type.Missing, Type.Missing,
                Type.Missing, Type.Missing, Type.Missing, Type.Missing,
                Type.Missing, Type.Missing, Type.Missing, Type.Missing);
            document.Close(ref missing, ref missing, ref missing);
            document = null;
            winword.Quit(ref missing, ref missing, ref missing);
        }
    }
}
