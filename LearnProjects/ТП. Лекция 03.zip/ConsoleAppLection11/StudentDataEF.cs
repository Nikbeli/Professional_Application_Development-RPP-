﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ConsoleAppLection11
{
    [Table("Student")]
    public class StudentDataEF
    {
        [Key]
        public string StudentBookNumber { get; set; }

        [Required]
        [Column("StidentName")]
        public string FIO { get; set; }

        [Range(1, 5)]
        public int Course { get; set; }

        [Required]
        [MaxLength(50)]
        public string GroupName { get; set; }

        public double? AverageBall { get; set; }

        public int StudentGroupId { get; set; }

        public StudentGroupDataEF StudentGroup { get; set; }
    }
}