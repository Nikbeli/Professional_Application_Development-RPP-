﻿using System.Data.Entity;

namespace ConsoleAppLection11
{
    //public class DatabseInitializer : DropCreateDatabaseIfModelChanges<SampleContext>
    //{
    //    protected override void Seed(SampleContext context)
    //    {
    //        Init(context);//свое
    //        base.Seed(context);
    //    }

    //    private void Init(SampleContext context)
    //    { }
    //}
}
