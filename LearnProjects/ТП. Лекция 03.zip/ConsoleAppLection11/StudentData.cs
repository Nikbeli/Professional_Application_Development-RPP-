﻿using System.Data.Linq.Mapping;

namespace ConsoleAppLection11
{
    [Table(Name = "Students")]
    public class StudentData
    {
        [Column(IsPrimaryKey = true, IsDbGenerated = false)]
        public string StudentBookNumber { get; set; }

        [Column(Name = "StudentName")]
        public string FIO { get; set; }

        public int Course { get; set; }

        public string GroupName { get; set; }

        [Column(Name = "AverageBall", CanBeNull = true)]
        public double? AverageBall { get; set; }
    }
}