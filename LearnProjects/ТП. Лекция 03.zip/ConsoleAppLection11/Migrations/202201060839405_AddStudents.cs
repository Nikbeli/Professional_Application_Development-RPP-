﻿namespace ConsoleAppLection11.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class AddStudents : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.Student",
                c => new
                    {
                        StudentBookNumber = c.String(nullable: false, maxLength: 128),
                        StidentName = c.String(nullable: false),
                        Course = c.Int(nullable: false),
                        GroupName = c.String(nullable: false, maxLength: 50),
                        AverageBall = c.Double(),
                    })
                .PrimaryKey(t => t.StudentBookNumber);
            
        }
        
        public override void Down()
        {
            DropTable("dbo.Student");
        }
    }
}
