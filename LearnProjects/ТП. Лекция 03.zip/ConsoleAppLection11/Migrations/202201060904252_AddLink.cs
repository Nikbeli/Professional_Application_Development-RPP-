﻿namespace ConsoleAppLection11.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class AddLink : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.Student", "StudentGroupId", c => c.Int(nullable: false));
            CreateIndex("dbo.Student", "StudentGroupId");
            AddForeignKey("dbo.Student", "StudentGroupId", "dbo.StudentGroupDataEFs", "Id", cascadeDelete: true);
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.Student", "StudentGroupId", "dbo.StudentGroupDataEFs");
            DropIndex("dbo.Student", new[] { "StudentGroupId" });
            DropColumn("dbo.Student", "StudentGroupId");
        }
    }
}
