﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Linq;
using System.Data.Odbc;
using System.Data.OleDb;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleAppLection11
{
    class Program
    {
        static void Main(string[] args)
        {
            #region Simple ADO.Net Query To BD

            using (var connection = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=Database;
                    Integrated Security=True;Connect Timeout=30;User Instance=True"))
            {
                //connection.Open();
                //using (var command = new SqlCommand("SELECT * FROM Table1"))
                //{
                //    command.Connection = connection;
                //    using (var reader = command.ExecuteReader())
                //    {
                //        while (reader.Read())
                //        {
                //            Console.WriteLine("\t{0}\t{1}\t{2}", reader[0], reader[1], reader[2]);
                //        }
                //    }
                //}
            }

            #endregion

            #region ADO.Net query

            string sqlConnectionString = "Data Source=(local);Initial Catalog=Database;Integrated Security=true";
            using (var connection = new SqlConnection(sqlConnectionString))
            {
                string queryString = @"SELECT Id, FIO, GroupName FROM dbo.Students 
                                    WHERE GroupName = @GroupName
                                    ORDER BY FIO;";
                var command = new SqlCommand(queryString, connection);
                command.Parameters.AddWithValue("@GroupName", "ИСЭбд-31");

                try
                {
                    //connection.Open();
                    //using (var reader = command.ExecuteReader())
                    //{
                    //    while (reader.Read())
                    //    {
                    //        Console.WriteLine("\t{0}\t{1}\t{2}", reader[0], reader[1], reader[2]);
                    //    }
                    //}
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
                Console.ReadLine();
            }

            using (var connection = new OleDbConnection(@"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=c:\\Data\\Database.mdb;
                                                            User Id=admin;Password=;"))
            {
                int course = 2;
                var command = new OleDbCommand("dbo.CountStudentsOnCourse")
                {
                    Connection = connection,
                    CommandType = CommandType.StoredProcedure
                };
                command.Parameters.AddWithValue("@Course", course);

                try
                {
                    //connection.Open();
                    //int count = (int)command.ExecuteScalar();
                    //Console.WriteLine("Студентов на {0} курсе: {1}", course, count);
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
                Console.ReadLine();
            }

            using (var connection = new OdbcConnection())
            {
                connection.ConnectionString = "Driver={Microsoft Access Driver (*.mdb)};Dbq=c:\\Data\\Database.mdb;Uid=Admin;Pwd=;";

                var command = new OdbcCommand()
                {
                    CommandText = "UPDATE dbo.Students SET Course = @Course WHERE Id = @Id",
                    Connection = connection,
                    CommandType = CommandType.Text
                };
                command.Parameters.AddWithValue("@Id", 12);
                command.Parameters.AddWithValue("@Course", 3);

                try
                {
                    //connection.Open();
                    //command.ExecuteNonQuery();
                    //Console.WriteLine("Запись обновлена");
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
                Console.ReadLine();
            }

            #endregion

            #region DataSet

            using (var connection = new SqlConnection(@"Data Source=(local);Initial Catalog=Database;Integrated Security=true"))
            {
                string queryString = @"SELECT Id, FIO, GroupName FROM dbo.Students 
                                    WHERE GroupName = @GroupName
                                    ORDER BY FIO;";
                var command = new SqlCommand(queryString, connection);
                command.Parameters.AddWithValue("@GroupName", "ИСЭбд-31");
                try
                {
                    connection.Open();
                    var adapter = new SqlDataAdapter(command);
                    var ds = new DataSet();
                    adapter.Fill(ds);

                    foreach (DataRow row in ds.Tables[0].Rows)
                    {
                        row.ItemArray[2] = "ИСЭбд-41";
                    }

                    adapter.Update(ds);
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
                Console.ReadLine();
            }


            var dataSetStuds = new DataSet("StudentDataSet");

            var dataTableStuds = new DataTable("Students");
            dataTableStuds.Columns.Add(new DataColumn("Id", Type.GetType("System.Int32")));
            dataTableStuds.Columns.Add(new DataColumn("FIO", Type.GetType("System.String")));
            dataTableStuds.Columns.Add(new DataColumn("Course", Type.GetType("System.Int32")));
            dataTableStuds.Columns.Add(new DataColumn("GroupName", Type.GetType("System.String")));
            dataTableStuds.Columns.Add(new DataColumn("AverageBall", Type.GetType("System.Double")));

            dataSetStuds.Tables.Add(dataTableStuds);

            dataTableStuds.Rows.Add(new object[] { 1, "Петрова Екатерина", 3, "ИСЭбд-31", 4.45 });
            dataTableStuds.Rows.Add(new object[] { 2, "Иванова Наталья", 1, "ИСЭбд-12", 4.12 });
            dataTableStuds.Rows.Add(new object[] { 3, "Котов Петр", 1, "ПИбд-12", 4.12 });
            dataTableStuds.Rows.Add(new object[] { 4, "Сидоров Сергей", 2, "ПИбд-21", 4.8 });
            dataTableStuds.Rows.Add(new object[] { 5, "Картошкин Антон", 4, "ПИбд-41", 4.97 });


            var seletedExcellents = from dsStud in dataSetStuds.Tables["Students"].AsEnumerable()
                                    where (double)dsStud["AverageBall"] > 4.75
                                    select new
                                    {
                                        FIO = (string)dsStud["FIO"],
                                        GroupName = (string)dsStud["GroupName"]
                                    };

            DataSet dsXML = new DataSet();
            dsXML.ReadXml("file.xml");

            dataSetStuds.Merge(dsXML, true, MissingSchemaAction.AddWithKey);

            dataSetStuds.WriteXml("file.xml");

            #endregion

            #region Linq to SQL

            string connectionString = @"Data Source=.\SQLEXPRESS;Initial Catalog=DataBase;Integrated Security=True";
            var dataContext = new DataContext(connectionString);

            Table<StudentData> students = dataContext.GetTable<StudentData>();

            var dataClasses = new DataClassesDataContext();

            IQueryable<Students> studentByGroup =
                dataClasses.Students.Where(x => x.GroupName == "ИСЭбд-31");

            var group = dataClasses.StudentGroup.FirstOrDefault();

            dataClasses.Students.InsertOnSubmit(new Students
            {
                FIO = "Мышечкин Никита",
                Course = 1,
                GroupId = group.Id,
                StudentBookNumber = "20/777"
            });
            dataClasses.SubmitChanges();

            dataClasses.StudentGroup.InsertOnSubmit(new StudentGroup
            { GroupName = "ПИбд-11", KafedraName = "ИС", YearEnrollment = 2020 });
            dataClasses.StudentGroup.InsertOnSubmit(new StudentGroup
            { GroupName = "ПИбд-12", KafedraName = "ИС", YearEnrollment = 2020 });
            dataClasses.StudentGroup.InsertOnSubmit(new StudentGroup
            { GroupName = "ПИбд-13", KafedraName = "ИС", YearEnrollment = 2020 });
            dataClasses.SubmitChanges();


            var st = dataClasses.Students.FirstOrDefault(x => x.AverageBall > (decimal)4.75);
            if (st != null)
            {
                st.FIO += " (отл.)";
            }
            dataClasses.SubmitChanges();

            var studs = dataClasses.Students.Where(x => x.Course == 1);
            foreach (var stud in studs)
            {
                stud.Course = 2;
            }
            dataClasses.SubmitChanges();

            var deletedStuds = dataClasses.Students.Where(x => x.AverageBall < 2);
            dataClasses.Students.DeleteAllOnSubmit(deletedStuds);
            dataClasses.SubmitChanges();

            var delSt = dataClasses.Students.FirstOrDefault(x => x.FIO == "Мышечкин Никита");
            dataClasses.Students.DeleteOnSubmit(delSt);
            dataClasses.SubmitChanges();

            #endregion

            #region EF

            using (StudentContext context = new StudentContext())
            {
                context.StudentGroups.Add(new StudentGroupDataEF
                {
                    KafedraName = "ИС",
                    Name = "ИСЭбд-21",
                    YearEnrollment = 2021
                });

                context.SaveChanges();
            }

            using (StudentContext context = new StudentContext())
            {
                var studGroup = context.StudentGroups.FirstOrDefault(x => x.KafedraName == "ИС");
                studGroup.KafedraName = "ИС2";

                context.SaveChanges();
            }

            using (StudentContext context = new StudentContext())
            {
                context.StudentGroups.RemoveRange(context.StudentGroups.Where(x => x.YearEnrollment == 2016));

                context.SaveChanges();
            }

            var studGroupEF = new StudentGroupDataEF
            {
                KafedraName = "ИС",
                Name = "ИСЭбд-21",
                YearEnrollment = 2021
            };

            using (StudentContext context = new StudentContext())
            using (var transaction = context.Database.BeginTransaction())
            {
                try
                {
                    context.StudentGroups.Add(studGroupEF);
                    context.SaveChanges();

                    context.Students.Add(new StudentDataEF
                    {
                        FIO = "Васечькин Олег",
                        Course = 2,
                        GroupName = studGroupEF.Name,
                        StudentGroupId = studGroupEF.Id,
                        StudentBookNumber = "20/2525"
                    });

                    context.Students.Add(new StudentDataEF
                    {
                        FIO = "Васечькина Ольга",
                        Course = 2,
                        GroupName = studGroupEF.Name,
                        StudentGroupId = studGroupEF.Id,
                        StudentBookNumber = "20/2526"
                    });
                    context.SaveChanges();

                    transaction.Commit();
                }
                catch (Exception)
                {
                    transaction.Rollback();
                }
            }

            #endregion

            #region SQLQuery

            using (StudentContext context = new StudentContext())
            {
                var param = new SqlParameter("@Cource", 1);
                var studentsSQL = 
                    context.Database.SqlQuery<StudentDataEF>("SELECT * FROM GetStudentByCourse (@Cource)", param);
                foreach (var stSQL in studentsSQL)
                {
                    Console.WriteLine("{0} - {1}", stSQL.FIO, stSQL.GroupName);
                }

                var year = new SqlParameter("@YearEnrollment", 2017);
                context.Database.
                    ExecuteSqlCommand("DELETE FROM [dbo].[StudentGroupDataEFs] WHERE [YearEnrollment]=@YearEnrollment", year);
            }

            #endregion
        }
    }
}
