﻿using System.Collections.Generic;

namespace ConsoleAppLection11
{
    public class StudentGroupDataEF
    {
        public int Id { get; set; }

        public string Name { get; set; }

        public string KafedraName { get; set; }

        public int YearEnrollment { get; set; }

        public List<StudentDataEF> Students { get; set; }
    }
}