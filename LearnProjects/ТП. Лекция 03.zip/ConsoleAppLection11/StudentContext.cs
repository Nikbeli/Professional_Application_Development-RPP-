﻿using System.Data.Entity;

namespace ConsoleAppLection11
{
    public class StudentContext : DbContext
    {
        public StudentContext() : base("StudentConnection") { }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            //modelBuilder.Entity<StudentDataEF>()
            //    .HasKey(x => x.StudentBookNumber);

            //modelBuilder.Entity<StudentDataEF>()
            //    .Property(x => x.FIO).IsRequired();
            //modelBuilder.Entity<StudentDataEF>()
            //    .Property(x => x.FIO).HasColumnName("StidentName");

            //modelBuilder.Entity<StudentDataEF>()
            //    .Property(x => x.GroupName).IsRequired();
            //modelBuilder.Entity<StudentDataEF>()
            //    .Property(x => x.GroupName).HasMaxLength(50);

            //modelBuilder.Entity<StudentDataEF>()
            //    .ToTable("Student");

            modelBuilder.Entity<StudentGroupDataEF>()
                .HasMany(x => x.Students)
                .WithRequired(x => x.StudentGroup)
                .HasForeignKey(x => x.StudentGroupId);
        }

        public DbSet<StudentGroupDataEF> StudentGroups { get; set; }

        public DbSet<StudentDataEF> Students { get; set; }
    }
}