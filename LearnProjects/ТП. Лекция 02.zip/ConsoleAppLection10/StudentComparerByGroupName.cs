﻿using System.Collections.Generic;

namespace ConsoleAppLection10
{
    class StudentComparerByGroupName : IEqualityComparer<Student>
    {
        public bool Equals(Student x, Student y)
        {
            return x.GroupName == y.GroupName;
        }

        public int GetHashCode(Student obj)
        {
            return obj.GetHashCode();
        }
    }
}