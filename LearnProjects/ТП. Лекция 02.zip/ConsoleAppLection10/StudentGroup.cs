﻿using System.Collections.Generic;

namespace ConsoleAppLection10
{
    public class StudentGroup
    {
        public string Name { get; set; }

        public string KafedraName { get; set; }

        public int YearEnrollment { get; set; }

        public List<Student> Students { get; set; }
    }
}