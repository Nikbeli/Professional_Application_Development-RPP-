﻿using ConsoleAppLection09;

namespace ConsoleAppLection10
{
    public class InternalChildFieldExample : InternalFieldExample
    {
        public int GetPrpInterField => ProtField;

      //  public int GetPrpIntField => Field;
    }
}