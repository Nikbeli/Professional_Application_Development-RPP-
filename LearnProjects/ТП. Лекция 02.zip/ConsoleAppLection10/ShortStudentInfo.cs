﻿namespace ConsoleAppLection10
{
    public class ShortStudentInfo
    {
        public string StudentName { get; set; }

        public string GroupName { get; set; }
    }
}