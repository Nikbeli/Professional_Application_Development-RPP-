﻿using ConsoleAppLection09;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;

namespace ConsoleAppLection10
{
    class Program
    {
        static void Main(string[] args)
        {
            //InternalExample xampl = new InternalExample();

            //InternalFieldExample exampl = new InternalFieldExample();
            //exampl.Field = 15;
            //exampl.ProtField = 15;

            #region loader
            //List<Book> selectedBooks = new List<Book>();

            //XmlDocument doc = new XmlDocument();
            //doc.Load("books.xml");
            //XmlNodeList books = doc.SelectNodes("book");
            //foreach (XmlNode item in books)
            //{
            //    var cost = Convert.ToDouble(item.SelectSingleNode("Cost")?.InnerText);
            //    if (cost > 100)
            //    {
            //        selectedBooks.Add(new Book()
            //        {
            //            Author = item.SelectSingleNode("Author")?.InnerText,
            //            Title = item.SelectSingleNode("Title")?.InnerText,
            //            Cost = cost
            //        });
            //    }
            //}

            //string connectionString = "Data Source=(local);Initial Catalog=Northwind;Integrated Security=true";
            //string queryString = "SELECT Title, Authior, Cost from dbo.Books WHERE Cost > @pricePoint ";
            //using (SqlConnection connection = new SqlConnection(connectionString))
            //{
            //    SqlCommand command = new SqlCommand(queryString, connection);
            //    command.Parameters.AddWithValue("@pricePoint", 100);
            //    try
            //    {
            //        connection.Open();
            //        SqlDataReader reader = command.ExecuteReader();
            //        while (reader.Read())
            //        {
            //            selectedBooks.Add(new Book()
            //            {
            //                Author = reader[0].ToString(),
            //                Title = reader[1].ToString(),
            //                Cost = Convert.ToDouble(reader[2])
            //            });
            //        }
            //        reader.Close();
            //    }
            //    catch (Exception ex)
            //    {
            //        Console.WriteLine(ex.Message);
            //    }
            //    Console.ReadLine();
            //}

            //List<Book> allBooks = new List<Book>();

            //// какая-то логика наполнения allBooks

            //foreach (var book in allBooks)
            //{
            //    if (book.Cost > 100)
            //    {
            //        selectedBooks.Add(new Book()
            //        {
            //            Author = book.Author,
            //            Title = book.Title,
            //            Cost = book.Cost
            //        });
            //    }
            //}
            #endregion

            #region Exapmle Simple Query
            //Console.WriteLine();

            int[] numbers = new int[7] { 0, 1, 2, 3, 4, 5, 6 };

            IEnumerable<int> numQuery = from num in numbers
                                        where (num % 2) == 0
                                        select num;

            List<int> numList = new List<int>();
            for (int i = 0; i < numbers.Length; ++i)
            {
                if (numbers[i] % 2 == 0)
                {
                    numList.Add(numbers[i]);
                }
            }

            foreach (var num in numbers)
            {
                if (num % 2 == 0)
                {
                    numList.Add(num);
                }
            }

            //foreach (var elem in numQuery)
            //{
            //    Console.Write(elem + ", ");
            //}
            #endregion

            List<Student> students = new List<Student>
            {
                new Student { FIO = "Петрова Екатерина",  GroupName = "ИСЭбд-31", AverageBall = 4.45, Course = 3 },
                new Student { FIO = "Иванова Наталья", GroupName = "ИСЭбд-12", AverageBall = 3.56, Course = 1 },
                new Student { FIO = "Котов Петр", GroupName = "ПИбд-12", AverageBall = 4.12, Course = 1 },
                new Student { FIO = "Сидоров Сергей", GroupName = "ПИбд-21", AverageBall = 4.8, Course = 2 },
                new Student { FIO = "Картошкин Антон", GroupName = "ПИбд-41" , AverageBall = 4.97, Course = 4 }
            };

            #region Select simple
            //Console.WriteLine();

            IEnumerable<Student> seleted = from st in students
                                           select st;
            //foreach (var sel in seleted)
            //{
            //    Console.WriteLine("{0}, {1}", sel.FIO, sel.AverageBall);
            //}

            //Console.WriteLine();

            IEnumerable<double> seletedAvg = from st in students
                                             select st.AverageBall;
            //foreach (var avg in seletedAvg)
            //{
            //    Console.WriteLine("Средний балл: {0}", avg);
            //}

            //Console.WriteLine();

            IEnumerable<ShortStudentInfo> ssi = from st in students
                                                select new ShortStudentInfo
                                                {
                                                    StudentName = st.FIO,
                                                    GroupName = st.GroupName
                                                };
            //foreach (var s in ssi)
            //{
            //    Console.WriteLine("{0} ({1})", s.StudentName, s.GroupName);
            //}

            //Console.WriteLine();

            var selectedStudentInfo = from student in students
                                      select new
                                      {
                                          GroupNumber = student.GroupName.Split('-')[1][1],
                                          Kurs = student.GroupName.Split('-')[1][0],
                                          LastName = student.FIO.Split(' ')[0],
                                          FirstName = student.FIO.Split(' ')[1]
                                      };
            //foreach (var selStudInf in selectedStudentInfo)
            //{
            //    Console.WriteLine("Курс: {0} - Фамилия: {1}", selStudInf.Kurs, selStudInf.LastName);
            //}
            #endregion

            #region Group simple
            students = new List<Student>
            {
                new Student { FIO = "Петрова Екатерина",  GroupName = "ИСЭбд-31", AverageBall = 4.45, Course = 3 },
                new Student { FIO = "Иванова Наталья", GroupName = "ИСЭбд-31", AverageBall = 3.56, Course = 3 },
                new Student { FIO = "Котов Петр", GroupName = "ПИбд-21", AverageBall = 4.12, Course = 2 },
                new Student { FIO = "Сидоров Сергей", GroupName = "ПИбд-21", AverageBall = 4.8, Course = 2 },
                new Student { FIO = "Картошкин Антон", GroupName = "ПИбд-31" , AverageBall = 4.97, Course = 3 }
            };

            //Console.WriteLine();

            var studentCourse = from student in students
                                group student by student.Course;
            //foreach (IGrouping<int, Student> gr in studentCourse)
            //{
            //    Console.WriteLine(gr.Key);
            //    foreach (var t in gr)
            //    {
            //        Console.WriteLine(t.FIO);
            //    }
            //    Console.WriteLine();
            //}

            //Console.WriteLine();

            var studentGoods = from student in students
                               group student by student.AverageBall > 4.75;
            //foreach (IGrouping<bool, Student> gr in studentGoods)
            //{
            //    Console.WriteLine(gr.Key);
            //    foreach (var t in gr)
            //    {
            //        Console.WriteLine(t.FIO);
            //    }
            //    Console.WriteLine();
            //}

            //Console.WriteLine();

            var studentCourseGroups = from student in students
                                      group student by new { student.Course, student.GroupName };
            //foreach (var gr in studentCourseGroups)
            //{
            //    Console.WriteLine("Курс: {0}, Группа {1}", gr.Key.Course, gr.Key.GroupName);
            //    foreach (var t in gr)
            //    {
            //        Console.WriteLine(t.FIO);
            //    }
            //    Console.WriteLine();
            //}
            #endregion

            #region Where simple
            students = new List<Student>
            {
                new Student { FIO = "Петрова Екатерина",  GroupName = "ИСЭбд-31", AverageBall = 4.45, Course = 3 },
                new Student { FIO = "Иванова Наталья", GroupName = "ИСЭбд-31", AverageBall = 3.56, Course = 3 },
                new Student { FIO = "Котов Петр", GroupName = "ПИбд-21", AverageBall = 4.12, Course = 2 },
                new Student { FIO = "Сидоров Сергей", GroupName = "ПИбд-21", AverageBall = 4.8, Course = 2 },
                new Student { FIO = "Картошкин Антон", GroupName = "ПИбд-31" , AverageBall = 4.97, Course = 3 }
            };

            //Console.WriteLine();

            IEnumerable<Student> seletedExcellents = from st in students
                                                     where st.AverageBall > 4.75
                                                     select st;
            //foreach (var student in seletedExcellents)
            //{
            //    Console.WriteLine("Курс: {0} - Фамилия: {1}", student.GroupName, student.FIO);
            //}

            //Console.WriteLine();

            IEnumerable<Student> seletedSeniorExcellents = from st in students
                                                           where st.AverageBall > 4.75 && st.Course > 2
                                                           select st;
            //foreach (var student in seletedSeniorExcellents)
            //{
            //    Console.WriteLine("Курс: {0} - Фамилия: {1}", student.GroupName, student.FIO);
            //}

            //Console.WriteLine();

            IEnumerable<Student> seletedJuniors = from st in students
                                                  where SelectedJuniorStudent(st)
                                                  select st;
            //foreach (var student in seletedJuniors)
            //{
            //    Console.WriteLine("Курс: {0} - Фамилия: {1}", student.GroupName, student.FIO);
            //}
            #endregion

            #region Order simple
            students = new List<Student>
            {
                new Student { FIO = "Петрова Екатерина",  GroupName = "ИСЭбд-31", AverageBall = 4.45, Course = 3 },
                new Student { FIO = "Иванова Наталья", GroupName = "ИСЭбд-31", AverageBall = 3.56, Course = 3 },
                new Student { FIO = "Котов Петр", GroupName = "ПИбд-21", AverageBall = 4.12, Course = 2 },
                new Student { FIO = "Сидоров Сергей", GroupName = "ПИбд-21", AverageBall = 4.8, Course = 2 },
                new Student { FIO = "Картошкин Антон", GroupName = "ПИбд-31" , AverageBall = 4.97, Course = 3 }
            };

            //Console.WriteLine();

            IEnumerable<Student> orderedAsceding = from st in students
                                                   orderby st.Course
                                                   select st;
            //foreach (var student in orderedAsceding)
            //{
            //    Console.WriteLine("Курс: {0} - Фамилия: {1}", student.GroupName, student.FIO);
            //}

            //Console.WriteLine();

            IEnumerable<Student> orderedDescedning = from st in students
                                                     orderby st.GroupName descending
                                                     select st;
            //foreach (var student in orderedDescedning)
            //{
            //    Console.WriteLine("Курс: {0} - Фамилия: {1}", student.GroupName, student.FIO);
            //}

            //Console.WriteLine();

            IEnumerable<Student> orderedMultyOrder = from st in students
                                                     orderby st.GroupName, st.FIO
                                                     select st;
            //foreach (var student in orderedMultyOrder)
            //{
            //    Console.WriteLine("Курс: {0} - Фамилия: {1}", student.GroupName, student.FIO);
            //}

            //Console.WriteLine();

            IEnumerable<Student> orderedMultyAscDescOrder = from st in students
                                                            orderby st.Course descending, st.AverageBall ascending
                                                            select st;
            //foreach (var student in orderedMultyAscDescOrder)
            //{
            //    Console.WriteLine("Курс: {0} - Фамилия: {1}", student.GroupName, student.FIO);
            //}
            #endregion

            #region Join simple
            students = new List<Student>
            {
                new Student { FIO = "Петрова Екатерина",  GroupName = "ИСЭбд-31", AverageBall = 4.45, Course = 3 },
                new Student { FIO = "Иванова Наталья", GroupName = "ИСЭбд-31", AverageBall = 3.56, Course = 3 },
                new Student { FIO = "Котов Петр", GroupName = "ПИбд-21", AverageBall = 4.12, Course = 2 },
                new Student { FIO = "Сидоров Сергей", GroupName = "ПИбд-21", AverageBall = 4.8, Course = 2 },
                new Student { FIO = "Картошкин Антон", GroupName = "ПИбд-31" , AverageBall = 4.97, Course = 3 }
            };
            List<StudentGroup> groups = new List<StudentGroup>
            {
                new StudentGroup { Name = "ИСЭбд-31", KafedraName = "ИС", YearEnrollment = 2019 },
                new StudentGroup { Name = "ПИбд-31", KafedraName = "ИС", YearEnrollment = 2019 },
                new StudentGroup { Name = "ИСЭбд-21", KafedraName = "ИС", YearEnrollment = 2020 },
                new StudentGroup { Name = "ПИбд-21", KafedraName = "ИС", YearEnrollment = 2020 }
            };

            //Console.WriteLine();

            var innerJoinQuery = from gr in groups
                                 join st in students on gr.Name equals st.GroupName
                                 select new { Student = st.FIO, Year = gr.YearEnrollment, gr.Name };
            //foreach (var inner in innerJoinQuery)
            //{
            //    Console.WriteLine("{0}: {1} ({2})", inner.Student, inner.Year, inner.Name);
            //}

            //Console.WriteLine();

            var innerGroupJoinQuery = from gr in groups
                                      join st in students on gr.Name equals st.GroupName into groupStuds
                                      select new { gr.YearEnrollment, Students = groupStuds };
            //foreach (var inner in innerGroupJoinQuery)
            //{
            //    Console.WriteLine(inner.YearEnrollment + ": ");
            //    foreach (var st in inner.Students)
            //    {
            //        Console.WriteLine("Студент: {0}", st.FIO);
            //    }
            //}

            //Console.WriteLine();

            var leftOuterJoinQuery = from gr in groups
                                     join st in students on gr.Name equals st.GroupName into groupStuds
                                     from item in groupStuds.DefaultIfEmpty(new Student { FIO = "Нет студентов" })
                                     select new { GroupName = gr.Name, Student = item };

            //foreach (var inner in leftOuterJoinQuery)
            //{
            //    Console.WriteLine("{0}: {1}", inner.GroupName, inner.Student.FIO);
            //}
            #endregion

            #region Example Error
            string[] strings = { "один", "два", null, "три" };

            //Console.WriteLine("Перед вызовом linq");

            IEnumerable<string> query = from str in strings
                                        where str.Length > 3
                                        select str;

            //Console.WriteLine("После вызова linq");

            //foreach (var s in query)
            //{
            //    Console.Write("{0}, ", s);
            //}
            #endregion

            #region Nested Query
            var nesterStudentGroups = from student in students
                                      group student by student.GroupName into g
                                      select new
                                      {
                                          Name = g.Key,
                                          TotalCount = g.Count(),
                                          Students = from s in g
                                                     where s.AverageBall > 4.75
                                                     select s
                                      };
            #endregion

            #region Combine query
            var studentQuery = from st in students
                               where st.AverageBall > 4.75
                               orderby st.GroupName, st.FIO
                               select new ShortStudentInfo
                               {
                                   StudentName = st.FIO,
                                   GroupName = st.GroupName
                               };
            #endregion

            #region Anonymous type
            var anonType = new { Message = "Привет, мир", Age = 0.1 };

            //Console.WriteLine("{0}. Мне {1}", anonType.Message, anonType.Age);
            #endregion

            #region Lambda
            students = new List<Student>
            {
                new Student { FIO = "Петрова Екатерина",  GroupName = "ИСЭбд-31", AverageBall = 4.45, Course = 3 },
                new Student { FIO = "Иванова Наталья", GroupName = "ИСЭбд-31", AverageBall = 3.56, Course = 3 },
                new Student { FIO = "Котов Петр", GroupName = "ПИбд-21", AverageBall = 4.12, Course = 2 },
                new Student { FIO = "Сидоров Сергей", GroupName = "ПИбд-21", AverageBall = 4.8, Course = 2 },
                new Student { FIO = "Картошкин Антон", GroupName = "ПИбд-31" , AverageBall = 4.97, Course = 3 }
            };

            Console.WriteLine();

            IEnumerable<Student> seletedExcellentsMethod =
                        students.Where(x => x.AverageBall > 4.75);
            //foreach (var student in seletedExcellents)
            //{
            //    Console.WriteLine("Курс: {0} - Фамилия: {1}", student.GroupName, student.FIO);
            //}

            var firstSel = Filter(students, 2, null, 4.00);
            var secondSel = Filter(students, 3, "П", null);
            var thirdSel = Filter(students, null, null, null);

            IOrderedEnumerable<Student> ordStud =
                students.OrderByDescending(x => x.Course).ThenBy(x => x.AverageBall);

            var orderedSel = FilterWithOrder(students, null, null, null, true, true);

            IEnumerable<IGrouping<string, Student>> simpleGrouping =
                students.GroupBy(x => x.GroupName);

            IEnumerable<IGrouping<string, string>> studFIOGrouping =
                students.GroupBy(x => x.GroupName, x => x.FIO);

            var newTypeGrouping =
                students.GroupBy(x => x.GroupName, x => x.FIO, (grKey, grValue) =>
                new
                {
                    GroupName = grKey,
                    StudentCount = grValue.Count()
                });

            IEnumerable<double> avgBalls = students.Select(x => x.AverageBall);

            IEnumerable<ShortStudentInfo> shortStudentInfos =
                students.Select(x => new ShortStudentInfo
                {
                    GroupName = x.GroupName,
                    StudentName = x.FIO
                });

            var newTypeSelect =
                students.Select(x => new
                {
                    x.GroupName,
                    Student = x.FIO,
                    Ball = x.AverageBall
                });

            IEnumerable<Student> selManyStudSimple =
                groups.SelectMany(x => x.Students);

            IEnumerable<ShortStudentInfo> selManyStudInfoSimple =
                groups.SelectMany(x => x.Students).Select(x => new ShortStudentInfo
                {
                    GroupName = x.GroupName,
                    StudentName = x.FIO
                });


            var simpleJoin = groups.Join(
                students,
                gr => gr.Name,
                st => st.GroupName,
                (gr, st) => new
                {
                    Student = st.FIO,
                    Year = gr.YearEnrollment,
                    gr.Name
                });

            var groupJoin = groups.GroupJoin(
               students,
               gr => gr.Name,
               st => st.GroupName,
               (gr, stCollect) => new
               {
                   gr.YearEnrollment,
                   Students = stCollect
               });

            List<Student> studentEmptyList = new List<Student>();

            foreach (var st in studentEmptyList.DefaultIfEmpty(new Student { FIO = "Пустой" }))
            {
                //Console.WriteLine("Студент {0}", st.FIO);
            }

            ArrayList arrayListStrings = new ArrayList
            {
                "Студент",
                "Преподаватель",
                "Экзамен"
            };

            IEnumerable<string> stringCast = arrayListStrings.Cast<string>();
            //foreach (var elem in stringCast)
            //{
            //    Console.WriteLine("{0}, ", elem.ToUpper());
            //}

            //Console.WriteLine();

            ArrayList arrayList = new ArrayList
            {
                "Студент",
                "Преподаватель",
                "Экзамен",
                10,
                4.45
            };

            IEnumerable<string> stringOfType = arrayListStrings.OfType<string>();
            //foreach (var elem in stringOfType)
            //{
            //    Console.WriteLine("{0}, ", elem);
            //}

            var isebd = new List<Student>
            {
                new Student { FIO = "Петрова Екатерина",  GroupName = "ИСЭбд-31", AverageBall = 4.45, Course = 3 },
                new Student { FIO = "Иванова Наталья", GroupName = "ИСЭбд-31", AverageBall = 3.56, Course = 3 }
            };

            var pibd = new List<Student>
            {
                new Student { FIO = "Котов Петр", GroupName = "ПИбд-21", AverageBall = 4.12, Course = 2 },
                new Student { FIO = "Сидоров Сергей", GroupName = "ПИбд-21", AverageBall = 4.8, Course = 2 },
                new Student { FIO = "Картошкин Антон", GroupName = "ПИбд-31" , AverageBall = 4.97, Course = 3 }
            };

            var studConcat = isebd.Concat(pibd);
            //foreach (var elem in studConcat)
            //{
            //    Console.WriteLine("Студент: {0} ", elem.FIO);
            //}

            //Console.WriteLine();

            var studZip = isebd.Zip(pibd, (ise, pi) => new Student { FIO = ise.FIO, GroupName = pi.GroupName });
            //foreach (var elem in studZip)
            //{
            //    Console.WriteLine("Студент: {0}, группа {1}", elem.FIO, elem.GroupName);
            //}

            var studSAT = SkipAndTake(students, 2, 2);
            //foreach (var elem in studSAT)
            //{
            //    Console.WriteLine("Студент: {0}, группа {1}", elem.FIO, elem.GroupName);
            //}

            var massive = new int[] { 10, 4, 67, 2, 34, 4, 23, 76, 10, 43 };

            //foreach (var elem in massive.Distinct())
            //{
            //    Console.Write("{0}, ", elem);
            //}

            //Console.WriteLine();

            //Console.WriteLine();

            //foreach (var elem in massive.Reverse())
            //{
            //    Console.Write("{0}, ", elem);
            //}

            var firstmassive = new int[] { 10, 4, 67, 2, 34, };
            var secondmassive = new int[] { 4, 23, 76, 10, 43 };

            //foreach (var elem in firstmassive.Except(secondmassive))
            //{
            //    Console.Write("{0}, ", elem);
            //}

            //Console.WriteLine();

            //Console.WriteLine();

            //foreach (var elem in firstmassive.Intersect(secondmassive))
            //{
            //    Console.Write("{0}, ", elem);
            //}

            //Console.WriteLine();

            //Console.WriteLine();

            //foreach (var elem in firstmassive.Union(secondmassive))
            //{
            //    Console.Write("{0}, ", elem);
            //}

            if (students.All(x => x.AverageBall > 4.75))
            {
                Console.WriteLine("Невероятно, но тут учатся одни отличники");
            }
            else
            {
                //Console.WriteLine("Хотя бы один неотличник тут есть");
            }

            if (students.Any(x => x.AverageBall > 4.75))
            {
                //Console.WriteLine("Да тут есть отличники");
            }
            else
            {
                Console.WriteLine("Ни одного отличника, печально");
            }

            var newStudent = new Student { FIO = "Васечкин", GroupName = "ИСЭбд-31" };
            if (isebd.Contains(newStudent, new StudentComparerByGroupName()))
            {
                //Console.WriteLine("Студент {0} в группе", newStudent.FIO);
            }
            else
            {
                Console.WriteLine("Студент {0} не в группе", newStudent.FIO);
            }

            //Console.WriteLine();

            if (isebd.SequenceEqual(pibd, new StudentComparerByGroupName()))
            {
                Console.WriteLine("Студенты одной группы");
            }
            else
            {
                //Console.WriteLine("Студенты разных группы");
            }

            var agregate = massive.Aggregate(
                0,
                (agr, next) => next % 2 == 0 ? agr + next : agr,
                rez => rez / 2);
            //Console.WriteLine("Агрегация: {0}", agregate);

            //Console.WriteLine();

            var avg = massive.Average();
            //Console.WriteLine("Среднее: {0}", avg);

            var countStudents = students.Count(x => x.AverageBall > 4.75);
            //Console.WriteLine("Количество отличников: {0}", countStudents);

            //Console.WriteLine();

            var sumCources = students.Sum(x => x.Course);
            //Console.WriteLine("Сумма курсов: {0}", sumCources);

            var maxVal = massive.Max();
            //Console.WriteLine("Максимальное число массива: {0}", maxVal);

            //Console.WriteLine();

            var minBall = students.Min(x => x.AverageBall);
            //Console.WriteLine("Минимальрный срелний балл: {0}", minBall);

            var firstStudent = students.First(x => x.Course > 2);
            //Console.WriteLine("Первый старшекурсник: {0}", firstStudent.FIO);

            //Console.WriteLine();

            var singleStudent = students.SingleOrDefault(x => x.AverageBall == 5);
            //Console.WriteLine("Круглый отличник: {0}", singleStudent?.FIO ?? "нет такого");

            var elementStudent = students.ElementAtOrDefault(33);
            //Console.WriteLine("33 студент: {0}", elementStudent?.FIO ?? "нет такого");

            //Console.WriteLine();

            var lastStudent = students.LastOrDefault(x => x.GroupName == "ПИбд-21");
            //Console.WriteLine("Последний студент группы ПИбд-21: {0}", lastStudent.FIO);

            Student[] arrayOfStudents = students.ToArray();

            List<Student> studentList =
                students.Where(x => x.AverageBall > 4.75).ToList();

            var studentDitcionary =
                students.GroupBy(x => x.GroupName, x => x.FIO, (grKey, grValue) =>
                new
                {
                    GroupName = grKey,
                    StudentCount = grValue.Count()
                })
                .ToDictionary(x => x.GroupName);

            //foreach(var elem in studentDitcionary)
            //{
            //    Console.WriteLine("Ключ: {0}, Значение {1}", elem.Key, elem.Value.StudentCount);
            //}

            Dictionary<string, int> studentDitcionary2 =
                students.GroupBy(x => x.GroupName, x => x.FIO, (grKey, grValue) =>
                new
                {
                    GroupName = grKey,
                    StudentCount = grValue.Count()
                })
                .ToDictionary(x => x.GroupName, x => x.StudentCount);

            var studentMethodQuery = students
                .Where(x => x.AverageBall > 4.75)
                .OrderBy(x => x.GroupName)
                .ThenBy(x => x.FIO)
                .Select(x => new ShortStudentInfo
                {
                    StudentName = x.FIO,
                    GroupName = x.GroupName
                });

            #endregion

            Console.ReadKey();
        }

        private static bool SelectedJuniorStudent(Student student)
        {
            return student.Course < 3;
        }

        private static IEnumerable<Student> Filter(List<Student> source, int? course, string FIO, double? ball)
        {
            var query = source.AsEnumerable();
            if (course.HasValue)
            {
                query = query.Where(x => x.Course == course.Value);
            }
            if (!string.IsNullOrEmpty(FIO))
            {
                query = query.Where(x => x.FIO.StartsWith(FIO));
            }
            if (ball.HasValue)
            {
                query = query.Where(x => x.AverageBall >= ball.Value);
            }

            return query;
        }

        private static IEnumerable<Student> FilterWithOrder(List<Student> source, int? course, string FIO, double? ball,
            bool orderByCourse, bool orderByFIO)
        {
            var query = source.AsEnumerable();
            if (course.HasValue)
            {
                query = query.Where(x => x.Course == course.Value);
            }
            if (!string.IsNullOrEmpty(FIO))
            {
                query = query.Where(x => x.FIO.StartsWith(FIO));
            }
            if (ball.HasValue)
            {
                query = query.Where(x => x.AverageBall >= ball.Value);
            }

            if (orderByCourse && !orderByFIO)
            {
                query = query.OrderBy(x => x.Course);
            }
            else if (!orderByCourse && orderByFIO)
            {
                query = query.OrderBy(x => x.FIO);
            }
            else if (orderByCourse && orderByFIO)
            {
                query = query.OrderBy(x => x.Course).ThenBy(x => x.FIO);
            }

            return query;
        }

        private static IEnumerable<Student> SkipAndTake(List<Student> source, int page, int count)
        {
            return source.Skip(count * (page - 1)).Take(count);
        }
    }
}
