﻿namespace ConsoleAppLection10
{
    public class Student
    {
        public string FIO { get; set; }

        public int Course { get; set; }

        public string GroupName { get; set; }

        public double AverageBall { get; set; }
    }
}