﻿using System;

namespace ConsoleAppLection16
{
    public class MembersClass
    {
        private int _field1;

        protected int _field2;

        public int _field3;

        [MapConfiguration("Свойство первое", IsDifficle = true)]
        private double Prop1 { set { _field3 = (int)value; } }

        [MapConfiguration("Свойство второе")]
        protected double Prop2 { get { return _field1; } }

        [MapConfiguration("Свойство третье", AllowCopyWithoutRigth = true)]
        public double Prop3 { get; set; }

        private event Action Ev1;

        public event Action Ev2;

        public event Action Ev3;

        private void Meth1()
        {
            _field1 = 10;
            _field2 = 12;
            if (_field1 > _field2)
            {
                _field3 = 13;
            }
        }

        protected void Meth2()
        {
        }

        public void Meth3()
        {
            Meth1();
            Ev1?.Invoke();
            Ev2?.Invoke();
            Ev3?.Invoke();
        }

        public string PrintFields()
        {
            return $"field1: {_field1}, field2: {_field2}, field3: {_field3}";
        }

        public string PrintProps()
        {
            return $"Prop1: {{Prop1}}, Prop2: {Prop2}, Prop3: {Prop3}";
        }

        public MembersClass()
        {
            _field1 = 10;
            _field2 = -14;
            _field3 = 400;
            Prop1 = 10;
            Prop3 = 100;
        }
    }
}