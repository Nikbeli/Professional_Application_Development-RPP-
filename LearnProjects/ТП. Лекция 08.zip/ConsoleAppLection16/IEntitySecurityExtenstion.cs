﻿namespace ConsoleAppLection16
{
    internal interface IEntitySecurityExtenstion<T>
	{
		/// <summary>
		/// Обработка сущности для сокрытия важных полей
		/// </summary>
		/// <param name="entity"></param>
		/// <param name="allowFullData"></param>
		/// <returns></returns>
		T SecurityCheck(T entity, bool allowFullData);
	}
}