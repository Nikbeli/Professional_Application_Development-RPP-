﻿using System;

namespace ConsoleAppLection16
{
    [AttributeUsage(AttributeTargets.Property)]
	public class MapConfigurationAttribute : Attribute
	{
		/// <summary>
		/// Название свойства с класса, из которого извлекаем данные
		/// </summary>
		public string PropertyNameFromModel { get; set; }

		/// <summary>
		/// Сложное свойство (свойствое в другом классе-свойстве)
		/// </summary>
		public bool IsDifficle { get; set; } = false;

		/// <summary>
		/// Можно копировать поле даже при доступе без прав 
		/// </summary>
		public bool AllowCopyWithoutRigth { get; set; } = true;

		/// <summary>
		/// Настройка для полей сущности правил маппинга
		/// </summary>
		/// <param name="propertyNameFromMModel">Название свойства с класса, из которого извлекаем данные</param>
		public MapConfigurationAttribute(string propertyNameFromMModel)
		{
			PropertyNameFromModel = propertyNameFromMModel;
		}
	}
}