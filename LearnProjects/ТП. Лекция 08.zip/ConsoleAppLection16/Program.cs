﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Reflection;

namespace ConsoleAppLection16
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine();

            #region Load Assembly

            //string filePath = "u:\\Teaching\\TP\\ConsoleAppLections\\ConsoleAppLection16\\bin\\Debug\\ConsoleAppLection16.exe";
            //byte[] buffer = File.ReadAllBytes(filePath);
            //var appDomain = AppDomain.CreateDomain("Test");
            //var assemblyLoad = appDomain.Load(buffer);
            //var types = assemblyLoad.GetTypes();
            //foreach (var type in types)
            //{
            //    Console.WriteLine(type.FullName);
            //}
            //Console.WriteLine();
            //filePath = "u:\\Teaching\\TP\\ConsoleAppLections\\ConsoleAppLection15\\bin\\Debug\\ConsoleAppLection15.exe";
            //if (File.Exists(filePath))
            //{
            //    var assemblyLoadFrom = Assembly.LoadFrom(filePath);
            //    if (assemblyLoadFrom != null)
            //    {
            //        Console.WriteLine(assemblyLoadFrom.FullName);
            //    }
            //}
            //Console.WriteLine();
            //filePath = "u:\\Teaching\\TP\\ConsoleAppLections\\ConsoleAppLection14\\bin\\Debug\\ConsoleAppLection14.exe";
            //if (File.Exists(filePath))
            //{
            //    var assemblyLoadFile = Assembly.LoadFile(filePath);
            //    if (assemblyLoadFile != null)
            //    {
            //        foreach (var module in assemblyLoadFile.Modules)
            //        {
            //            Console.WriteLine($"{module.Name} ({module.FullyQualifiedName})");
            //        }
            //    }
            //}

            #endregion

            #region Get Type

            //object[] values = { "word", true, 120, 136.34, 'a' };
            //foreach (var value in values)
            //{
            //    Console.WriteLine($"{value} - type {value.GetType().Name}");
            //}
            //Console.WriteLine();
            //string[] typeNames = { "System.Int32", "ConsoleAppLection16.NewClass", "ConsoleAppLection15.FileAttributes" };
            //foreach (var value in typeNames)
            //{
            //    var type = Type.GetType(value, false, true);
            //    Console.WriteLine($"{type?.Name} ({type?.BaseType?.Name})");
            //}
            //Console.WriteLine();
            //Type[] types = { typeof(NewClass), typeof(List<>), typeof(int) };
            //foreach (var type in types)
            //{
            //    Console.WriteLine($"{type.FullName} - {type.IsGenericType}");
            //}

            #endregion

            #region Get Generic Type

            //Type[] types = { typeof(List<>), typeof(List<int>), typeof(Dictionary<char, string>) };
            //foreach (var type in types)
            //{
            //    if (type.IsGenericType)
            //    {
            //        foreach(var t in type.GetGenericArguments())
            //        {
            //            Console.WriteLine($"{type.Name}:{t.FullName}");
            //        }
            //        Console.WriteLine();
            //    }
            //}

            #endregion

            #region GetProperties

            //BindingFlags bindingFlagsProp = BindingFlags.Instance | BindingFlags.Public;
            //var typeProperty = typeof(System.Windows.Forms.TextBox);
            //PropertyInfo[] propInfo = typeProperty.GetProperties(bindingFlagsProp);
            //Console.WriteLine("Свойства элемента TextBox: ");
            //for (int i = 0; i < propInfo.Length; i++)
            //{
            //    Console.WriteLine($"{propInfo[i].Name}:{(propInfo[i].CanRead ? " get" : "")}{(propInfo[i].CanWrite ? " set" : "")}");
            //}

            #endregion

            #region GetFields

            //var bindingFlagsField = BindingFlags.Instance | BindingFlags.NonPublic;
            //var typeField = typeof(System.Windows.Forms.Label);
            //FieldInfo[] fieldsType = typeField.GetFields(bindingFlagsField);

            //Console.WriteLine("Поля элемента Label: ");
            //for (int i = 0; i < fieldsType.Length; i++)
            //{
            //    Console.WriteLine($"{fieldsType[i].Name} ({fieldsType[i].FieldType})");
            //}

            #endregion

            #region GetEvents

            //var bindingFlagsEvent = BindingFlags.Instance | BindingFlags.Public;
            //var typeEvent = typeof(System.Windows.Forms.Button);
            //EventInfo[] eventsType = typeEvent.GetEvents(bindingFlagsEvent);

            //Console.WriteLine("События элемента Button: ");
            //for (int i = 0; i < eventsType.Length; i++)
            //{
            //    Console.WriteLine($"{eventsType[i].Name} ({eventsType[i].EventHandlerType.Name})");
            //}

            #endregion

            #region GetConstructors

            //var typeNewClass = typeof(NewClass);
            //ConstructorInfo[] ctors = typeNewClass.GetConstructors();

            //Console.WriteLine("Конструкторы класса NewClass: ");
            //for (int i = 0; i < ctors.Length; i++)
            //{
            //    Console.WriteLine($"{ctors[i].Name} {ctors[i].GetParameters().FirstOrDefault()?.Name}");
            //}

            #endregion

            #region GetMethods

            //var typeNewClass = typeof(NewClass);
            //MethodInfo[] methods = typeNewClass.GetMethods();

            //Console.WriteLine("Методы класса NewClass: ");
            //foreach(var meth in methods)
            //{
            //    Console.WriteLine($"{(meth.IsStatic ? "stat " : "")}{meth.ReturnType} {meth.Name}");
            //}

            #endregion

            #region GetParameters

            //var typeNewClass = typeof(NewClass);
            //var methods = typeNewClass.GetMethods();

            //Console.WriteLine("Параметры методов класса NewClass: ");
            //for (int i = 0; i < methods.Length; i++)
            //{
            //    Console.WriteLine($"Метод: {methods[i].Name}");
            //    ParameterInfo[] parameters = methods[i].GetParameters();
            //    foreach (var param in parameters)
            //    {
            //        Console.WriteLine($"\t\t{param.ParameterType} {param.Name}");
            //    }
            //}

            #endregion

            #region GetMembers

            //var typeMembersClass = typeof(MembersClass);
            //MemberInfo[] members = typeMembersClass.GetMembers();
            //foreach(var mem in members)
            //{
            //    Console.WriteLine($"{mem.MemberType}: {mem.Name}");
            //}

            #endregion

            #region GetNestedTypes

            //var typeNestedTypesClass = typeof(NestedTypesClass);
            //Type[] types = typeNestedTypesClass.GetNestedTypes();
            //foreach (var ty in types)
            //{
            //    Console.WriteLine($"{ty.Name}: {ty.IsClass}/{ty.IsValueType}/{ty.IsGenericType}/{ty.IsEnum}");
            //}

            #endregion

            #region CreateInstance Simple Type

            //var instance = Activator.CreateInstance(typeof(NewClass));
            //if (instance != null)
            //{
            //    Console.WriteLine($"Создан объект типа {instance.GetType().Name}");
            //}

            #endregion

            #region CreateInstance Dificle Type

            //var instance = Activator.CreateInstance(
            //    typeof(NewClass), 
            //    BindingFlags.NonPublic | BindingFlags.Instance, 
            //    null, 
            //    new object[] { "строка" }, 
            //    CultureInfo.CurrentCulture, 
            //    null);
            //if (instance != null)
            //{
            //    Console.WriteLine($"Создан объект типа {instance.GetType().Name}");
            //}

            #endregion

            #region CreateInstance Simple String

            //var instance = Activator.CreateInstance(null, "NewClass");
            //var instance = Activator.CreateInstance(null, "ConsoleAppLection16.NewClass");
            //if (instance != null)
            //{
            //    Console.WriteLine($"Создан объект типа {instance.GetType().Name}");
            //    var obj = instance.Unwrap();
            //    Console.WriteLine($"Получен объект типа {obj.GetType().Name}");
            //}

            #endregion

            #region CreateInstance Dificle String

            //var instance = Activator.CreateInstance(
            //    null, "ConsoleAppLection16.NewClass", true,
            //    BindingFlags.Public | BindingFlags.Instance,
            //    null,
            //    new object[] { 15 },
            //    CultureInfo.CurrentCulture,
            //    null);
            //if (instance != null)
            //{
            //    Console.WriteLine($"Создан объект типа {instance.GetType().Name}");
            //    var obj = instance.Unwrap();
            //    Console.WriteLine($"Получен объект типа {obj.GetType().Name}");
            //}

            #endregion

            #region CreateInstance Generic

            //var typeGeneric = typeof(Dictionary<,>);
            //var typeArgs = new Type[] { typeof(string), typeof(NewClass)};
            //var constructed = typeGeneric.MakeGenericType(typeArgs);
            //var instance = Activator.CreateInstance(constructed);
            //if (instance != null)
            //{
            //    var type = instance.GetType();
            //    Console.WriteLine($"Создан объект типа {type.Name}");
            //    Console.WriteLine($"Он {(type.IsGenericType ? "параметризованный" : "обычный")} тип");
            //    if (type.IsGenericType)
            //    {
            //        var genParams = type.GetGenericArguments();
            //        foreach(var par in genParams)
            //        {
            //            Console.WriteLine($"Параметр параметризованного класса: {par.Name}");
            //        }
            //    }
            //}

            #endregion

            #region SetField

            //var type = typeof(MembersClass);
            //var memClass = new MembersClass();
            //int count = 10;
            //foreach (var field in type.GetFields(BindingFlags.NonPublic | BindingFlags.Public | BindingFlags.Instance))
            //{
            //    if (field.FieldType != Type.GetType("System.Int32"))
            //    {
            //        continue;
            //    }
            //    Console.WriteLine($"field: {field.Name}");
            //    field.SetValue(memClass, count);
            //    count += 10;
            //}
            //Console.WriteLine(memClass.PrintFields());

            #endregion

            #region SetProperty

            //var type = typeof(MembersClass);
            //var memClass = new MembersClass();
            //double count = 10.5;
            //foreach (var prop in type.GetProperties(BindingFlags.NonPublic | BindingFlags.Public | BindingFlags.Instance))
            //{
            //    if (!prop.CanWrite)
            //    {
            //        continue;
            //    }
            //    Console.WriteLine($"Property: {prop.Name}");
            //    prop.SetValue(memClass, count);
            //    count += 0.3;
            //}
            //Console.WriteLine(memClass.PrintProps());

            #endregion

            #region SetEvent

            //var type = typeof(MembersClass);
            //var memClass = new MembersClass();
            //var methodInfo = typeof(NewClass).GetMethod("SimpleMethod");
            //int count = 10;
            //foreach (var ev in type.GetEvents(BindingFlags.Public | BindingFlags.Instance))
            //{
            //    var newClass = new NewClass(count);
            //    Console.WriteLine($"Event: {ev.Name}");
            //    var handler = Delegate.CreateDelegate(ev.EventHandlerType, newClass, methodInfo);
            //    ev.AddEventHandler(memClass, handler);
            //    count += 15;
            //}
            //memClass.Meth3();

            #endregion

            #region GetField

            //var type = typeof(MembersClass);
            //var memClass = new MembersClass();
            //foreach (var field in type.GetFields(BindingFlags.NonPublic | BindingFlags.Public | BindingFlags.Instance))
            //{
            //    if (field.FieldType != Type.GetType("System.Int32"))
            //    {
            //        continue;
            //    }
            //    Console.WriteLine($"field: {field.Name}, value: {field.GetValue(memClass)}");
            //}

            #endregion

            #region GetProperty

            //var type = typeof(MembersClass);
            //var memClass = new MembersClass();
            //foreach (var prop in type.GetProperties(BindingFlags.NonPublic | BindingFlags.Public | BindingFlags.Instance))
            //{
            //    if (!prop.CanRead)
            //    {
            //        continue;
            //    }
            //    Console.WriteLine($"Property: {prop.Name}, value {prop.GetValue(memClass)}");
            //}

            #endregion

            #region InvokeMember

            //var newClass = new NewClass();
            //var type = typeof(NewClass);

            //type.InvokeMember("HelloWorld",
            //    BindingFlags.InvokeMethod | BindingFlags.Public | BindingFlags.Static,
            //    null, null, new object[] { });

            //type.InvokeMember("MethodFirst",
            //    BindingFlags.InvokeMethod | BindingFlags.Public | BindingFlags.Instance,
            //    null, newClass, new object[] { 10, "abs" });

            //type.InvokeMember("MethodSecond",
            //    BindingFlags.InvokeMethod | BindingFlags.Public | BindingFlags.Instance | BindingFlags.OptionalParamBinding,
            //    null, newClass, new object[] { 10, Missing.Value });

            //type.InvokeMember("MethodThird",
            //    BindingFlags.InvokeMethod | BindingFlags.Public | BindingFlags.Instance,
            //    null, newClass, new object[] { 10.5, 15.3 }, null ,null, new string[] { "s", "d"});

            #endregion

            #region Invoke

            //var asm = typeof(DatabaseManager).Assembly;
            //var newClass = new NewClass();
            //MethodInfo method = typeof(NewClass).GetType().GetTypeInfo().GetDeclaredMethod("SaveToFile");
            //foreach (var t in asm.GetExportedTypes())
            //{
            //    if (t.IsClass && t.GetInterfaces().Any(i => i.IsGenericType && 
            //        i.GetGenericTypeDefinition() == typeof(IEntitySecurityExtenstion<>)) &&
            //        t.GetCustomAttribute<EntityDescriptionAttribute>() != null)
            //    {
            //        MethodInfo generic = method.MakeGenericMethod(t);
            //        generic.Invoke(newClass, new object[] { "fileName", false, t });
            //    }
            //}

            #endregion

            #region GetCustomAttributes Attribute

            //var type = typeof(NewClass);
            //foreach (Attribute attr in Attribute.GetCustomAttributes(type))
            //{
            //    if (attr is CommentAttribute attribute)
            //        Console.WriteLine($"{attribute.Comment}  дата: {attribute.Date}");
            //}

            #endregion

            #region GetCustomAttributes Attribute

            //var type = typeof(MembersClass);
            //foreach (var prop in type.GetProperties(BindingFlags.NonPublic | BindingFlags.Public | BindingFlags.Instance))
            //{
            //    foreach (Attribute attr in prop.GetCustomAttributes())
            //    {
            //        if (attr is MapConfigurationAttribute attribute)
            //            Console.WriteLine($"{attribute.PropertyNameFromModel} сложное: {(attribute.IsDifficle ? "да" : "нет")}");
            //    }
            //}

            #endregion

            Console.ReadKey();
        }

        #region Get Set Properties by Type example

        private static To FillObject<From, To>(From obj, To newObject, bool haveRigth)
        where To : class
        {
            if (obj == null)
            {
                return null;
            }
            if (newObject == null)
            {
                newObject = Activator.CreateInstance(typeof(To)) as To;
            }
            var typeFrom = typeof(From);
            var typeTo = typeof(To);
            var properties = typeTo.GetProperties();
            foreach (var property in properties)
            {
                var customAttribute = property.GetCustomAttribute<MapConfigurationAttribute>();
                if (customAttribute != null)
                {
                    object value = obj;
                    if (customAttribute.IsDifficle)
                    {
                        var props = customAttribute.PropertyNameFromModel.Split('.');
                        foreach (var prop in props)
                        {
                            if (prop == "ToString")
                            {
                                value = value.ToString();
                                break;
                            }
                            else if (prop == "Count")
                            {
                                value = (value as ICollection)?.Count;
                                break;
                            }
                            var bindingProperty = value.GetType().GetProperty(prop);
                            if (bindingProperty != null)
                            {
                                value = bindingProperty.GetValue(value);
                                if (value is null)
                                {
                                    break;
                                }
                            }
                            else
                            {
                                value = null;
                                break;
                            }
                        }
                    }
                    else
                    {
                        if (customAttribute.PropertyNameFromModel == "ToString")
                        {
                            value = value.ToString();
                        }
                        var bindingProperty = typeFrom.GetProperty(customAttribute.PropertyNameFromModel);
                        if (bindingProperty != null)
                        {
                            value = bindingProperty.GetValue(obj);
                        }
                    }
                    if (value is null)
                    {
                        continue;
                    }
                    if ((haveRigth && !customAttribute.AllowCopyWithoutRigth) || customAttribute.AllowCopyWithoutRigth)
                    {
                        if (property.PropertyType.Name.StartsWith("Nullable"))
                        {
                            if (Nullable.GetUnderlyingType(property.PropertyType).IsEnum)
                            {
                                property.SetValue(newObject, Enum.Parse(Nullable.GetUnderlyingType(property.PropertyType), value.ToString()));
                                continue;
                            }
                        }
                        property.SetValue(newObject, value);
                    }
                }
            }

            return newObject;
        }

        #endregion
    }
}
