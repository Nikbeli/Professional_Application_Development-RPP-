﻿using System;

namespace ConsoleAppLection16
{
    internal class EntityDescriptionAttribute : Attribute
    {
    }
}