﻿namespace ConsoleAppLection16
{
    internal class DatabaseManager
    {
        public static DatabaseContext GetContext => new DatabaseContext();
    }
}