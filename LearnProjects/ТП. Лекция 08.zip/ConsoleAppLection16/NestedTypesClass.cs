﻿namespace ConsoleAppLection16
{
    class NestedTypesClass
    {
        public enum PublicEnum { }

        public struct PublicStruct
        {
            public struct InsideStruct { }
        }

        public class PublicClass
        {
            public class InsideClass { }
        }

        public delegate void PublicDelegate();
    }
}