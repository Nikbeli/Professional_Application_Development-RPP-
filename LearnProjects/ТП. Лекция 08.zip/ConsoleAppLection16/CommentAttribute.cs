﻿using System;

namespace ConsoleAppLection16
{
    [AttributeUsage(AttributeTargets.Class)]
    public class CommentAttribute : Attribute
    {
        public string Comment { get; set; }

        public DateTime Date { get; set; }

        public CommentAttribute()
        {
            Comment = "Нет комментария";
            Date = DateTime.Now;
        }

        public CommentAttribute(string comment)
        {
            Comment = comment;
            Date = DateTime.Now;
        }
    }
}