﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Xml.Serialization;

namespace ConsoleAppLection16
{
    [Comment("NewClass")]
    public class NewClass
    {
        //[Comment("FieldNewClass")]
        private int _a;

        //[Comment("ConstructorNewClass")]
        public NewClass()
        {
            Console.WriteLine("Вызывали конструктор без параметров класса NewClass");
        }

        public NewClass(int a)
        {
            _a = a;
            Console.WriteLine($"Вызывали конструктор c параметром a={a} класса NewClass");
        }

        private NewClass(string s)
        {
            Console.WriteLine($"Вызывали конструктор c параметром s={s} класса NewClass");
        }

        //[Comment("MethodClass")]
        public static void HelloWorld()
        {
            Console.WriteLine("Hello world");
        }

        public void MethodFirst(int a, string b) 
        {
            Console.WriteLine($"a = {a}, b = {b}");
        }

        public int MethodSecond(double d, string s = "default") 
        {
            Console.WriteLine($"d = {d}, s = {s}");
            return -1;
        }

        public int MethodThird(double d, double s)
        {
            Console.WriteLine($"d = {d}, s = {s}");
            return -1;
        }

        public void SimpleMethod()
        {
            Console.WriteLine($"Простой метод  с параметром {_a}");
        }

        private void SaveToFile<T>(string folderName, bool allowFullData, Type t) where T : class, IEntitySecurityExtenstion<T>, new()
        {
            using (var context = DatabaseManager.GetContext)
            { 
                var records = context.Set<T>().Select(x => x.SecurityCheck(x, allowFullData));
                var jsonFormatter = new XmlSerializer(typeof(List<T>));
                using (var fs = new FileStream(string.Format("{0}/{1}.xml", folderName, t.Name), FileMode.OpenOrCreate))
                    jsonFormatter.Serialize(fs, records); 
            }
        }
    }
}