﻿using System.Data.Entity;

namespace ConsoleAppLection16
{
    public class DatabaseContext : DbContext
    {
    }
}