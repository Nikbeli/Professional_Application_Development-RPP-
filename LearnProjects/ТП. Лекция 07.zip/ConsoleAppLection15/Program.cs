﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;

namespace ConsoleAppLection15
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine();

            #region Simple String Add

            bool flag1 = true;
            bool flag2 = true;

            string str = "";

            if (flag1)
            {
                str += "Hello";
            }
            if (flag2)
            {
                if (str.Length > 0)
                {
                    str += " ";
                }
                str += "world";
            }

            //Console.WriteLine(str);

            #endregion

            #region Concat

            var animals = new List<string>
            {
                "Hello",
                " ",
                "world"
            };
            var strConcateEnum = string.Concat(animals.Select(a => a));

            var strConcateStrs = string.Concat("Hello", " ", "world");

            var strConcateObjs = string.Concat(new ClassToString("Hello"),
                new ClassToString(" "), new ClassToString("world"));

            var strs = new string[] { "Hello ", "  ", "world" };
            var strConcateStrArray = string.Concat(strs);

            //Console.WriteLine(strConcateEnum);
            //Console.WriteLine(strConcateStrs);
            //Console.WriteLine(strConcateObjs);
            //Console.WriteLine(strConcateStrArray);

            #endregion

            #region Join

            var strsJoin = new string[] { "Hello ", "  ", "world", "in", "C#" };
            var strJoinFull = string.Join("_", strsJoin);
            var strJoinPart = string.Join("_", strsJoin, 2, 3);

            var words = new List<string>
            {
                "Hello",
                " ",
                "world"
            };
            string strJoinEnum = string.Join(",", words);

            var objs = new List<ClassToString>
            {
                new ClassToString("Hello"),
                new ClassToString(" "),
                new ClassToString("world")
            };
            string strJoinObjs = string.Join(" ", objs);

            //Console.WriteLine(strJoinFull);
            //Console.WriteLine(strJoinPart);
            //Console.WriteLine(strJoinEnum);
            //Console.WriteLine(strJoinObjs);

            #endregion

            #region StringBuilder

            var sb = new StringBuilder();
            if (flag1)
            {
                sb.Append("Hello");
            }
            if (flag2)
            {
                if (sb.Length > 0)
                {
                    sb.Append(" ");
                }
                sb.Append("world");
            }
            // Console.WriteLine(sb.ToString());

            #endregion

            #region Format

            int d = 10;
            double f = 4.5;
            int price = 34;
            var format = string.Format("Мне {0} штук кругов диаметром {1} по цене {2:C2}", d, f, price);
            //Console.WriteLine(format);

            #endregion

            #region $

            int count = 10;
            double r = 4.5;
            int cost = 34;
            var strInter = $"Мне {count} штук кругов диаметром {r} по цене {cost:C2}";
            //Console.WriteLine(strInter);

            #endregion

            #region $ vs format

            var format2 = string.Format("Круг диаметром {1}{3}Количество {0} штук{3}Цена {2:C2}", d, f, price, Environment.NewLine);

            var strInter2 = $"Круг диаметром {r}{Environment.NewLine}Количество {count} штук{Environment.NewLine}Цена {cost:C2}";

            #endregion

            #region CultureInfo

            //var cultureNames = new string[] { "en-US", "fr-FR", "de-DE", "es-ES" };

            //var dateToDisplay = new DateTime(2009, 9, 1, 18, 32, 0);
            //double valueCF = 9164.32;

            //Console.WriteLine("Culture     Date                                Value");
            //foreach (string cultureName in cultureNames)
            //{
            //    var culture = new CultureInfo(cultureName);
            //    string output = string.Format(culture, "{0,-11} {1,-35:D} {2:N}", culture.Name, dateToDisplay, valueCF);
            //    Console.WriteLine(output);
            //}

            //var cultureName = CultureInfo.CurrentCulture.Name;

            //Console.WriteLine(CultureInfo.CurrentCulture.Name);
            //Console.WriteLine(string.Format("{0,-35:D}", dateToDisplay));

            //CultureInfo.CurrentCulture = new CultureInfo("pt-BR");
            //Console.WriteLine(CultureInfo.CurrentCulture.Name);
            //Console.WriteLine(string.Format("{0,-35:D}", dateToDisplay));

            //CultureInfo.CurrentCulture = new CultureInfo(cultureName);
            #endregion

            #region Number format

            //double value = 12345.6789;
            //int numValue = 12345;

            //Console.WriteLine(value.ToString("C", CultureInfo.CurrentCulture));

            //Console.WriteLine(value.ToString("c3", CultureInfo.InvariantCulture));

            //Console.WriteLine(numValue.ToString("D"));

            //Console.WriteLine(numValue.ToString("d8"));

            //Console.WriteLine(value.ToString("E", CultureInfo.CurrentCulture));

            //Console.WriteLine(numValue.ToString("e10", CultureInfo.InvariantCulture));

            //Console.WriteLine(value.ToString("F", CultureInfo.InvariantCulture));

            //Console.WriteLine(numValue.ToString("f0", CultureInfo.CurrentCulture));

            //Console.WriteLine(value.ToString("G", CultureInfo.InvariantCulture));

            //Console.WriteLine(value.ToString("g5", CultureInfo.CurrentCulture));

            //Console.WriteLine();

            //Console.WriteLine(value.ToString("P", CultureInfo.InvariantCulture));

            //Console.WriteLine(numValue.ToString("P1", CultureInfo.CurrentCulture));

            //Console.WriteLine(value.ToString("N", CultureInfo.InvariantCulture));

            //Console.WriteLine(numValue.ToString("N2", CultureInfo.CurrentCulture));

            //Console.WriteLine(value.ToString("R", CultureInfo.InvariantCulture));

            //Console.WriteLine(value.ToString("r9", CultureInfo.CurrentCulture));

            //Console.WriteLine(numValue.ToString("X", CultureInfo.InvariantCulture));

            //Console.WriteLine(numValue.ToString("x8", CultureInfo.CurrentCulture));

            #endregion

            #region Date format

            //var date = new DateTime(2017, 4, 10, 6, 30, 0);

            //Console.WriteLine(date.ToString("d", DateTimeFormatInfo.InvariantInfo));

            //Console.WriteLine(date.ToString("D",  CultureInfo.CreateSpecificCulture("en-US")));

            //Console.WriteLine(date.ToString("f", DateTimeFormatInfo.InvariantInfo));

            //Console.WriteLine(date.ToString("F", CultureInfo.CreateSpecificCulture("fr-FR")));

            //Console.WriteLine(date.ToString("g", DateTimeFormatInfo.InvariantInfo));

            //Console.WriteLine(date.ToString("G", CultureInfo.CreateSpecificCulture("en-us")));

            //Console.WriteLine(date.ToString("t", CultureInfo.CreateSpecificCulture("Ru-ru")));

            //Console.WriteLine(date.ToString("T", CultureInfo.CreateSpecificCulture("en-us")));

            #endregion

            #region MyDate format

            //var now = DateTime.Now;

            //Console.WriteLine(now.ToString("hh:mm:ss"));

            //Console.WriteLine(now.ToString("dd.MM.yyyy"));

            //Console.WriteLine(now.ToString("zz hh mm "));

            //Console.WriteLine(now.ToString("g ddd"));

            //Console.WriteLine(now.ToString("tt hh mm "));

            #endregion

            #region Enum format

            //var attributes = FileAttributes.Hidden | FileAttributes.Archive;

            //Console.WriteLine(ConsoleColor.Red.ToString("G"));

            //Console.WriteLine(attributes.ToString("G"));

            //Console.WriteLine(ConsoleColor.Red.ToString("F"));

            //Console.WriteLine(attributes.ToString("f"));

            //Console.WriteLine(ConsoleColor.Cyan.ToString("D"));

            //Console.WriteLine(attributes.ToString("D"));

            #endregion

            #region TimeSpan format

            //var span = new TimeSpan(27, 45, 16);

            //Console.WriteLine(span.ToString("c"));

            //Console.WriteLine(span.ToString("c", CultureInfo.InvariantCulture));

            //Console.WriteLine(span.ToString("g"));

            //Console.WriteLine(span.ToString("g", new CultureInfo("fr-FR")));

            //Console.WriteLine(span.ToString("G", new CultureInfo("pt-BR")));

            //Console.WriteLine(span.ToString("G", CultureInfo.InvariantCulture));

            #endregion

            #region GUID

            //var guid = Guid.NewGuid();

            //Console.WriteLine(guid.ToString("N"));

            //Console.WriteLine(guid.ToString("D", CultureInfo.InvariantCulture));

            //Console.WriteLine(guid.ToString("B"));

            //Console.WriteLine(guid.ToString("P", new CultureInfo("fr-FR")));

            //Console.WriteLine(guid.ToString("X", new CultureInfo("pt-BR")));

            #endregion

            #region Regex Simple

            //var reg = new Regex(@"\s\d{5}$");

            //var isMatch1 = reg.IsMatch("Много текста и число: 123456");
            //var isMatch2 = reg.IsMatch("Много текста и число: 12345");
            //var isMatch3 = reg.IsMatch("Много текста и число:12345");
            //var isMatch4 = reg.IsMatch("Много текста и число: 12345.");

            //Console.WriteLine($"В первом тексте {(isMatch1? "" : "не ")}найдено пятизначное число");
            //Console.WriteLine($"Во втором тексте {(isMatch2 ? "" : "не ")}найдено пятизначное число");
            //Console.WriteLine($"В третьем тексте {(isMatch3 ? "" : "не ")}найдено пятизначное число");
            //Console.WriteLine($"В четвертом тексте {(isMatch4 ? "" : "не ")}найдено пятизначное число");

            #endregion

            #region Regex Phone Number

            //var phones = new string[] { 
            //    "Иванов Иван Иванович. Адвокат. Телефон: 456-435-2318. Звоните в любое время.",
            //    "Смирнов Иван Владимирович. Звонить по вопросам налоговых сборов по телефону 555-234-5677",
            //    "Фирма \"Бегемот и Ко\". Починяем примусы. 333-567-7777" };
            //foreach(var elem in phones)
            //{
            //    var match = Regex.Match(elem, @"\d{3}-\d{3}-\d{4}");
            //    if (match.Success)
            //    {
            //        Console.WriteLine($"Телефон: {match.Value}");
            //    }
            //}

            #endregion

            #region Regex Symbols

            //var mathcColw = Regex.Matches("... Много букв, которые собираются в слова. 4626356", @"\w");
            //foreach(Match matchw in mathcColw)
            //{
            //    Console.Write(matchw.Value);
            //}
            //Console.WriteLine(); Console.WriteLine();
            //var mathcColW = Regex.Matches("... Много букв, которые собираются в слова. 4626356", @"\W");
            //foreach (Match matchw in mathcColW)
            //{
            //    Console.Write(matchw.Value);
            //}
            //Console.WriteLine(); Console.WriteLine();
            //var mathcCols = Regex.Matches("... Много букв, которые собираются в слова. 4626356", @"\s");
            //foreach (Match matchw in mathcCols)
            //{
            //    Console.Write($"'{matchw.Value}'");
            //}
            //Console.WriteLine(); Console.WriteLine();
            //var mathcColS = Regex.Matches("... Много букв, которые собираются в слова. 4626356", @"\S");
            //foreach (Match matchw in mathcColS)
            //{
            //    Console.Write(matchw.Value);
            //}
            //Console.WriteLine(); Console.WriteLine();
            //var mathcCold = Regex.Matches("... Много букв, которые собираются в слова. 4626356", @"\d");
            //foreach (Match matchw in mathcCold)
            //{
            //    Console.Write(matchw.Value);
            //}
            //Console.WriteLine(); Console.WriteLine();
            //var mathcColD = Regex.Matches("... Много букв, которые собираются в слова. 4626356", @"\D");
            //foreach (Match matchw in mathcColD)
            //{
            //    Console.Write(matchw.Value);
            //}
            //Console.WriteLine(); Console.WriteLine();

            #endregion

            #region Regex Groups

            //var text = "Как много очей скрыто во тьме. Каждое око смотрит на тебя. Около окна сидит кот.";
            //var filterText = Regex.Replace(text, @"[око]", "*", RegexOptions.IgnoreCase);
            //Console.WriteLine(filterText);
            //Console.WriteLine();
            //var inverseText = Regex.Replace(text, @"[^око]", "?", RegexOptions.IgnoreCase);
            //Console.WriteLine(inverseText);
            //Console.WriteLine();
            //var partText = Regex.Replace(text, @"[а-м]", "_", RegexOptions.IgnoreCase);
            //Console.WriteLine(partText);
            //Console.WriteLine();

            #endregion

            #region Regex Links

            //var regexDigitPoint = new Regex(@"^\d(.)*\.$");
            //var regexDigit = new Regex(@"^\d");
            //var regexPoint = new Regex(@"\.$");
            //var texts = new string[] { 
            //    "Привет, меня зовут Андрей, мне 35 лет.",
            //    "33 года Илья Муромец сидел на печи.",
            //    "3 дня и 3 ночи" };
            //foreach(var text in texts)
            //{
            //    if (regexDigitPoint.IsMatch(text))
            //    {
            //        Console.WriteLine($"Начинается на число, заканчивается на точку: {text}");
            //    }
            //    if (regexDigit.IsMatch(text))
            //    {
            //        Console.WriteLine($"Начинается на число: {text}");
            //    }
            //    if (regexPoint.IsMatch(text))
            //    {
            //        Console.WriteLine($"Заканчивается на точку: {text}");
            //    }
            //}

            #endregion

            #region Regex Kvantor

            //var phoneReg = new Regex(@"^(\(\d+\))*\d{2}-\d{2}-\d{2}$");
            //var mobileReg = new Regex(@"^\+*\d{1,11}(-\d{3}-\d{3}-\d{2,4}(-\d{2})*)*$");

            //var numbers = new string[] { "(8422)58-48-78", "74-84-87", 
            //    "+7-906-458-5898", "+75894581254", "8-456-789-48-89",
            //    "586-459-488 78", "489215768514" };
            //foreach(var num in numbers)
            //{
            //    if (phoneReg.IsMatch(num))
            //    {
            //        Console.WriteLine($"Городской номер: {num}");
            //    }
            //    else if (mobileReg.IsMatch(num))
            //    {
            //        Console.WriteLine($"Мобильный номер: {num}");
            //    }
            //    else
            //    {
            //        Console.WriteLine($"не телефонный номер: {num}");
            //    }
            //}

            #endregion

            #region Regex Select

            //var phoneReg = new Regex(@"^(((\+7|8)( )?\(?\d{3}\)?)|(\(\d{4}\)))?( )?\d{2}(-| )?\d{2}(-| )?\d{2}$");

            //var numbers = new string[] { "(8422)58-48-78", "+7 (453) 78 89 48",
            //    "8 959 48 56 48", "(8422) 58-48-78", "(8422)584878",
            //    "586-459-488 78", "489215768514" };
            //foreach (var num in numbers)
            //{
            //    if (phoneReg.IsMatch(num))
            //    {
            //        Console.WriteLine($"Городской номер: {num}");
            //    }
            //    else
            //    {
            //        Console.WriteLine($"неидентифицируемое число: {num}");
            //    }
            //}

            #endregion

            #region Regex Verifi

            //Console.Write("Введите имя: ");
            //while (!Regex.Match(Console.ReadLine(), "^[А-Я][а-яА-Я]*$").Success)
            //{
            //    Console.Write("Некорректно! Введите имя: ");
            //}
            //Console.Write("Введите адрес (индекс, город, улица, дом, квартира): ");
            //while (!Regex.Match(Console.ReadLine(),
            //    @"^([0-9]){6}[,\s]+([а-я]+\.\s)?[а-яА-Я]+[,\s]+([а-я]+\.\s)?[а-яА-Я ]+[,\s]+(д\.)?[0-9]+[,\s]+((кв\.)?[0-9]+)?$").Success)
            //{
            //    Console.Write("Некорректно! Введите адрес: ");
            //}
            //Console.Write("Введите номер мобильного телефона: ");
            //while (!Regex.Match(Console.ReadLine(),
            //    @"^(\+7|8|\b)[\(\s-]*(\d)[\s-]*(\d)[\s-]*(\d)[)\s-]*(\d)[\s-]*(\d)[\s-]*(\d)[\s-]*(\d)[\s-]*(\d)[\s-]*(\d)[\s-]*(\d)?$").Success)
            //{
            //    Console.Write("Некорректно! Введите номер мобильного телефона: ");
            //}

            #endregion

            #region Regex Classroom

            //var lessons = new string[] { "ИСЭбд-22 пр.Статистика Алексеева В А 2-401",
            //    "ПИбд-21 пр.Элективные курсы по физичeской культуре и спорту Преподаватели кафедры 2-С3",
            //    "ПИбд-22 Лаб.Интернет-программирование- 1 п/г Филиппов А А 3-418а",
            //    "ИСЭбд-21 Лаб.Системы управления базами данных Шеркунов В В 3-418а ИСЭбд-21 Технология программирования Эгов Е Н 3-424/2"};

            //foreach (var lesson in lessons)
            //{
            //    var classroomMatches = Regex.Matches(lesson, @"\d(.|..|.. )?(_|-)(.|..)?([\d]+(/[\d]+)*([\w]+)*|[\w. ]+)");
            //    foreach (Match classroom in classroomMatches)
            //    {
            //        Console.WriteLine($"Аудитория: {classroom.Value}");
            //    }
            //}

            #endregion

            #region Regex Email

            //string pattern = @"^(?("")(""[^""]+?""@)|(([0-9a-z]((\.(?!\.))|[-!#\$%&'\*\+/=\?\^`\{\}\|~\w])*)(?<=[0-9a-z])@))" +
            //    @"(?(\[)(\[(\d{1,3}\.){3}\d{1,3}\])|(([0-9a-z][-\w]*[0-9a-z]*\.)+[a-z0-9]{2,17}))$";

            //string email1 = "someMilo@ttt.com";
            //string email2 = "@ttt.com";
            //string email3 = "someMilo.com";
            //string email4 = "someMilo@ttt";

            //if (Regex.IsMatch(email1, pattern, RegexOptions.IgnoreCase))
            //{
            //    Console.WriteLine("Email1 подтвержден");
            //}
            //if (Regex.IsMatch(email2, pattern, RegexOptions.IgnoreCase))
            //{
            //    Console.WriteLine("Email2 подтвержден");
            //}
            //if (Regex.IsMatch(email3, pattern, RegexOptions.IgnoreCase))
            //{
            //    Console.WriteLine("Email3 подтвержден");
            //}
            //if (Regex.IsMatch(email4, pattern, RegexOptions.IgnoreCase))
            //{
            //    Console.WriteLine("Email4 подтвержден");
            //}

            #endregion

            Console.ReadKey();
        }
    }
}