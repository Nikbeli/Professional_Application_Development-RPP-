﻿namespace ConsoleAppLection15
{
    class ClassToString
    {
        private readonly string _field;

        public ClassToString(string data)
        {
            _field = data;
        }

        public override string ToString()
        {
            return _field;
        }
    }
}