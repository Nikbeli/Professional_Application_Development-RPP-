﻿using System;

namespace ConsoleAppLection15
{
    [Flags]
    enum FileAttributes
    {
        Hidden = 1,

        Archive = 2
    }
}
