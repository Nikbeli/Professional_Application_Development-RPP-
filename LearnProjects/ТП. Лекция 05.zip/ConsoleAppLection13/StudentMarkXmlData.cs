﻿namespace ConsoleAppLection13
{
    public class StudentMarkXmlData
    {
        public string Exam { get; set; }

        public int Mark { get; set; }
    }
}