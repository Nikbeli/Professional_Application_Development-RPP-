﻿using System.Runtime.InteropServices;

namespace ConsoleAppLection13
{
    public class ClassWithMarshaling
    {
        [MarshalAs(UnmanagedType.LPStr)]
        private string _filed1;

        private decimal _money;

        public decimal Money
        {
            [return: MarshalAs(UnmanagedType.Currency)]
            get { return _money; }
            [param: MarshalAs(UnmanagedType.Currency)]
            set { _money = value; }
        }

        public void SomeMethod([MarshalAs(UnmanagedType.LPStr)] string s)
        {
            _filed1 = s;
        }

        [return: MarshalAs(UnmanagedType.Interface)]
        public object GetItem([In, MarshalAs(UnmanagedType.BStr)] string bstrName)
        {
            if (bstrName != null)
            {
                return _filed1;
            }
            return Money;
        }

        public void GetItems([In, MarshalAs(UnmanagedType.BStr)] string bstrLocation,
            [Out, MarshalAs( UnmanagedType.SafeArray, SafeArraySubType = VarEnum.VT_VARIANT )] out object[] Items)
        {
            if (bstrLocation != null)
            {
                _filed1 = bstrLocation;
                Items = new object[0];
            }

            Items = new object[] { _filed1, _money };
        }
    }
}