﻿namespace ConsoleAppLection13
{
    public class StudentJsonData
    {
        public string FirstName { get; set; }

        public string LastName { get; set; }

        public int Age { get; set; }

        public GenderXmlData Gender { get; set; }

        public StudentMarkXmlData[] Marks { get; set; }

        public double AveargeBall { get; set; }

        private string studentBookName;

        public StudentJsonData(string bookName)
        {
            studentBookName = bookName;
        }

        public StudentJsonData() { }
    }
}