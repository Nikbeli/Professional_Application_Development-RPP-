﻿using System;

namespace ConsoleAppLection13
{
    [Serializable]
    class BaseSerializable
    {
        public int serField;

        [NonSerialized]
        public string notSerField;

        private double privateField;

        public BaseSerializable(int n, string s, double d)
        {
            serField = n;
            notSerField = s;
            privateField = d;
        }

        public double GetPrivateField => privateField;
    }
}