﻿using System;
using System.Runtime.Serialization;

namespace ConsoleAppLection13
{
    [Serializable]
    class PackageSender
    {
        public DateTime sendTime;

        public object data;

        private double timeForSend;

        [OnSerializing]
        private void SetValuesOnSerializing(StreamingContext context)
        {
            sendTime = DateTime.UtcNow;
        }

        [OnDeserializing]
        private void SetValuesOnDeserializing(StreamingContext context)
        {
            var nowTime = DateTime.UtcNow;
            timeForSend = (nowTime - sendTime).TotalSeconds;
        }

        public double GetTimeForSend => timeForSend;
    }
}