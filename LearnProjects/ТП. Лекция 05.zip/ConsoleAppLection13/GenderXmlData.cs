﻿using System.Xml.Serialization;

namespace ConsoleAppLection13
{
    public enum GenderXmlData
    {
        [XmlEnum(Name = "Men")]
        Male,
        [XmlEnum(Name = "Women")]
        Female
    }
}