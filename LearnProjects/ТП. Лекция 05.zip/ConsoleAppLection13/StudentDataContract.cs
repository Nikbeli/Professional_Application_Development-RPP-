﻿using System.Runtime.Serialization;

namespace ConsoleAppLection13
{
    [DataContract]
    public class StudentDataContract
    {
        [DataMember]
        public string FirstName { get; set; }

        [DataMember]
        public string LastName { get; set; }

        public int Age { get; set; }

        [DataMember]
        public GenderXmlData Gender { get; set; }

        [DataMember]
        public StudentMarkXmlData[] Marks { get; set; }

        public double AveargeBall { get; set; }

        [DataMember]
        private string studentBookName;

        public StudentDataContract(string bookName)
        {
            studentBookName = bookName;
        }
    }
}