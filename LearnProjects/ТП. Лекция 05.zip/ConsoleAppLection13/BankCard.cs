﻿using System;
using System.Runtime.Serialization;

namespace ConsoleAppLection13
{
    [Serializable]
    class BankCard : ISerializable
    {
        private string cardNumber;

        private string fioOwner;

        public void GetObjectData(SerializationInfo info, StreamingContext context)
        {
            info.AddValue("field1", Crypto(cardNumber));
            info.AddValue("field2", Crypto(fioOwner));
        }

        public BankCard(SerializationInfo info, StreamingContext context)
        {
            if (info == null)
            {
                throw new ArgumentNullException("info");
            }
            cardNumber = (string)Decrypto(info.GetValue("field1", typeof(string)));
            fioOwner = (string)Decrypto(info.GetValue("field2", typeof(string)));
        }

        private string Crypto(object data)
        {
            return data.ToString();
        }

        private object Decrypto(object data)
        {
            return data;
        }
    }
}