﻿using System.Xml.Serialization;

namespace ConsoleAppLection13
{
    [XmlRoot]
    public class StudentXmlData
    {
        public string FirstName { get; set; }

        [XmlElement(typeof(string), ElementName = "StudentName")]
        public string LastName { get; set; }

        [XmlAttribute]
        public int Age { get; set; }

        [XmlAttribute(AttributeName = "Sex")]
        public GenderXmlData Gender { get; set; }

        [XmlArrayItem(ElementName = "Mark", IsNullable = true, Type = typeof(StudentMarkXmlData))]
        [XmlArray]
        public StudentMarkXmlData[] Marks { get; set; }

        [XmlIgnore]
        public double AveargeBall { get; set; }

        [XmlAttribute(AttributeName = "studentBookName")]
        private string studentBookName;

        public StudentXmlData(string bookName)
        {
            studentBookName = bookName;
        }

        public StudentXmlData() { }
    }
}