﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;
using System.Runtime.Serialization.Formatters.Soap;
using System.Runtime.Serialization.Json;
using System.Text.Json;
using System.Xml;
using System.Xml.Linq;
using System.Xml.Serialization;

namespace ConsoleAppLection13
{
    class Program
    {
        private static void SaveIFormatter(string fileName, IFormatter formatter, object data) 
        {
            if (string.IsNullOrEmpty(fileName) || formatter == null || data ==null)
            {
                return;
            }
            using (var fs = new FileStream(fileName, FileMode.OpenOrCreate))
            {
                formatter.Serialize(fs, data);
            }
        }

        private static object LoadIFormatter(string fileName, IFormatter formatter)
        {
            if (string.IsNullOrEmpty(fileName) || formatter == null)
            {
                return null;
            }
            using (var fs = new FileStream(fileName, FileMode.OpenOrCreate))
            {
                return formatter.Deserialize(fs);
            }
        }

        static void Main(string[] args)
        {
            #region BinaryFormatter

            var binaryBaseList = new List<BaseSerializable>
            {
                new BaseSerializable(10, "state 1", 5.5),
                new BaseSerializable(15, "state 2", 3.5),
                new BaseSerializable(20, "state 3", 5.2),
                new BaseSerializable(25, "state 4", 7.3),
            };

            var fileNameBinary = "baseBinary.bin";
            SaveIFormatter(fileNameBinary, new BinaryFormatter(), binaryBaseList);
            var newbinaryBaseList = LoadIFormatter(fileNameBinary, new BinaryFormatter()) as List<BaseSerializable>;
            foreach (var elem in newbinaryBaseList)
            {
                Console.WriteLine("Elem: {0} - {1} - {2}", elem.serField, elem.notSerField, elem.GetPrivateField);
            }

            Console.WriteLine();
            #endregion

            #region SOAPFormatter

            var soapBaseList = new List<BaseSerializable>
            {
                new BaseSerializable(10, "state 1", 5.5),
                new BaseSerializable(15, "state 2", 3.5),
                new BaseSerializable(20, "state 3", 5.2),
                new BaseSerializable(25, "state 4", 7.3),
            };

            var fileNameSOAP = "baseSOAP.xml";
            SaveIFormatter(fileNameSOAP, new SoapFormatter(), soapBaseList.ToArray());
            var newsoapBaseList = LoadIFormatter(fileNameSOAP, new SoapFormatter()) as BaseSerializable[];
            foreach (var elem in newsoapBaseList)
            {
                Console.WriteLine("Elem: {0} - {1} - {2}", elem.serField, elem.notSerField, elem.GetPrivateField);
            }

            Console.WriteLine();

            #endregion

            #region XmlSerializer

            var student = new StudentXmlData("00/000")
            {
                Age = 19,
                Gender = GenderXmlData.Male,
                FirstName = "Ivan",
                LastName = "Ivanov",
                Marks = null
            };
            var formatter = new XmlSerializer(typeof(StudentXmlData));
            using (var fs = new FileStream($"{student.LastName}.xml", FileMode.OpenOrCreate))
            {
                formatter.Serialize(fs, student);
            }

            using (var fs = new FileStream($"{student.LastName}.xml", FileMode.OpenOrCreate))
            {
                var newStudent = (StudentXmlData)formatter.Deserialize(fs);
                Console.WriteLine("Student: {0} {1} {2} {3}", newStudent.LastName, newStudent.FirstName, newStudent.Age, newStudent.Gender);
            }

            Console.WriteLine();

            var studentList = new List<StudentXmlData>()
            {
                student,
                new StudentXmlData("00/000")
                {
                    Age = 19,
                    Gender = GenderXmlData.Female,
                    FirstName = "Marya",
                    LastName = "Ivanova",
                    Marks = new StudentMarkXmlData[] { new StudentMarkXmlData { Exam = "Matan", Mark = 5 } }
                }
            };
            var formatterList = new XmlSerializer(typeof(List<StudentXmlData>));
            using (var fs = new FileStream("studentList.xml", FileMode.OpenOrCreate))
            {
                formatterList.Serialize(fs, studentList);
            }

            using (var fs = new FileStream("studentList.xml", FileMode.OpenOrCreate))
            {
                var newStudents = (List<StudentXmlData>)formatterList.Deserialize(fs);
                foreach (var newStudent in newStudents)
                {
                    Console.WriteLine("Student: {0} {1} {2} {3}", newStudent.LastName, newStudent.FirstName, newStudent.Age, newStudent.Gender);
                }
            }

            Console.WriteLine();

            #endregion

            #region XmlReader/XmlWriter

            using (var fileStream = new FileStream("XmlReaderWriter.xml", FileMode.Create))
            {
                using (var writer = XmlWriter.Create(fileStream))
                {
                    writer.WriteComment("sample XML document");
                    writer.WriteStartElement("book");
                    writer.WriteAttributeString("genre", "novel");
                    writer.WriteStartElement("title");
                    writer.WriteString("The Handmaid's Tale");
                    writer.WriteEndElement();
                    writer.WriteElementString("price", "19.95");
                    writer.WriteEndElement();
                    writer.Flush();
                }
            }

            using (var fileStream = new FileStream("XmlReaderWriter.xml", FileMode.Open))
            {
                using (var reader = XmlReader.Create(fileStream))
                {
                    while (reader.Read())
                    {
                        switch (reader.NodeType)
                        {
                            case XmlNodeType.Element:
                                Console.Write("| Element: {0}", reader.Name);
                                break;
                            case XmlNodeType.Text:
                                Console.Write("| {0} |", reader.Value);
                                break;
                            case XmlNodeType.Comment:
                                Console.Write("| Comment: {0}", reader.Value);
                                break;
                        }
                    }
                }
            }

            Console.WriteLine();
            Console.WriteLine();

            #endregion

            #region LINQ to Xml

            var studentElement = new XElement("Student");
            studentElement.Add(new XElement("FirstName", "Ivan"));
            studentElement.Add(new XElement("LastName", "Ivanov"));
            studentElement.Add(new XAttribute("Age", "18"));

            var xDocument = new XDocument(
                new XElement("Students",
                    new XElement("Student",
                        new XAttribute("Age", "19"),
                        new XElement("FirstName", "Petr"),
                        new XElement("LastName", "Petrov")),
                    studentElement)
            );
            xDocument.Save("StudentLinq.xml");

            var xDocumentLoad = XDocument.Load("StudentLinq.xml");
            var firstName = xDocumentLoad
                        .Root
                        .Elements("Student")
                        .Elements("FirstName")
                        .First();

            Console.WriteLine("First Student Name; {0}", firstName.Value);

            Console.WriteLine();

            #endregion

            #region JSON

            var studentJson = new StudentJsonData("00/000")
            {
                Age = 19,
                Gender = GenderXmlData.Male,
                FirstName = "Ivan",
                LastName = "Ivanov",
                Marks = null
            };
            using (var fs = new FileStream($"{student.LastName}.json", FileMode.OpenOrCreate))
            {
                System.Text.Json.JsonSerializer.SerializeAsync(fs, studentJson);
            }

            using (var fs = new FileStream($"{student.LastName}.json", FileMode.Open))
            {
                var newStudent = System.Text.Json.JsonSerializer.DeserializeAsync<StudentJsonData>(fs).Result;
                Console.WriteLine("Student: {0} {1} {2} {3}", newStudent.LastName, newStudent.FirstName, newStudent.Age, newStudent.Gender);
            }

            Console.WriteLine();

            var studentJsonList = new List<StudentJsonData>()
            {
                studentJson,
                new StudentJsonData("00/000")
                {
                    Age = 19,
                    Gender = GenderXmlData.Female,
                    FirstName = "Marya",
                    LastName = "Ivanova",
                    Marks = new StudentMarkXmlData[] { new StudentMarkXmlData { Exam = "Matan", Mark = 5 } }
                }
            };
            using (var fs = new FileStream("studentList.json", FileMode.OpenOrCreate))
            {
                System.Text.Json.JsonSerializer.Serialize(new Utf8JsonWriter(fs), studentJsonList);
            }

            using (var fs = new FileStream("studentList.json", FileMode.Open))
            {
                var newStudents = System.Text.Json.JsonSerializer.DeserializeAsync<List<StudentJsonData>>(fs).Result;
                foreach (var newStudent in newStudents)
                {
                    Console.WriteLine("Student: {0} {1} {2} {3}", newStudent.LastName, newStudent.FirstName, newStudent.Age, newStudent.Gender);
                }
            }

            Console.WriteLine();

            #endregion

            #region JSON DataContract

            var studentContract = new StudentDataContract("00/000")
            {
                Age = 19,
                Gender = GenderXmlData.Male,
                FirstName = "Ivan",
                LastName = "Ivanov",
                Marks = null
            };
            var ser = new DataContractJsonSerializer(typeof(StudentDataContract));
            using (var fs = new FileStream($"{student.LastName}Contract.json", FileMode.OpenOrCreate))
            {
                ser.WriteObject(fs, studentContract);
            }

            using (var fs = new FileStream($"{student.LastName}Contract.json", FileMode.Open))
            {
                var newStudent = (StudentDataContract)ser.ReadObject(fs);
                Console.WriteLine("Student: {0} {1} {2} {3}", newStudent.LastName, newStudent.FirstName, newStudent.Age, newStudent.Gender);
            }

            Console.WriteLine();

            #endregion

            #region JSONConvert

            var newtonSer = new Newtonsoft.Json.JsonSerializer();
            using (var sw = new StreamWriter($"{student.LastName}NewtonVar1.json"))
            {
                newtonSer.Serialize(new JsonTextWriter(sw), studentJson);
            }
            using (var sw = new StreamWriter($"{student.LastName}NewtonVar2.json"))
            {
                sw.WriteLine(JsonConvert.SerializeObject(studentJson));
            }

            using (var sr = new StreamReader($"{student.LastName}NewtonVar2.json"))
            {
                var newStudent = JsonConvert.DeserializeObject<StudentJsonData>(sr.ReadLine());
                Console.Write("Student: {0} {1} {2} {3}", newStudent.LastName, newStudent.FirstName, newStudent.Age, newStudent.Gender);
            }
            using (var sr = new StreamReader($"{student.LastName}NewtonVar2.json"))
            {
                var newStudent = newtonSer.Deserialize<StudentJsonData>(new JsonTextReader(sr));
                Console.WriteLine("Student: {0} {1} {2} {3}", newStudent.LastName, newStudent.FirstName, newStudent.Age, newStudent.Gender);
            }

            Console.WriteLine();

            #endregion

            Console.ReadKey();
        }
    }
}
