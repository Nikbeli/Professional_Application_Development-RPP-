﻿using AbstractShopContracts.BindingModels;
using AbstractShopContracts.SearchModels;
using AbstractShopContracts.StoragesContracts;
using AbstractShopContracts.ViewModels;

namespace AbstractShopDatabaseImplement.Implements
{
    public class OrderStorage : IOrderStorage
    {
        public OrderViewModel? Delete(OrderBindingModel model)
        {
            throw new NotImplementedException();
        }

        public OrderViewModel? GetElement(OrderSearchModel model)
        {
            throw new NotImplementedException();
        }

        public List<OrderViewModel> GetFilteredList(OrderSearchModel model)
        {
            throw new NotImplementedException();
        }

        public List<OrderViewModel> GetFullList()
        {
            throw new NotImplementedException();
        }

        public OrderViewModel? Insert(OrderBindingModel model)
        {
            throw new NotImplementedException();
        }

        public OrderViewModel? Update(OrderBindingModel model)
        {
            throw new NotImplementedException();
        }
    }
}