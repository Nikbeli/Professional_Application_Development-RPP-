﻿using AbstractShopContracts.BindingModels;
using AbstractShopContracts.ViewModels;
using AbstractShopDataModels.Models;
using System.Xml.Linq;

namespace AbstractShopFileImplement.Models
{
    internal class Product : IProductModel
    {
        public int Id { get; private set; }

        public string ProductName { get; private set; } = string.Empty;

        public double Price { get; private set; }

        public Dictionary<int, int> Components { get; private set; } = new();

        private Dictionary<int, (IComponentModel, int)>? _productComponents = null;

        public Dictionary<int, (IComponentModel, int)> ProductComponents
        {
            get
            {
                if (_productComponents == null)
                {
                    var source = DataFileSingleton.GetInstance();
                    _productComponents = Components.ToDictionary(x => x.Key, y => ((source.Components.FirstOrDefault(z => z.Id == y.Key) as IComponentModel)!, y.Value));
                }
                return _productComponents;
            }
        }

        public static Product? Create(ProductBindingModel? model)
        {
            if (model == null)
            {
                return null;
            }
            return new Product()
            {
                Id = model.Id,
                ProductName = model.ProductName,
                Price = model.Price,
                Components = model.ProductComponents.ToDictionary(x => x.Key, x => x.Value.Item2)
            };
        }

        public static Product? Create(XElement element)
        {
            if (element == null)
            {
                return null;
            }
            return new Product()
            {
                Id = Convert.ToInt32(element.Attribute("Id")!.Value),
                ProductName = element.Element("ProductName")!.Value,
                Price = Convert.ToDouble(element.Element("Price")!.Value),
                Components = element.Element("ProductComponents")!.Elements("ProductComponent")
                                .ToDictionary(x => Convert.ToInt32(x.Element("Key")?.Value), x => Convert.ToInt32(x.Element("Value")?.Value))
            };
        }

        public void Update(ProductBindingModel? model)
        {
            if (model == null)
            {
                return;
            }
            ProductName = model.ProductName;
            Price = model.Price;
            Components = model.ProductComponents.ToDictionary(x => x.Key, x => x.Value.Item2);
            _productComponents = null;
        }

        public ProductViewModel GetViewModel => new()
        {
            Id = Id,
            ProductName = ProductName,
            Price = Price,
            ProductComponents = ProductComponents
        };

        public XElement GetXElement => new("Product",
                        new XAttribute("Id", Id),
                        new XElement("ProductName", ProductName),
                        new XElement("Price", Price.ToString()),
                        new XElement("ProductComponents", Components.Select(x => new XElement("ProductComponent",
                                                                                        new XElement("Key", x.Key),
                                                                                        new XElement("Value", x.Value)))
                                                                        .ToArray()));
    }
}
