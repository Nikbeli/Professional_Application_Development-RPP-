﻿using AbstractShopContracts.BindingModels;
using AbstractShopContracts.SearchModels;
using AbstractShopContracts.StoragesContracts;
using AbstractShopContracts.ViewModels;

namespace AbstractShopListImplement.Implements
{
    public class ClientStorage : IClientStorage
    {
        public ClientViewModel? Delete(ClientBindingModel model)
        {
            throw new NotImplementedException();
        }

        public ClientViewModel? GetElement(ClientSearchModel model)
        {
            throw new NotImplementedException();
        }

        public List<ClientViewModel> GetFilteredList(ClientSearchModel model)
        {
            throw new NotImplementedException();
        }

        public List<ClientViewModel> GetFullList()
        {
            throw new NotImplementedException();
        }

        public ClientViewModel? Insert(ClientBindingModel model)
        {
            throw new NotImplementedException();
        }

        public ClientViewModel? Update(ClientBindingModel model)
        {
            throw new NotImplementedException();
        }
    }
}