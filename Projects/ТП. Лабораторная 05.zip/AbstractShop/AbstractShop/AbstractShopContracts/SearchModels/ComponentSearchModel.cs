﻿namespace AbstractShopContracts.SearchModels
{
    public class ComponentSearchModel
    {
        public int? Id { get; set; }

        public string? ComponentName { get; set; }
    }
}