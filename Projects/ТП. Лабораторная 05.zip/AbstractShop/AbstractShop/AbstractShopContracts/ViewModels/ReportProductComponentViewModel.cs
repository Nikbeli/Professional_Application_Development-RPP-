﻿namespace AbstractShopContracts.ViewModels
{
    public class ReportProductComponentViewModel
    {
        public string ComponentName { get; set; } = string.Empty;

        public int TotalCount { get; set; }

        public List<(string Product, int Count)> Products { get; set; } = new();
    }
}