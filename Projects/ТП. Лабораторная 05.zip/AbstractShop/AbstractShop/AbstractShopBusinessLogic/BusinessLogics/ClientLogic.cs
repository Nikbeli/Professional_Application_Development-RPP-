﻿using AbstractShopContracts.BindingModels;
using AbstractShopContracts.BusinessLogicsContracts;
using AbstractShopContracts.SearchModels;
using AbstractShopContracts.ViewModels;

namespace AbstractShopBusinessLogic.BusinessLogics
{
    public class ClientLogic : IClientLogic
    {
        public bool Create(ClientBindingModel model)
        {
            throw new NotImplementedException();
        }

        public bool Delete(ClientBindingModel model)
        {
            throw new NotImplementedException();
        }

        public ClientViewModel? ReadElement(ClientSearchModel model)
        {
            throw new NotImplementedException();
        }

        public List<ClientViewModel>? ReadList(ClientSearchModel? model)
        {
            throw new NotImplementedException();
        }

        public bool Update(ClientBindingModel model)
        {
            throw new NotImplementedException();
        }
    }
}