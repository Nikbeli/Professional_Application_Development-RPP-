﻿using AbstractShopContracts.ViewModels;

namespace AbstractShopBusinessLogic.OfficePackage.HelperModels
{
    public class ExcelInfo
    {
        public string FileName { get; set; } = string.Empty;

        public string Title { get; set; } = string.Empty;

        public List<ReportProductComponentViewModel> ProductComponents { get; set; } = new();
    }
}