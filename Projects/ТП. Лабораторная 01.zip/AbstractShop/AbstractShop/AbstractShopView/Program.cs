using AbstractShopBusinessLogic.BusinessLogics;
using AbstractShopContracts.BusinessLogicsContracts;
using AbstractShopContracts.StoragesContracts;
using AbstractShopListImplement.Implements;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using NLog.Extensions.Logging;

namespace AbstractShopView
{
    internal static class Program
    {
        private static ServiceProvider? _serviceProvider;
        public static ServiceProvider? ServiceProvider => _serviceProvider;

        /// <summary>
        ///  The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            // To customize application configuration such as set high DPI settings or default font,
            // see https://aka.ms/applicationconfiguration.
            ApplicationConfiguration.Initialize();
           // Application.Run(new Form1());
        }

		private static void ConfigureServices(ServiceCollection services)
		{
			services.AddLogging(option =>
			{
				option.SetMinimumLevel(LogLevel.Information);
				option.AddNLog("nlog.config");
			});
			services.AddTransient<IComponentStorage, ComponentStorage>();
			services.AddTransient<IOrderStorage, OrderStorage>();
			services.AddTransient<IProductStorage, ProductStorage>();

			services.AddTransient<IComponentLogic, ComponentLogic>();
			services.AddTransient<IOrderLogic, OrderLogic>();
			services.AddTransient<IProductLogic, ProductLogic>();

			services.AddTransient<FormMain>();
			services.AddTransient<FormComponent>();
			services.AddTransient<FormComponents>();
			services.AddTransient<FormCreateOrder>();
			services.AddTransient<FormProduct>();
			services.AddTransient<FormProductComponent>();
		}
	}
}