﻿namespace AbstractShopContracts.SearchModels
{
    public class OrderSearchModel
    {
        public int? Id { get; set; }
    }
}