﻿namespace AbstractShopContracts.SearchModels
{
    public class ProductSearchModel
    {
        public int? Id { get; set; }

        public string? ProductName { get; set; }
    }
}