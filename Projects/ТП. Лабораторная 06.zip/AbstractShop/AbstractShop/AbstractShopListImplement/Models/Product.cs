﻿using AbstractShopContracts.BindingModels;
using AbstractShopContracts.ViewModels;
using AbstractShopDataModels.Models;

namespace AbstractShopListImplement.Models
{
    internal class Product : IProductModel
    {
        public int Id { get; private set; }

        public string ProductName { get; private set; } = string.Empty;

        public double Price { get; private set; }

        public Dictionary<int, (IComponentModel, int)> ProductComponents { get; private set; } = new Dictionary<int, (IComponentModel, int)>();

        public static Product? Create(ProductBindingModel? model)
        {
            if (model == null)
            {
                return null;
            }
            return new Product()
            {
                Id = model.Id,
                ProductName = model.ProductName,
                Price = model.Price,
                ProductComponents = model.ProductComponents
            };
        }

        public void Update(ProductBindingModel? model)
        {
            if (model == null)
            {
                return;
            }
            ProductName = model.ProductName;
            Price = model.Price;
            ProductComponents = model.ProductComponents;
        }

        public ProductViewModel GetViewModel => new()
        {
            Id = Id,
            ProductName = ProductName,
            Price = Price,
            ProductComponents = ProductComponents
        };
    }
}