﻿using AbstractShopContracts.BindingModels;
using AbstractShopContracts.SearchModels;
using AbstractShopContracts.ViewModels;

namespace AbstractShopContracts.BusinessLogicsContracts
{
    public interface IProductLogic
    {
        List<ProductViewModel>? ReadList(ProductSearchModel? model);

        ProductViewModel? ReadElement(ProductSearchModel model);

        bool Create(ProductBindingModel model);

        bool Update(ProductBindingModel model);

        bool Delete(ProductBindingModel model);
    }
}