﻿using AbstractShopContracts.BindingModels;
using AbstractShopContracts.ViewModels;
using AbstractShopDataModels.Enums;
using AbstractShopDataModels.Models;
using System.Xml.Linq;

namespace AbstractShopFileImplement.Models
{
    internal class Order : IOrderModel
    {
        public int ProductId => throw new NotImplementedException();

        public int Count => throw new NotImplementedException();

        public double Sum => throw new NotImplementedException();

        public OrderStatus Status => throw new NotImplementedException();

        public DateTime DateCreate => throw new NotImplementedException();

        public DateTime? DateImplement => throw new NotImplementedException();

        public int Id => throw new NotImplementedException();

        public static Order? Create(OrderBindingModel? model)
        {
            return new Order();
        }

        public static Order? Create(XElement element)
        {
            return new Order();
        }

        public void Update(OrderBindingModel? model)
        {

        }

        public OrderViewModel GetViewModel => new()
        {
        };

        public XElement GetXElement => new("Order");
    }
}
