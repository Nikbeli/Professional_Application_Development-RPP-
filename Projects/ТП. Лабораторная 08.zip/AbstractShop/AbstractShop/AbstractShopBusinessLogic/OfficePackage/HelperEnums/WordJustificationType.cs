﻿namespace AbstractShopBusinessLogic.OfficePackage.HelperEnums
{
    public enum WordJustificationType
    {
        Center,

        Both
    }
}