﻿using AbstractShopContracts.BindingModels;
using AbstractShopContracts.BusinessLogicsContracts;
using AbstractShopContracts.SearchModels;
using AbstractShopContracts.ViewModels;

namespace AbstractShopBusinessLogic.BusinessLogics
{
    public class ImplementerLogic : IImplementerLogic
    {
        public bool Create(ImplementerBindingModel model)
        {
            throw new NotImplementedException();
        }

        public bool Delete(ImplementerBindingModel model)
        {
            throw new NotImplementedException();
        }

        public ImplementerViewModel? ReadElement(ImplementerSearchModel model)
        {
            throw new NotImplementedException();
        }

        public List<ImplementerViewModel>? ReadList(ImplementerSearchModel? model)
        {
            throw new NotImplementedException();
        }

        public bool Update(ImplementerBindingModel model)
        {
            throw new NotImplementedException();
        }
    }
}