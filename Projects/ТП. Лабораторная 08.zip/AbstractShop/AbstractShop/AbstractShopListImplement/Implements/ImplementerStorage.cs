﻿using AbstractShopContracts.BindingModels;
using AbstractShopContracts.SearchModels;
using AbstractShopContracts.StoragesContracts;
using AbstractShopContracts.ViewModels;

namespace AbstractShopListImplement.Implements
{
    public class ImplementerStorage : IImplementerStorage
    {
        public ImplementerViewModel? Delete(ImplementerBindingModel model)
        {
            throw new NotImplementedException();
        }

        public ImplementerViewModel? GetElement(ImplementerSearchModel model)
        {
            throw new NotImplementedException();
        }

        public List<ImplementerViewModel> GetFilteredList(ImplementerSearchModel model)
        {
            throw new NotImplementedException();
        }

        public List<ImplementerViewModel> GetFullList()
        {
            throw new NotImplementedException();
        }

        public ImplementerViewModel? Insert(ImplementerBindingModel model)
        {
            throw new NotImplementedException();
        }

        public ImplementerViewModel? Update(ImplementerBindingModel model)
        {
            throw new NotImplementedException();
        }
    }
}