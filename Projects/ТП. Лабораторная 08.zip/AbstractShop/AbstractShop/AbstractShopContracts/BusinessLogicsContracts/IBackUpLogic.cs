﻿using AbstractShopContracts.BindingModels;

namespace AbstractShopContracts.BusinessLogicsContracts
{
    public interface IBackUpLogic
    {
        void CreateBackUp(BackUpSaveBinidngModel model);
    }
}