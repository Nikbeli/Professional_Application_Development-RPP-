﻿namespace AbstractShopContracts.SearchModels
{
    public class ClientSearchModel
    {
        public int? Id { get; set; }

        public string? ClientFIO { get; set; }

        public string? Email { get; set; }

        public string? Password { get; set; }
    }
}