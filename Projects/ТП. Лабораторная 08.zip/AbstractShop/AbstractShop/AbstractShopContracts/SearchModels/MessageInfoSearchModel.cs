﻿namespace AbstractShopContracts.SearchModels
{
    public class MessageInfoSearchModel
    {
        public int? ClientId { get; set; }

        public string? MessageId { get; set; }
    }
}