﻿namespace AbstractShopContracts.SearchModels
{
    public class ImplementerSearchModel
    {
        public int? Id { get; set; }

        public string? ImplementerFIO { get; set; }

        public string? Password { get; set; }
    }
}