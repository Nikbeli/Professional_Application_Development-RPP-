﻿namespace AbstractShopContracts.BindingModels
{
    public class BackUpSaveBinidngModel
    {
        public string FolderName { get; set; } = string.Empty;
    }
}