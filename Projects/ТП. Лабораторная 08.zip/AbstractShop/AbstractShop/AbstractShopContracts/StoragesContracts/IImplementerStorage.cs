﻿using AbstractShopContracts.BindingModels;
using AbstractShopContracts.SearchModels;
using AbstractShopContracts.ViewModels;

namespace AbstractShopContracts.StoragesContracts
{
    public interface IImplementerStorage
    {
        List<ImplementerViewModel> GetFullList();

        List<ImplementerViewModel> GetFilteredList(ImplementerSearchModel model);

        ImplementerViewModel? GetElement(ImplementerSearchModel model);

        ImplementerViewModel? Insert(ImplementerBindingModel model);

        ImplementerViewModel? Update(ImplementerBindingModel model);

        ImplementerViewModel? Delete(ImplementerBindingModel model);
    }
}