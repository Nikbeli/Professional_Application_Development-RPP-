﻿using AbstractShopContracts.BindingModels;
using AbstractShopContracts.BusinessLogicsContracts;
using AbstractShopContracts.SearchModels;
using AbstractShopContracts.ViewModels;

namespace AbstractShopBusinessLogic.BusinessLogics
{
    public class ProductLogic : IProductLogic
    {
        public bool Create(ProductBindingModel model)
        {
            throw new NotImplementedException();
        }

        public bool Delete(ProductBindingModel model)
        {
            throw new NotImplementedException();
        }

        public ProductViewModel? ReadElement(ProductSearchModel model)
        {
            throw new NotImplementedException();
        }

        public List<ProductViewModel>? ReadList(ProductSearchModel? model)
        {
            throw new NotImplementedException();
        }

        public bool Update(ProductBindingModel model)
        {
            throw new NotImplementedException();
        }
    }
}