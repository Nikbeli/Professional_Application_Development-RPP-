﻿namespace AbstractShopBusinessLogic.OfficePackage.HelperEnums
{
    public enum PdfParagraphAlignmentType
    {
        Center,

        Left,

        Rigth
    }
}