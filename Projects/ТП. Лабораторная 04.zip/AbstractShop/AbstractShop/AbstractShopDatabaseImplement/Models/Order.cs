﻿using AbstractShopContracts.BindingModels;
using AbstractShopContracts.ViewModels;
using AbstractShopDataModels.Enums;
using AbstractShopDataModels.Models;

namespace AbstractShopDatabaseImplement.Models
{
    public class Order : IOrderModel
    {
        public int ProductId { get; set; }

        public int Count { get; set; }

        public double Sum { get; set; }

        public OrderStatus Status { get; set; }

        public DateTime DateCreate { get; set; }

        public DateTime? DateImplement { get; set; }

        public int Id { get; set; }

        public static Order? Create(OrderBindingModel? model)
        {
            return new Order();
        }

        public void Update(OrderBindingModel? model)
        {

        }

        public OrderViewModel GetViewModel => new()
        {
        };
    }
}