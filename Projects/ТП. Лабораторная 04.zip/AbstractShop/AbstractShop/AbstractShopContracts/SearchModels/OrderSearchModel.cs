﻿namespace AbstractShopContracts.SearchModels
{
    public class OrderSearchModel
    {
        public int? Id { get; set; }

        public DateTime? DateFrom { get; set; }

        public DateTime? DateTo { get; set; }
    }
}