﻿using AbstractShopDataModels.Models;
using System.ComponentModel;

namespace AbstractShopContracts.ViewModels
{
    public class ProductViewModel : IProductModel
    {
        public int Id { get; set; }

        [DisplayName("Название изделия")]
        public string ProductName { get; set; } = string.Empty;

        [DisplayName("Цена")]
        public double Price { get; set; }

        public Dictionary<int, (IComponentModel, int)> ProductComponents { get; set; } = new();
    }
}
