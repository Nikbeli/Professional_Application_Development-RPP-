﻿using AbstractShopContracts.BindingModels;
using AbstractShopContracts.SearchModels;
using AbstractShopContracts.ViewModels;

namespace AbstractShopContracts.BusinessLogicsContracts
{
    public interface IOrderLogic
    {
        List<OrderViewModel>? ReadList(OrderSearchModel? model);

        bool CreateOrder(OrderBindingModel model);

        bool TakeOrderInWork(OrderBindingModel model);

        bool FinishOrder(OrderBindingModel model);

        bool DeliveryOrder(OrderBindingModel model);
    }
}