﻿using AbstractShopDatabaseImplement.Models;
using Microsoft.EntityFrameworkCore;

namespace AbstractShopDatabaseImplement
{
    public class AbstractShopDatabase : DbContext
    {
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (optionsBuilder.IsConfigured == false)
            {
                optionsBuilder.UseSqlServer(@"Data Source=CHESHIR\SQLEXPRESS;Initial Catalog=AbstractShopDatabase;Integrated Security=True;MultipleActiveResultSets=True;;TrustServerCertificate=True");
            }
            base.OnConfiguring(optionsBuilder);
        }

        public virtual DbSet<Component> Components { set; get; }

        public virtual DbSet<Product> Products { set; get; }

        public virtual DbSet<ProductComponent> ProductComponents { set; get; }

        public virtual DbSet<Order> Orders { set; get; }
    }
}