﻿using AbstractShopDataModels.Enums;
using AbstractShopDataModels.Models;

namespace AbstractShopContracts.BindingModels
{
    public class OrderBindingModel : IOrderModel
    {
        public int Id { get; set; }

        public int ProductId { get; set; }

        public int Count { get; set; }

        public double Sum { get; set; }

        public OrderStatus Status { get; set; } = OrderStatus.Неизвестен;

        public DateTime DateCreate { get; set; } = DateTime.Now;

        public DateTime? DateImplement { get; set; }
    }
}