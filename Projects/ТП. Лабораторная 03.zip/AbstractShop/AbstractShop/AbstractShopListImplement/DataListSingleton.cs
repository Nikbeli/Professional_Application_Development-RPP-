﻿using AbstractShopListImplement.Models;

namespace AbstractShopListImplement
{
    internal class DataListSingleton
    {
        private static DataListSingleton? _instance;

        public List<Component> Components { get; set; }

        public List<Order> Orders { get; set; }

        public List<Product> Products { get; set; }

        private DataListSingleton()
        {
            Components = new List<Component>();
            Orders = new List<Order>();
            Products = new List<Product>();
        }

        public static DataListSingleton GetInstance()
        {
            if (_instance == null)
            {
                _instance = new DataListSingleton();
            }

            return _instance;
        }
    }
}