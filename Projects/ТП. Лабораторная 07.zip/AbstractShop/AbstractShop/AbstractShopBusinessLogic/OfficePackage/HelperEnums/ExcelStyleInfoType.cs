﻿namespace AbstractShopBusinessLogic.OfficePackage.HelperEnums
{
    public enum ExcelStyleInfoType
    {
        Title,

        Text,

        TextWithBroder
    }
}