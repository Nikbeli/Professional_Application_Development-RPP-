﻿using AbstractShopContracts.BindingModels;
using AbstractShopContracts.BusinessLogicsContracts;
using AbstractShopContracts.SearchModels;
using AbstractShopContracts.ViewModels;

namespace AbstractShopBusinessLogic.BusinessLogics
{
    public class MessageInfoLogic : IMessageInfoLogic
    {
        public bool Create(MessageInfoBindingModel model)
        {
            throw new NotImplementedException();
        }

        public List<MessageInfoViewModel>? ReadList(MessageInfoSearchModel? model)
        {
            throw new NotImplementedException();
        }
    }
}