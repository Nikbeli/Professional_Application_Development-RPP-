﻿using AbstractShopContracts.BindingModels;
using AbstractShopContracts.BusinessLogicsContracts;
using AbstractShopContracts.SearchModels;
using AbstractShopContracts.ViewModels;

namespace AbstractShopBusinessLogic.BusinessLogics
{
    public class OrderLogic : IOrderLogic
    {
        public bool CreateOrder(OrderBindingModel model)
        {
            throw new NotImplementedException();
        }

        public bool DeliveryOrder(OrderBindingModel model)
        {
            throw new NotImplementedException();
        }

        public bool FinishOrder(OrderBindingModel model)
        {
            throw new NotImplementedException();
        }

        public OrderViewModel? ReadElement(OrderSearchModel model)
        {
            throw new NotImplementedException();
        }

        public List<OrderViewModel>? ReadList(OrderSearchModel? model)
        {
            throw new NotImplementedException();
        }

        public bool TakeOrderInWork(OrderBindingModel model)
        {
            throw new NotImplementedException();
        }
    }
}