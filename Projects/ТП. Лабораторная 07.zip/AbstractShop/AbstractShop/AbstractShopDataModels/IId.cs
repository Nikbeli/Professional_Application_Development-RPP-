﻿namespace AbstractShopDataModels
{
    public interface IId
    {
        int Id { get; }
    }
}