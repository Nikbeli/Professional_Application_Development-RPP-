using AbstractShopBusinessLogic.BusinessLogics;
using AbstractShopBusinessLogic.MailWorker;
using AbstractShopBusinessLogic.OfficePackage;
using AbstractShopBusinessLogic.OfficePackage.Implements;
using AbstractShopContracts.BindingModels;
using AbstractShopContracts.BusinessLogicsContracts;
using AbstractShopContracts.StoragesContracts;
using AbstractShopDatabaseImplement.Implements;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using NLog.Extensions.Logging;

namespace AbstractShopView
{
    internal static class Program
    {
        private static ServiceProvider? _serviceProvider;
        public static ServiceProvider? ServiceProvider => _serviceProvider;

        /// <summary>
        ///  The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            // To customize application configuration such as set high DPI settings or default font,
            // see https://aka.ms/applicationconfiguration.
            ApplicationConfiguration.Initialize();
			var services = new ServiceCollection();
			ConfigureServices(services);
			_serviceProvider = services.BuildServiceProvider();

			try
			{
				var mailSender = _serviceProvider.GetService<AbstractMailWorker>();
				mailSender?.MailConfig(new MailConfigBindingModel
				{
					MailLogin = System.Configuration.ConfigurationManager.AppSettings["MailLogin"] ?? string.Empty,
					MailPassword = System.Configuration.ConfigurationManager.AppSettings["MailPassword"] ?? string.Empty,
					SmtpClientHost = System.Configuration.ConfigurationManager.AppSettings["SmtpClientHost"] ?? string.Empty,
					SmtpClientPort = Convert.ToInt32(System.Configuration.ConfigurationManager.AppSettings["SmtpClientPort"]),
					PopHost = System.Configuration.ConfigurationManager.AppSettings["PopHost"] ?? string.Empty,
					PopPort = Convert.ToInt32(System.Configuration.ConfigurationManager.AppSettings["PopPort"])
				});

				// ������� ������
				var timer = new System.Threading.Timer(new TimerCallback(MailCheck!), null, 0, 100000);
			}
			catch (Exception ex)
			{
				var logger = _serviceProvider.GetService<ILogger>();
				logger?.LogError(ex, "������ ������ � ������");
			}

			// Application.Run(new Form1());
		}

		private static void ConfigureServices(ServiceCollection services)
		{
			services.AddLogging(option =>
			{
				option.SetMinimumLevel(LogLevel.Information);
				option.AddNLog("nlog.config");
			});
			services.AddTransient<IClientStorage, ClientStorage>();
			services.AddTransient<IComponentStorage, ComponentStorage>();
			services.AddTransient<IImplementerStorage, ImplementerStorage>();
			services.AddTransient<IOrderStorage, OrderStorage>();
			services.AddTransient<IProductStorage, ProductStorage>();
			services.AddTransient<IMessageInfoStorage, MessageInfoStorage>();

			services.AddTransient<IClientLogic, ClientLogic>();
			services.AddTransient<IComponentLogic, ComponentLogic>();
			services.AddTransient<IImplementerLogic, ImplementerLogic>();
			services.AddTransient<IOrderLogic, OrderLogic>();
			services.AddTransient<IProductLogic, ProductLogic>();
			services.AddTransient<IReportLogic, ReportLogic>();
			services.AddTransient<IMessageInfoLogic, MessageInfoLogic>();

			services.AddTransient<IWorkProcess, WorkModeling>();
			services.AddSingleton<AbstractMailWorker, MailKitWorker>();

			services.AddTransient<AbstractSaveToExcel, SaveToExcel>();
			services.AddTransient<AbstractSaveToWord, SaveToWord>();
			services.AddTransient<AbstractSaveToPdf, SaveToPdf>();

			services.AddTransient<FormMain>();
			services.AddTransient<FormClients>();
			services.AddTransient<FormComponent>();
			services.AddTransient<FormComponents>();
			services.AddTransient<FormCreateOrder>();
			services.AddTransient<FormProduct>();
			services.AddTransient<FormProductComponent>();
			services.AddTransient<FormReportProductComponents>();
			services.AddTransient<FormReportOrders>();
		}

		private static void MailCheck(object obj) => ServiceProvider?.GetService<AbstractMailWorker>()?.MailCheck();
	}
}