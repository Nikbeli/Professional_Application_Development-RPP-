﻿using AbstractShopContracts.BindingModels;
using AbstractShopContracts.SearchModels;
using AbstractShopContracts.StoragesContracts;
using AbstractShopContracts.ViewModels;

namespace AbstractShopFileImplement.Implements
{
    public class MessageInfoStorage : IMessageInfoStorage
    {
        public MessageInfoViewModel? GetElement(MessageInfoSearchModel model)
        {
            throw new NotImplementedException();
        }

        public List<MessageInfoViewModel> GetFilteredList(MessageInfoSearchModel model)
        {
            throw new NotImplementedException();
        }

        public List<MessageInfoViewModel> GetFullList()
        {
            throw new NotImplementedException();
        }

        public MessageInfoViewModel? Insert(MessageInfoBindingModel model)
        {
            throw new NotImplementedException();
        }
    }
}