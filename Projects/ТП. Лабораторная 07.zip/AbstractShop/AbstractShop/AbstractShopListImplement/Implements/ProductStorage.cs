﻿using AbstractShopContracts.BindingModels;
using AbstractShopContracts.SearchModels;
using AbstractShopContracts.StoragesContracts;
using AbstractShopContracts.ViewModels;

namespace AbstractShopListImplement.Implements
{
    public class ProductStorage : IProductStorage
    {
        public ProductViewModel? Delete(ProductBindingModel model)
        {
            throw new NotImplementedException();
        }

        public ProductViewModel? GetElement(ProductSearchModel model)
        {
            throw new NotImplementedException();
        }

        public List<ProductViewModel> GetFilteredList(ProductSearchModel model)
        {
            throw new NotImplementedException();
        }

        public List<ProductViewModel> GetFullList()
        {
            throw new NotImplementedException();
        }

        public ProductViewModel? Insert(ProductBindingModel model)
        {
            throw new NotImplementedException();
        }

        public ProductViewModel? Update(ProductBindingModel model)
        {
            throw new NotImplementedException();
        }
    }
}